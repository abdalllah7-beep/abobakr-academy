'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Code,
  Briefcase,
  Globe,
  Award,
  Heart,
  ArrowLeft,
  Terminal,
  Database,
  Layers,
  Rocket,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'

const topicData = {
  name: 'Python Programming Course',
  category: 'Digital Skills',
  rating: 4.9,
  students: 65,
  lessons: 220,
  description: 'Learn Python programming from scratch with our comprehensive course. Whether you\'re a complete beginner or looking to advance your skills, our expert tutors guide you through fundamentals, data structures, object-oriented programming, and real-world projects.',
  highlights: [
    'Beginner Friendly',
    'Hands-on Projects',
    'Real-World Applications',
    'Code Review Included',
    'Career Guidance',
    'Flexible Scheduling',
    'All Ages Welcome',
    'Certificate Provided',
  ],
  modules: [
    {
      name: 'Python Fundamentals',
      icon: Terminal,
      description: 'Start your Python journey with variables, data types, operators, and control flow. Build a solid foundation for more advanced concepts.',
      topics: ['Variables & data types', 'Operators', 'Control flow', 'Functions', 'Input/Output', 'Error handling'],
    },
    {
      name: 'Data Structures',
      icon: Database,
      description: 'Master Python\'s built-in data structures including lists, dictionaries, tuples, and sets. Learn when and how to use each effectively.',
      topics: ['Lists', 'Dictionaries', 'Tuples', 'Sets', 'List comprehensions', 'String manipulation'],
    },
    {
      name: 'Object-Oriented Programming',
      icon: Layers,
      description: 'Understand OOP concepts including classes, objects, inheritance, and polymorphism. Write clean, reusable, and maintainable code.',
      topics: ['Classes & objects', 'Inheritance', 'Polymorphism', 'Encapsulation', 'Magic methods', 'Design patterns'],
    },
    {
      name: 'Projects & Applications',
      icon: Rocket,
      description: 'Apply your knowledge to build real projects. Create applications, work with APIs, and develop a portfolio to showcase your skills.',
      topics: ['Web scraping', 'API integration', 'File handling', 'GUI basics', 'Automation', 'Final project'],
    },
  ],
}

const faqData = [
  {
    question: 'Is Python good for beginners?',
    answer: 'Python is widely considered the best programming language for beginners. Its clean, readable syntax closely resembles English, making it easy to understand and write. Unlike languages with complex syntax rules, Python lets you focus on learning programming concepts rather than struggling with grammar. Many universities and coding bootcamps start with Python for this reason.',
  },
  {
    question: 'How long does it take to learn Python?',
    answer: 'The time to learn Python depends on your goals. Basic Python fundamentals can be learned in 4-6 weeks with regular practice. Becoming comfortable with core concepts and data structures typically takes 2-3 months. Achieving job-ready skills for entry-level positions usually requires 4-6 months of dedicated learning and project work. Our personalized approach accelerates learning based on your pace.',
  },
  {
    question: 'What can I build with Python?',
    answer: 'Python is incredibly versatile. You can build web applications (using Django/Flask), automate repetitive tasks, analyze data, create games, build machine learning models, develop APIs, scrape websites, create desktop applications, and much more. Python is used by companies like Google, Netflix, and Instagram. During our course, you\'ll build practical projects that demonstrate these capabilities.',
  },
  {
    question: 'Do I need any prior programming experience?',
    answer: 'No prior programming experience is required for our Python course. We start from the very beginning—explaining what programming is and how computers understand code. Our patient tutors guide you through each concept step by step. Many of our most successful students started with zero programming knowledge.',
  },
  {
    question: 'What equipment do I need for Python classes?',
    answer: 'You only need a computer (Windows, Mac, or Linux) with internet access. We\'ll help you install Python and a code editor during the first session. No special hardware is required. For online classes, we use screen sharing and online code editors so you can code along with your tutor in real-time.',
  },
  {
    question: 'How are online Python classes conducted?',
    answer: 'Classes are conducted one-on-one via Zoom with screen sharing. You and your tutor code together in real-time using shared online editors or your local development environment. You see your tutor\'s screen as they explain concepts, and they see yours as you practice. This interactive approach means you learn by doing, not just watching.',
  },
  {
    question: 'Will this course help me get a job?',
    answer: 'Python skills are in high demand across industries. Our course provides practical skills that employers seek, and we include career guidance for those interested in programming careers. You\'ll build a portfolio of projects to showcase your abilities. While we can\'t guarantee employment, many students have transitioned to tech careers or enhanced their current roles with Python skills.',
  },
  {
    question: 'What age groups can learn Python?',
    answer: 'Python is suitable for learners of all ages. We teach students from age 10 through adults. For younger students, we use age-appropriate examples and focus on engaging projects like games. Teenagers often learn Python for school coursework or as preparation for university CS programs. Adults learn for career advancement or personal projects. Our one-on-one format allows us to tailor instruction to any age.',
  },
]

export default function PythonClient() {
  const courseSchemaData = {
    name: topicData.name,
    description: topicData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/topics/python-programming',
    category: 'Programming & Digital Skills',
    rating: topicData.rating,
    reviewCount: topicData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Programming', url: 'https://www.abobakracademy.com/courses/programming' },
    { name: 'Python Programming', url: 'https://www.abobakracademy.com/topics/python-programming' },
  ]

  return (
    <main className="min-h-screen bg-white">
      <FAQSchema faqs={faqData} courseName="Python Programming" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Python Programming Course"
        subtitle="Learn Python from scratch with expert tutors"
        breadcrumb="Programming / Python"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.students}+</p>
              <p className="text-white/70 text-sm">Python Students</p>
            </div>
            <div className="text-center">
              <Code className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <Briefcase className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">20+</p>
              <p className="text-white/70 text-sm">Projects Built</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Link */}
          <Link
            href="/courses/programming"
            className="inline-flex items-center gap-2 text-[#1DA678] hover:text-[#168a60] mb-6 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Programming Course
          </Link>

          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Digital Skills</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {topicData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {topicData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {topicData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Python Modules */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Course Curriculum</h2>
              <div className="space-y-6">
                {topicData.modules.map((module, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-[#E8F8F2] rounded-xl flex items-center justify-center flex-shrink-0">
                          <module.icon className="w-6 h-6 text-[#1DA678]" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">{module.name}</h3>
                          <p className="text-gray-600 text-sm md:text-base mb-3">{module.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {module.topics.map((topic, i) => (
                              <Badge key={i} variant="outline" className="text-xs">{topic}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn Python with Us?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Python has become the world&apos;s most popular programming language, and for good reason.
                    It&apos;s used in web development, data science, artificial intelligence, automation, and
                    countless other fields. Learning Python opens doors to some of the most exciting and
                    well-paid careers in technology.
                  </p>
                  <p>
                    What sets our Python course apart is the one-on-one attention you receive. Instead of
                    struggling through video tutorials alone, you have an expert tutor who answers your
                    questions in real-time, reviews your code, and guides you past common pitfalls. This
                    personalized approach dramatically accelerates learning.
                  </p>
                  <p>
                    Our project-based curriculum means you don&apos;t just learn syntax—you build real
                    applications. From simple calculators to web scrapers and games, each project teaches
                    practical skills you can apply immediately. By course end, you&apos;ll have a portfolio
                    showcasing your abilities to employers or for personal satisfaction.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Start Coding Today</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Book a free trial session to experience our Python teaching and start your coding journey.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Code className="w-4 h-4 text-[#1DA678]" />
                      <span>Write real code from day one</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>No prior experience needed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;I went from knowing nothing about programming to building my own web scraper and automation scripts in just 3 months. The one-on-one sessions made all the difference!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Ahmad</p>
                  <p className="text-xs md:text-sm text-gray-600">Python Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Python"
        subtitle="Everything you need to know about learning Python programming"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Learn Python?
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join students who have transformed their careers with Python skills.
            Book your free trial today.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
