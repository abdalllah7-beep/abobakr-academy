import { Metadata } from 'next'
import PythonClient from './client'

export const metadata: Metadata = {
  title: 'Python Programming Course Online | Learn Python from Scratch',
  description: 'Learn Python programming online with expert tutors. Master Python fundamentals, data structures, OOP, and build real projects. Perfect for beginners and those advancing their coding skills.',
  keywords: 'Python programming, learn Python online, Python course, Python for beginners, Python tutorial, coding classes, programming course',
  openGraph: {
    title: 'Python Programming Course Online | Abobakr Academy',
    description: 'Learn Python programming online with expert tutors. Master fundamentals and build real projects.',
    url: 'https://www.abobakracademy.com/topics/python-programming',
    siteName: 'Abobakr Academy',
    type: 'website',
  },
  alternates: {
    canonical: 'https://www.abobakracademy.com/topics/python-programming',
  },
}

export default function PythonProgrammingPage() {
  return <PythonClient />
}
