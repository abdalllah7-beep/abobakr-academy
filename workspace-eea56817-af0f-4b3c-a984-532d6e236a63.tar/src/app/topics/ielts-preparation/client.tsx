'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  BookOpen,
  Mic,
  PenTool,
  Headphones,
  Globe,
  Award,
  Heart,
  ArrowLeft,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'

const topicData = {
  name: 'IELTS Preparation Course',
  category: 'English Language',
  rating: 4.9,
  students: 85,
  lessons: 320,
  description: 'Achieve your target IELTS band score with our comprehensive preparation course. Our certified IELTS tutors provide personalized coaching for all four modules: Reading, Writing, Speaking, and Listening. Whether you need Academic or General Training, we tailor our approach to your specific goals.',
  highlights: [
    'Certified IELTS Instructors',
    'All Four Modules Covered',
    'Practice Tests Included',
    'Speaking Mock Tests',
    'Writing Feedback',
    'Band Score 7.0-8.5 Results',
    'Academic & General Training',
    'Flexible Scheduling',
  ],
  modules: [
    {
      name: 'IELTS Reading',
      icon: BookOpen,
      description: 'Master reading comprehension strategies for all question types. Learn skimming, scanning, and time management techniques. Practice with authentic Cambridge materials and past papers.',
      topics: ['True/False/Not Given', 'Matching Headings', 'Multiple Choice', 'Summary Completion', 'Matching Information'],
    },
    {
      name: 'IELTS Writing',
      icon: PenTool,
      description: 'Learn to write high-scoring Task 1 and Task 2 responses. Understand marking criteria, structure essays effectively, and use advanced vocabulary and grammar.',
      topics: ['Task 1 Graphs & Charts', 'Task 2 Essay Structure', 'Coherence & Cohesion', 'Lexical Resource', 'Grammar Range'],
    },
    {
      name: 'IELTS Speaking',
      icon: Mic,
      description: 'Build confidence and fluency for all three parts of the speaking test. Practice with mock interviews and receive detailed feedback on pronunciation and coherence.',
      topics: ['Part 1: Introduction', 'Part 2: Cue Card', 'Part 3: Discussion', 'Fluency Techniques', 'Pronunciation'],
    },
    {
      name: 'IELTS Listening',
      icon: Headphones,
      description: 'Develop listening skills for all four sections. Learn to identify keywords, understand accents, and manage the test format effectively.',
      topics: ['Section 1: Conversation', 'Section 2: Monologue', 'Section 3: Discussion', 'Section 4: Lecture', 'Note-Taking'],
    },
  ],
}

const faqData = [
  {
    question: 'How long does IELTS preparation take?',
    answer: 'The duration depends on your current English level and target band score. Students with strong intermediate English typically need 2-3 months of focused preparation to improve by 0.5-1.0 band. For those starting from a lower level, 4-6 months may be needed. We assess your current level during the free trial and create a realistic timeline based on your goals.',
  },
  {
    question: 'What is the difference between Academic and General Training IELTS?',
    answer: 'Academic IELTS is required for university admissions and professional registration. It includes academic reading passages and a graph/chart description in Writing Task 1. General Training is for migration and work purposes, with simpler reading passages and a letter-writing task. Both have the same Listening and Speaking sections. We prepare students for both versions.',
  },
  {
    question: 'How do you help with IELTS Writing?',
    answer: 'IELTS Writing requires specific techniques that differ from general writing. We teach you to analyze task questions correctly, plan responses efficiently, and structure essays for maximum coherence. You will receive detailed feedback on practice essays, identifying exactly where you lose marks and how to improve. Our students typically improve writing scores by 1.0-1.5 bands.',
  },
  {
    question: 'Do you offer speaking mock tests?',
    answer: 'Yes! Speaking mock tests are a core part of our IELTS preparation. We conduct realistic 11-14 minute mock interviews following the exact IELTS format. After each mock test, you receive detailed feedback on fluency, lexical resource, grammar, and pronunciation, with specific recommendations for improvement. Many students find mock tests the most valuable part of their preparation.',
  },
  {
    question: 'What materials do you use for IELTS preparation?',
    answer: 'We use official Cambridge IELTS materials, including authentic past papers and practice tests. Students receive access to vocabulary lists, essay templates, speaking topic cards, and listening practice audio. All materials are included in the course fee. We also provide supplementary resources for specific weaknesses identified during your preparation.',
  },
  {
    question: 'How do I know what band score I can achieve?',
    answer: 'During your free trial session, we conduct an initial assessment covering all four skills. Based on this assessment, we provide an estimated current band level and projected score after preparation. This honest assessment helps you set realistic goals and understand the work required. Most students improve by 0.5-1.5 bands with dedicated preparation.',
  },
  {
    question: 'Can you help me achieve Band 7.0 or higher?',
    answer: 'Absolutely! Band 7.0 and higher require specific advanced skills that our tutors are trained to develop. We focus on the precise criteria examiners use for scoring, particularly in Writing and Speaking where many students struggle to reach Band 7. Our students regularly achieve Band 7.0-8.5, with many gaining admission to top universities.',
  },
  {
    question: 'What is your success rate for IELTS students?',
    answer: 'Over 90% of our students achieve or exceed their target band score. Students who complete our full preparation program and follow the recommended practice schedule have the highest success rates. We track progress throughout the course with regular practice tests, so there are no surprises on exam day. Our testimonials show real results from real students.',
  },
]

export default function IeltsPreparationClient() {
  const courseSchemaData = {
    name: topicData.name,
    description: topicData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/topics/ielts-preparation',
    category: 'English Language Test Preparation',
    rating: topicData.rating,
    reviewCount: topicData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'English', url: 'https://www.abobakracademy.com/courses/english' },
    { name: 'IELTS Preparation', url: 'https://www.abobakracademy.com/topics/ielts-preparation' },
  ]

  return (
    <main className="min-h-screen bg-white">
      <FAQSchema faqs={faqData} courseName="IELTS Preparation" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="IELTS Preparation Course"
        subtitle="Achieve your target band score with expert IELTS tutoring"
        breadcrumb="English / IELTS Preparation"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.students}+</p>
              <p className="text-white/70 text-sm">IELTS Students</p>
            </div>
            <div className="text-center">
              <Award className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">7.5</p>
              <p className="text-white/70 text-sm">Avg. Band Score</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <Globe className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">90%+</p>
              <p className="text-white/70 text-sm">Success Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Link */}
          <Link
            href="/courses/english"
            className="inline-flex items-center gap-2 text-[#1DA678] hover:text-[#168a60] mb-6 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to English Course
          </Link>

          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">English Language</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {topicData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {topicData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {topicData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* IELTS Modules */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">IELTS Modules We Cover</h2>
              <div className="space-y-6">
                {topicData.modules.map((module, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-[#E8F8F2] rounded-xl flex items-center justify-center flex-shrink-0">
                          <module.icon className="w-6 h-6 text-[#1DA678]" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">{module.name}</h3>
                          <p className="text-gray-600 text-sm md:text-base mb-3">{module.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {module.topics.map((topic, i) => (
                              <Badge key={i} variant="outline" className="text-xs">{topic}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Choose Our IELTS Preparation?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    IELTS is more than just an English test—it&apos;s a gateway to international education, professional
                    registration, and migration opportunities. A high band score can open doors to top universities
                    in the UK, Australia, Canada, and beyond. Our preparation course is designed to maximize your
                    score efficiently.
                  </p>
                  <p>
                    What sets our IELTS preparation apart is our focus on the specific skills and strategies that
                    examiners look for. We don&apos;t just teach English—we teach IELTS. You&apos;ll learn exactly how
                    responses are marked, common traps to avoid, and techniques to showcase your best English
                    under test conditions.
                  </p>
                  <p>
                    Our certified IELTS instructors have helped students achieve band scores of 7.0-8.5, with many
                    gaining admission to prestigious institutions like Oxford, Cambridge, Melbourne, and Toronto.
                    Whether you need Academic or General Training, our personalized approach ensures you&apos;re
                    fully prepared on test day.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Start Your IELTS Journey</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Book a free assessment session to know your current level and create a study plan.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Free level assessment</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>90%+ success rate</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Assessment
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;I improved from Band 6.0 to 7.5 in just two months! The writing feedback was incredibly detailed and the speaking mock tests made me so confident. Now I&apos;m studying at University of Melbourne!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Layla</p>
                  <p className="text-xs md:text-sm text-gray-600">IELTS Academic, Band 7.5</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About IELTS Preparation"
        subtitle="Everything you need to know about achieving your target IELTS score"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Achieve Your Target IELTS Score?
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Book your free assessment today and take the first step toward your international goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Assessment
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
