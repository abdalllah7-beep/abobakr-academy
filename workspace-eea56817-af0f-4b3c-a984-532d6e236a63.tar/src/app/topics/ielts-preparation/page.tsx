import { Metadata } from 'next'
import IeltsClient from './client'

export const metadata: Metadata = {
  title: 'IELTS Preparation Course Online | Achieve Your Target Band Score',
  description: 'Expert online IELTS preparation with certified tutors. Master all four modules - Reading, Writing, Speaking, Listening. Achieve band 7.0-8.5 with personalized coaching.',
  keywords: 'IELTS preparation, IELTS online course, IELTS tutoring, IELTS band score, IELTS speaking, IELTS writing, IELTS reading, IELTS listening',
  openGraph: {
    title: 'IELTS Preparation Course Online | Abobakr Academy',
    description: 'Expert online IELTS preparation with certified tutors. Master all four modules and achieve your target band score.',
    url: 'https://www.abobakracademy.com/topics/ielts-preparation',
    siteName: 'Abobakr Academy',
    type: 'website',
  },
  alternates: {
    canonical: 'https://www.abobakracademy.com/topics/ielts-preparation',
  },
}

export default function IeltsPreparationPage() {
  return <IeltsClient />
}
