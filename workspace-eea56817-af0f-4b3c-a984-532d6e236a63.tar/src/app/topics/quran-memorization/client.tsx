'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  BookMarked,
  Brain,
  RefreshCw,
  Award,
  Globe,
  Heart,
  ArrowLeft,
  Target,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'

const topicData = {
  name: 'Quran Memorization (Hifz) Program',
  category: 'Islamic Studies',
  rating: 5.0,
  students: 120,
  lessons: 400,
  description: 'Achieve the blessed goal of memorizing the Holy Quran with our structured Hifz program. Our certified Qaris guide you through proven memorization techniques, personalized revision schedules, and continuous support to help you commit the Quran to memory.',
  highlights: [
    'Certified Huffaz with Ijazah',
    'Structured Memorization Plan',
    'Daily Revision Schedule',
    'Progress Tracking System',
    'One-on-One Sessions',
    'All Ages Welcome',
    'Flexible Timing',
    'Retention Techniques',
  ],
  stages: [
    {
      name: 'New Memorization (Sabaq)',
      description: 'Learn new verses daily with proper tajweed and understanding. Our method ensures you memorize correctly from the first attempt, avoiding mistakes that require unlearning later.',
      details: ['Daily new lesson', 'Tajweed correction', 'Meaning context', 'Connection to previous verses'],
    },
    {
      name: 'Recent Review (Sabaqi)',
      description: 'Review the most recently memorized portion (last 10-20 pages) to strengthen new memories before they fade. This daily review is crucial for retention.',
      details: ['Daily review', 'Fluency check', 'Mistake correction', 'Strengthening memory'],
    },
    {
      name: 'Old Review (Manzil)',
      description: 'Systematic review of previously memorized surahs/juz to ensure long-term retention. Follow a structured cycle to review the entire Quran regularly.',
      details: ['Weekly cycles', 'Juz-by-juz review', 'Long-term retention', 'Perfecting recitation'],
    },
    {
      name: 'Assessment & Testing',
      description: 'Regular assessments to track progress and identify areas needing attention. Prepare for recitation before teachers and eventual Ijazah pursuit.',
      details: ['Weekly testing', 'Progress reports', 'Parent updates', 'Milestone celebrations'],
    },
  ],
}

const faqData = [
  {
    question: 'How long does it take to memorize the entire Quran?',
    answer: 'The time required for complete Hifz varies based on age, dedication, and prior Quran knowledge. On average, students memorize the entire Quran in 2-4 years with consistent daily lessons. Children typically progress faster than adults due to stronger memory. Some dedicated students complete Hifz in 1.5 years, while others taking a slower pace may need 5 years. We create realistic timelines based on your situation.',
  },
  {
    question: 'What is the best age to start Quran memorization?',
    answer: 'The ideal age to start Hifz is between 6-12 years old when memory is strongest. However, we have successful Hifz students of all ages, from young children to adults in their 50s and beyond. Children have the advantage of flexible schedules and strong memory, while adults bring discipline and understanding. It\'s never too late to start your Hifz journey.',
  },
  {
    question: 'How much time do I need to dedicate daily for Hifz?',
    answer: 'For steady progress, students should dedicate 1-2 hours daily to Hifz activities. This includes the lesson with the teacher (30-60 minutes) plus independent memorization and revision time. Students who can dedicate more time progress faster. We work with your schedule to create a realistic plan, whether you\'re a student, working professional, or parent.',
  },
  {
    question: 'What if I have already memorized some Quran?',
    answer: 'Many students come to us with partial memorization from madrasah or self-study. We assess your current level, identify any mistakes in previously memorized portions, and create a plan that builds on what you know. We help strengthen weak areas before moving forward, ensuring a solid foundation for continued memorization.',
  },
  {
    question: 'How do you help with forgetting previously memorized Quran?',
    answer: 'Forgetting is natural and happens to every Hafiz. Our structured revision system (Sabaqi and Manzil) is designed to combat this. We follow the principle that new memorization without revision leads to loss, while revision without new memorization leads to weakness. Our balanced approach ensures you retain what you\'ve learned while making steady progress.',
  },
  {
    question: 'Can adults successfully memorize the Quran online?',
    answer: 'Absolutely! Many adults have completed Hifz with us while working full-time jobs. Adult learners often have better discipline and understanding of Arabic meanings, which helps with memorization. The key is consistency and following the teacher\'s guidance. We offer flexible scheduling for working professionals and can adjust pace based on your capacity.',
  },
  {
    question: 'What qualifications do your Hifz teachers have?',
    answer: 'Our Hifz teachers are certified Huffaz who have memorized the entire Quran and hold Ijazah (authorization to teach). They have extensive experience teaching students of all ages and understand the psychology of memorization. Many have completed Hifz themselves at young ages and now dedicate their lives to helping others achieve this noble goal.',
  },
  {
    question: 'How do online Hifz classes work compared to in-person?',
    answer: 'Online Hifz classes offer several advantages: one-on-one attention without distractions, flexible scheduling, learning from qualified teachers regardless of location, and parent involvement in children\'s progress. Students hear the teacher clearly and can focus without classroom distractions. Many parents find online classes more effective than crowded madrasah settings.',
  },
]

export default function HifzClient() {
  const courseSchemaData = {
    name: topicData.name,
    description: topicData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/topics/quran-memorization',
    category: 'Islamic Education',
    rating: topicData.rating,
    reviewCount: topicData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Quran', url: 'https://www.abobakracademy.com/courses/quran' },
    { name: 'Quran Memorization', url: 'https://www.abobakracademy.com/topics/quran-memorization' },
  ]

  return (
    <main className="min-h-screen bg-white">
      <FAQSchema faqs={faqData} courseName="Quran Memorization" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Quran Memorization (Hifz) Program"
        subtitle="Structured online Hifz program with certified Huffaz"
        breadcrumb="Quran / Hifz Program"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.students}+</p>
              <p className="text-white/70 text-sm">Hifz Students</p>
            </div>
            <div className="text-center">
              <BookMarked className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">50+</p>
              <p className="text-white/70 text-sm">Completed Huffaz</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <Award className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">30+</p>
              <p className="text-white/70 text-sm">Certified Teachers</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Link */}
          <Link
            href="/courses/quran"
            className="inline-flex items-center gap-2 text-[#1DA678] hover:text-[#168a60] mb-6 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Quran Course
          </Link>

          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Islamic Studies</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {topicData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {topicData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {topicData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Hifz Stages */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Our Hifz Method</h2>
              <div className="space-y-6">
                {topicData.stages.map((stage, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-[#E8F8F2] rounded-xl flex items-center justify-center flex-shrink-0">
                          <span className="text-[#1DA678] font-bold text-lg">{index + 1}</span>
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">{stage.name}</h3>
                          <p className="text-gray-600 text-sm md:text-base mb-3">{stage.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {stage.details.map((detail, i) => (
                              <Badge key={i} variant="outline" className="text-xs">{detail}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Memorize Quran with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Memorizing the Holy Quran is one of the greatest achievements a Muslim can pursue. The Quran
                    will intercede for its companion on the Day of Judgment, and the Hafiz holds a noble status
                    in this life and the hereafter. Our Hifz program makes this blessed journey accessible to
                    students worldwide.
                  </p>
                  <p>
                    What distinguishes our approach is the combination of traditional memorization methods with
                    modern online convenience. Our certified Huffaz understand that every student is unique—some
                    memorize quickly, others need more time; some have flexible schedules, others juggle work or
                    school. We adapt our teaching to your situation while maintaining the rigorous standards
                    required for proper Hifz.
                  </p>
                  <p>
                    Parents particularly appreciate our progress tracking system. You receive regular updates on
                    your child&apos;s memorization progress, areas needing attention, and revision schedule. This
                    partnership between teacher, student, and parent creates the supportive environment essential
                    for successful Hifz.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Start Your Hifz Journey</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Book a free assessment to evaluate your current level and create your personalized Hifz plan.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Target className="w-4 h-4 text-[#1DA678]" />
                      <span>Personalized plan</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Assessment
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;My son memorized 15 Juz in just one year! The structured approach and patient teachers made all the difference. The revision system ensures he never forgets what he learned.&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Ahmed&apos;s Father</p>
                  <p className="text-xs md:text-sm text-gray-600">Parent of Hifz Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Hifz"
        subtitle="Everything you need to know about memorizing the Quran online"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Begin Your Hifz Journey Today
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join hundreds of students who have memorized the Quran with our expert guidance.
            Take the first step toward this blessed achievement.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Assessment
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
