import { Metadata } from 'next'
import HifzClient from './client'

export const metadata: Metadata = {
  title: 'Quran Memorization Course (Hifz) Online | Learn to Memorize Quran',
  description: 'Structured online Quran memorization (Hifz) program with certified Qaris. Learn proven memorization techniques, revision schedules, and achieve your Hifz goals from home.',
  keywords: 'Quran memorization, Hifz online, memorize Quran, Quran Hifz program, online Hifz classes, Quran memorization for kids, Hifz for adults',
  openGraph: {
    title: 'Quran Memorization Course (Hifz) Online | Abobakr Academy',
    description: 'Structured online Quran memorization program with certified Qaris. Learn proven memorization techniques and achieve your Hifz goals.',
    url: 'https://www.abobakracademy.com/topics/quran-memorization',
    siteName: 'Abobakr Academy',
    type: 'website',
  },
  alternates: {
    canonical: 'https://www.abobakracademy.com/topics/quran-memorization',
  },
}

export default function QuranMemorizationPage() {
  return <HifzClient />
}
