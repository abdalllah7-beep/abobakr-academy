'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Calculator,
  TrendingUp,
  Globe,
  Award,
  Heart,
  ArrowLeft,
  Sigma,
  GitBranch,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'

const topicData = {
  name: 'Algebra Tutoring',
  category: 'Mathematics',
  rating: 4.9,
  students: 75,
  lessons: 280,
  description: 'Master algebra concepts from basic equations to advanced functions with our expert tutors. Whether you\'re struggling with linear equations or preparing for advanced math courses, our personalized one-on-one algebra tutoring will help you build confidence and achieve your goals.',
  highlights: [
    'All Algebra Levels',
    'Step-by-Step Methods',
    'Word Problem Strategies',
    'Graphing Techniques',
    'Test Preparation',
    'Homework Help',
    'Confidence Building',
    'Flexible Scheduling',
  ],
  topics: [
    {
      name: 'Pre-Algebra Foundations',
      icon: Calculator,
      description: 'Build essential skills including operations with integers, fractions, decimals, order of operations, and basic equation solving. Perfect preparation for Algebra 1.',
      concepts: ['Integer operations', 'Fractions & decimals', 'Variables introduction', 'Order of operations', 'Basic equations'],
    },
    {
      name: 'Algebra 1',
      icon: Sigma,
      description: 'Master linear equations, inequalities, functions, systems of equations, and polynomials. Build the foundation for all future mathematics courses.',
      concepts: ['Linear equations', 'Inequalities', 'Functions', 'Systems of equations', 'Polynomials', 'Factoring'],
    },
    {
      name: 'Algebra 2',
      icon: GitBranch,
      description: 'Advance to quadratic functions, complex numbers, logarithms, conic sections, and matrices. Prepare for pre-calculus and advanced math.',
      concepts: ['Quadratic functions', 'Complex numbers', 'Logarithms', 'Rational expressions', 'Conic sections', 'Sequences & series'],
    },
    {
      name: 'College Algebra',
      icon: TrendingUp,
      description: 'Comprehensive college-level algebra covering functions, graphs, exponential and logarithmic functions, and advanced equation solving.',
      concepts: ['Advanced functions', 'Exponential functions', 'Logarithmic functions', 'Matrix algebra', 'Mathematical modeling'],
    },
  ],
}

const faqData = [
  {
    question: 'What algebra topics do you cover?',
    answer: 'We cover the complete algebra curriculum from Pre-Algebra through College Algebra. This includes integer operations and basic equations, linear equations and inequalities, systems of equations, polynomials and factoring, quadratic functions, rational expressions, radical expressions, exponential and logarithmic functions, and more. We align with your specific curriculum, whether it\'s Common Core, IB, A-Levels, or another program.',
  },
  {
    question: 'How do you help students who struggle with algebra?',
    answer: 'Algebra struggles often stem from gaps in foundational skills. We identify these gaps through assessment and rebuild understanding step by step. Our approach focuses on conceptual understanding rather than memorizing procedures. When students understand WHY algebra works, they gain confidence and can solve unfamiliar problems. We use visual aids, real-world examples, and plenty of practice to build mastery.',
  },
  {
    question: 'Can you help with algebra homework and test preparation?',
    answer: 'Absolutely! Homework help and test preparation are core parts of our tutoring. For homework, we guide students through problems while ensuring they understand the process—not just copying answers. For tests, we review key concepts, practice problem types that commonly appear, teach test-taking strategies, and build confidence through practice tests. Many students see significant grade improvements within weeks.',
  },
  {
    question: 'How long does it take to improve algebra skills?',
    answer: 'Most students see noticeable improvement within 4-6 weeks of regular sessions. Significant grade improvements (one to two letter grades) typically occur within 2-3 months. However, the timeline depends on your starting point, session frequency, and practice outside tutoring. Students who dedicate time to practice between sessions improve fastest. We provide practice problems and resources for independent work.',
  },
  {
    question: 'Do you prepare students for algebra exams?',
    answer: 'Yes! We prepare students for all algebra-related exams including end-of-course exams, semester finals, standardized tests (SAT, ACT, GRE), and placement tests. Our exam preparation includes concept review, problem-solving strategies, time management techniques, and practice with actual exam questions. Students feel confident and prepared on test day.',
  },
  {
    question: 'What makes your algebra tutoring effective?',
    answer: 'Our effectiveness comes from combining three elements: expert tutors who understand both algebra and teaching methods, personalized instruction that adapts to each student\'s learning style, and a focus on conceptual understanding that creates lasting mastery. We don\'t just teach procedures—we help students understand the logic behind algebra, which builds problem-solving skills that transfer to all areas of mathematics.',
  },
  {
    question: 'Can you help adult learners returning to algebra?',
    answer: 'Absolutely! Many adults return to algebra for college courses, career advancement, or personal development. Our tutors are experienced with adult learners and understand the unique challenges of returning to mathematics after years away. We create judgment-free environments where adults feel comfortable asking questions and learning at their own pace.',
  },
  {
    question: 'What technology do you use for online algebra tutoring?',
    answer: 'We use digital whiteboards where both tutor and student can write equations in real-time, screen sharing for textbook and worksheet review, and graphing tools to visualize functions and equations. Students only need a computer or tablet with internet access. Our technology makes online algebra tutoring as effective as in-person sessions.',
  },
]

export default function AlgebraClient() {
  const courseSchemaData = {
    name: topicData.name,
    description: topicData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/topics/algebra-tutoring',
    category: 'Mathematics Tutoring',
    rating: topicData.rating,
    reviewCount: topicData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Mathematics', url: 'https://www.abobakracademy.com/courses/mathematics' },
    { name: 'Algebra Tutoring', url: 'https://www.abobakracademy.com/topics/algebra-tutoring' },
  ]

  return (
    <main className="min-h-screen bg-white">
      <FAQSchema faqs={faqData} courseName="Algebra Tutoring" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Online Algebra Tutoring"
        subtitle="Master algebra concepts with expert one-on-one instruction"
        breadcrumb="Mathematics / Algebra"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.students}+</p>
              <p className="text-white/70 text-sm">Algebra Students</p>
            </div>
            <div className="text-center">
              <Calculator className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <TrendingUp className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">92%</p>
              <p className="text-white/70 text-sm">Grade Improvement</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Link */}
          <Link
            href="/courses/mathematics"
            className="inline-flex items-center gap-2 text-[#1DA678] hover:text-[#168a60] mb-6 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Mathematics Course
          </Link>

          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Mathematics</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {topicData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {topicData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {topicData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Algebra Topics */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Algebra Levels We Cover</h2>
              <div className="space-y-6">
                {topicData.topics.map((topic, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-[#E8F8F2] rounded-xl flex items-center justify-center flex-shrink-0">
                          <topic.icon className="w-6 h-6 text-[#1DA678]" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">{topic.name}</h3>
                          <p className="text-gray-600 text-sm md:text-base mb-3">{topic.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {topic.concepts.map((concept, i) => (
                              <Badge key={i} variant="outline" className="text-xs">{concept}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Choose Our Algebra Tutoring?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Algebra is the gateway to advanced mathematics and STEM careers. Yet many students struggle
                    with algebra because it introduces abstract thinking that requires a new way of understanding
                    numbers and operations. Our tutoring transforms algebra from a source of frustration into
                    a subject of confidence and even enjoyment.
                  </p>
                  <p>
                    Our approach focuses on building conceptual understanding rather than rote memorization.
                    When you understand WHY algebraic rules work, you can apply them to any problem, not just
                    ones you&apos;ve seen before. This deeper understanding creates lasting mastery that serves
                    students through advanced math courses and beyond.
                  </p>
                  <p>
                    With a 92% grade improvement rate, our algebra tutoring delivers results. Students who once
                    dreaded math class develop problem-solving confidence that transfers to all areas of study.
                    Whether you&apos;re catching up, keeping up, or getting ahead, our personalized approach will
                    help you achieve your algebra goals.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Start Improving Today</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Book a free trial session to experience our algebra tutoring and discuss your goals.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>92% grade improvement</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;I went from failing Algebra 2 to getting an A on my final exam! My tutor explained everything in a way that finally made sense. I actually enjoy algebra now!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Maria</p>
                  <p className="text-xs md:text-sm text-gray-600">High School Algebra Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Algebra Tutoring"
        subtitle="Everything you need to know about learning algebra online"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Master Algebra?
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Book your free trial today and start building algebra confidence.
            Join the 92% of students who improve their grades.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
