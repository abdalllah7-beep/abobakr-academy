import { Metadata } from 'next'
import AlgebraClient from './client'

export const metadata: Metadata = {
  title: 'Online Algebra Tutoring | Learn Algebra from Expert Tutors',
  description: 'Expert online algebra tutoring for all levels. Master linear equations, quadratic functions, polynomials, and advanced algebra concepts with personalized one-on-one instruction.',
  keywords: 'algebra tutoring, algebra help, learn algebra online, algebra tutor, linear equations, quadratic functions, algebra for beginners',
  openGraph: {
    title: 'Online Algebra Tutoring | Abobakr Academy',
    description: 'Expert online algebra tutoring for all levels. Master linear equations, quadratic functions, and more.',
    url: 'https://www.abobakracademy.com/topics/algebra-tutoring',
    siteName: 'Abobakr Academy',
    type: 'website',
  },
  alternates: {
    canonical: 'https://www.abobakracademy.com/topics/algebra-tutoring',
  },
}

export default function AlgebraTutoringPage() {
  return <AlgebraClient />
}
