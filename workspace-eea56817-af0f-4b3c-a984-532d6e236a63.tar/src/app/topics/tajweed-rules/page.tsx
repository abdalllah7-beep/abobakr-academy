import { Metadata } from 'next'
import TajweedClient from './client'

export const metadata: Metadata = {
  title: 'Learn Tajweed Rules Online | Quran Pronunciation Course',
  description: 'Master Tajweed rules with certified Qaris. Learn Makharij, Sifaat, Ghunna, Madd, and proper Quranic pronunciation. Improve your recitation with expert guidance.',
  keywords: 'Tajweed rules, learn Tajweed online, Quran pronunciation, Makharij, Sifaat, Tajweed for beginners, Quran recitation',
  openGraph: {
    title: 'Learn Tajweed Rules Online | Abobakr Academy',
    description: 'Master Tajweed rules with certified Qaris. Learn proper Quranic pronunciation and improve your recitation.',
    url: 'https://www.abobakracademy.com/topics/tajweed-rules',
    siteName: 'Abobakr Academy',
    type: 'website',
  },
  alternates: {
    canonical: 'https://www.abobakracademy.com/topics/tajweed-rules',
  },
}

export default function TajweedRulesPage() {
  return <TajweedClient />
}
