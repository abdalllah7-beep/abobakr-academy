'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  BookOpen,
  Mic,
  Ear,
  Globe,
  Award,
  Heart,
  ArrowLeft,
  Volume2,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'

const topicData = {
  name: 'Tajweed Rules Course',
  category: 'Islamic Studies',
  rating: 5.0,
  students: 150,
  lessons: 350,
  description: 'Master the science of Tajweed with our comprehensive course. Learn proper Quranic pronunciation, articulation points (Makharij), letter attributes (Sifaat), and all essential rules to recite the Quran beautifully and correctly as it was revealed.',
  highlights: [
    'Certified Qaris with Ijazah',
    'All Tajweed Rules Covered',
    'Practical Application Focus',
    'Makharij Training',
    'Sifaat Mastery',
    'Recording & Feedback',
    'All Levels Welcome',
    'Flexible Scheduling',
  ],
  modules: [
    {
      name: 'Makharij al-Huruf (Articulation Points)',
      icon: Mic,
      description: 'Learn the exact points where each Arabic letter originates. Understand the 17 articulation points and master correct pronunciation of every letter.',
      topics: ['Throat letters', 'Tongue letters', 'Lip letters', 'Nasal cavity', 'Common mistakes'],
    },
    {
      name: 'Sifaat al-Huruf (Letter Attributes)',
      icon: Ear,
      description: 'Understand the characteristics that distinguish letters sharing the same articulation point. Master the qualities that give each letter its unique sound.',
      topics: ['Permanent attributes', 'Temporary attributes', 'Strong vs weak letters', 'Elevation vs lowering', 'Whispered vs voiced'],
    },
    {
      name: 'Rules of Noon Sakinah & Tanween',
      icon: Volume2,
      description: 'Master the four rules: Izhar, Idgham, Iqlab, and Ikhfa. Learn when to pronounce clearly, merge, flip, or hide the Noon sound.',
      topics: ['Izhar (clear)', 'Idgham (merging)', 'Iqlab (flipping)', 'Ikhfa (hiding)', 'Practice examples'],
    },
    {
      name: 'Rules of Meem Sakinah',
      icon: BookOpen,
      description: 'Learn the three rules of Meem Sakinah: Izhar Shafawi, Idgham Shafawi, and Ikhfa Shafawi with practical application.',
      topics: ['Izhar Shafawi', 'Idgham Shafawi', 'Ikhfa Shafawi', 'Practice drills', 'Common errors'],
    },
  ],
}

const faqData = [
  {
    question: 'What is Tajweed and why is it important?',
    answer: 'Tajweed is the science of reciting the Quran correctly, giving each letter its proper pronunciation from its correct point of articulation with all its attributes. Learning Tajweed is important because incorrect pronunciation can change the meaning of Quranic words. It is a religious duty to recite the Quran as it was revealed, and Tajweed ensures we honor the sacred text properly.',
  },
  {
    question: 'How long does it take to learn Tajweed?',
    answer: 'The time to learn Tajweed varies based on prior Quran knowledge and practice dedication. Most students grasp the fundamentals in 3-6 months of regular lessons. Achieving proficiency and beautiful recitation typically takes 6-12 months. Mastery continues throughout life as students refine their skills. Consistent practice between lessons accelerates progress significantly.',
  },
  {
    question: 'Do I need to know Arabic to learn Tajweed?',
    answer: 'No, you don\'t need to know Arabic language to learn Tajweed. Tajweed focuses on pronunciation rules, not meaning or grammar. Many successful Tajweed students are non-Arabic speakers. However, understanding the Arabic alphabet is necessary—we teach this to beginners before moving to Tajweed rules.',
  },
  {
    question: 'Can children learn Tajweed online?',
    answer: 'Absolutely! Children often learn Tajweed faster than adults due to their ability to mimic sounds accurately. Our teachers use child-friendly methods including repetition, games, and positive reinforcement. Many children as young as 6-7 years old have successfully learned proper Tajweed through our online program.',
  },
  {
    question: 'What is the difference between Tajweed and just reading Quran?',
    answer: 'Reading Quran without Tajweed may involve pronunciation errors that affect meaning. Tajweed teaches the rules that the Prophet (peace be upon him) taught his companions—proper articulation points, letter characteristics, and rules for combining sounds. Tajweed transforms recitation from mere reading to beautiful, correct recitation as the Quran was revealed.',
  },
  {
    question: 'How do online Tajweed classes work?',
    answer: 'Online Tajweed classes are conducted one-on-one via Zoom or Google Meet. The teacher recites for the student to hear correct pronunciation, then the student recites while the teacher listens and corrects. Screen sharing allows teachers to display Tajweed charts and marked Quran pages. Recording lessons helps students practice between sessions.',
  },
  {
    question: 'What are common Tajweed mistakes people make?',
    answer: 'Common mistakes include incorrect articulation points (especially throat letters), not distinguishing between similar letters (like ض and ظ), improper Nun rules application, incorrect Madd (elongation) lengths, and not applying Ghunna (nasal sound) correctly. Our teachers identify your specific mistakes and help you correct them systematically.',
  },
  {
    question: 'Will I receive a certificate after completing Tajweed?',
    answer: 'Yes, students who complete our Tajweed course and demonstrate proficiency receive a certificate of completion. For advanced students seeking Ijazah (authorization to teach), we offer specialized programs with certified scholars. Ijazah programs require more intensive study and assessment.',
  },
]

export default function TajweedClient() {
  const courseSchemaData = {
    name: topicData.name,
    description: topicData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/topics/tajweed-rules',
    category: 'Islamic Education',
    rating: topicData.rating,
    reviewCount: topicData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Tajweed', url: 'https://www.abobakracademy.com/courses/tajweed' },
    { name: 'Tajweed Rules', url: 'https://www.abobakracademy.com/topics/tajweed-rules' },
  ]

  return (
    <main className="min-h-screen bg-white">
      <FAQSchema faqs={faqData} courseName="Tajweed Rules" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Tajweed Rules Course"
        subtitle="Master Quranic pronunciation with certified Qaris"
        breadcrumb="Tajweed / Tajweed Rules"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.students}+</p>
              <p className="text-white/70 text-sm">Tajweed Students</p>
            </div>
            <div className="text-center">
              <BookOpen className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{topicData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <Award className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">40+</p>
              <p className="text-white/70 text-sm">Certified Qaris</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Link */}
          <Link
            href="/courses/tajweed"
            className="inline-flex items-center gap-2 text-[#1DA678] hover:text-[#168a60] mb-6 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Tajweed Course
          </Link>

          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Islamic Studies</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {topicData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {topicData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {topicData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Tajweed Modules */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Tajweed Modules We Cover</h2>
              <div className="space-y-6">
                {topicData.modules.map((module, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-[#E8F8F2] rounded-xl flex items-center justify-center flex-shrink-0">
                          <module.icon className="w-6 h-6 text-[#1DA678]" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">{module.name}</h3>
                          <p className="text-gray-600 text-sm md:text-base mb-3">{module.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {module.topics.map((topic, i) => (
                              <Badge key={i} variant="outline" className="text-xs">{topic}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn Tajweed with Us?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    The Quran was revealed with Tajweed—the Angel Jibreel recited it to the Prophet (peace be
                    upon him) with proper pronunciation, and the Prophet taught his companions the same way.
                    Learning Tajweed connects you to this unbroken chain of correct recitation.
                  </p>
                  <p>
                    Our certified Qaris have studied Tajweed extensively and hold Ijazah (authorization) to
                    teach. They understand that learning Tajweed is not just about rules—it&apos;s about
                    developing an ear for correct recitation and building muscle memory for proper
                    pronunciation. Our practical approach ensures you apply what you learn immediately.
                  </p>
                  <p>
                    Whether you&apos;re a complete beginner or looking to refine your existing recitation,
                    our personalized one-on-one classes adapt to your needs. Many students tell us that
                    after learning Tajweed, they hear the Quran differently and connect with it more deeply.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Start Learning Tajweed</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Book a free trial session to experience our Tajweed teaching methodology.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Personalized assessment</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>Certified instructors</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;I never realized how many mistakes I was making until I learned Tajweed properly. Now my recitation is completely different—more beautiful and confident. The teachers are incredibly patient and knowledgeable.&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Yusuf</p>
                  <p className="text-xs md:text-sm text-gray-600">Tajweed Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Tajweed"
        subtitle="Everything you need to know about learning Tajweed online"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Perfect Your Quran Recitation
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join hundreds of students who have transformed their Quran recitation through our Tajweed course.
            Book your free trial today.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
