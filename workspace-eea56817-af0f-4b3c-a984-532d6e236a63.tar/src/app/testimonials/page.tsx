import { Metadata } from 'next'
import TestimonialsClient from './client'

export const metadata: Metadata = {
  title: 'Student Testimonials | Abobakr Academy - Real Reviews from Happy Students',
  description: 'Read authentic testimonials from students and parents who have experienced our online tutoring services. See why families trust Abobakr Academy for Quran, languages, math, science, and more.',
  keywords: 'online tutoring reviews, student testimonials, tutor reviews, abobakr academy reviews, quran class reviews, online education testimonials, private tutor feedback',
  openGraph: {
    title: 'Student Testimonials | Abobakr Academy',
    description: 'Real feedback from students and parents about our online tutoring services.',
    type: 'website',
  },
}

export default function TestimonialsPage() {
  return <TestimonialsClient />
}
