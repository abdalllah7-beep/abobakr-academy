'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Star,
  Calendar,
  MessageCircle,
  ArrowRight,
  Quote,
  PenLine,
  X,
  CheckCircle2,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

// All subjects organized by category
const subjectCategories = [
  {
    label: 'Islamic Studies',
    items: [
      { value: 'Quran & Tajweed', label: 'Quran & Tajweed' },
      { value: 'Tajweed', label: 'Tajweed' },
      { value: "Qa'ida", label: "Qa'ida (Arabic Alphabet)" },
      { value: 'Islamic Studies', label: 'Islamic Studies' },
    ]
  },
  {
    label: 'Languages',
    items: [
      { value: 'Arabic', label: 'Arabic Language' },
      { value: 'English', label: 'English Language' },
      { value: 'German', label: 'German Language' },
      { value: 'French', label: 'French Language' },
      { value: 'Spanish', label: 'Spanish Language' },
      { value: 'Italian', label: 'Italian Language' },
    ]
  },
  {
    label: 'School Support',
    items: [
      { value: 'Mathematics', label: 'Mathematics' },
      { value: 'Physics', label: 'Physics' },
      { value: 'Chemistry', label: 'Chemistry' },
      { value: 'Biology', label: 'Biology' },
      { value: 'Science', label: 'Science (General)' },
      { value: 'Geography', label: 'Geography' },
      { value: 'History', label: 'History' },
      { value: 'Social Studies', label: 'Social Studies' },
    ]
  },
  {
    label: 'Digital Skills',
    items: [
      { value: 'ICDL', label: 'ICDL Certification' },
      { value: 'Programming', label: 'Programming' },
      { value: 'Microsoft Office', label: 'Microsoft Office' },
    ]
  },
]

const testimonials = [
  {
    name: 'Farah',
    role: 'Quran Student',
    course: 'Quran & Tajweed',
    text: 'Great efforts! I feel like reading Quran for the first time! The teacher explains everything clearly and patiently. I never thought I could improve this much in such a short time.',
    rating: 5,
    date: 'Recent'
  },
  {
    name: "Adam & Amin's Mom",
    role: 'Parent',
    course: 'English',
    text: 'The class was amazing, my kids loved the teacher so much! They look forward to every session now. The interactive teaching method keeps them engaged throughout.',
    rating: 5,
    date: 'Recent'
  },
  {
    name: "Mohamed's Mom",
    role: 'Parent',
    course: 'English',
    text: 'I really want to thank you for your cooperation. You\'re the best! My son\'s grades improved significantly after just a few weeks of tutoring.',
    rating: 5,
    date: 'Recent'
  },
  {
    name: "Ali's Mom",
    role: 'Parent',
    course: 'Arabic',
    text: 'The teacher is excellent and patient. My son has improved so much in Arabic reading and writing! He now enjoys Arabic classes at school too.',
    rating: 5,
    date: 'Recent'
  },
  {
    name: 'Sarah',
    role: 'Student',
    course: 'Physics',
    text: 'Physics finally makes sense! The tutor breaks down complex concepts into simple explanations. Highly recommend! My grades went from C to A in two months.',
    rating: 5,
    date: 'Recent'
  },
  {
    name: 'Hassan',
    role: 'Student',
    course: 'German',
    text: 'Passed my Goethe B1 exam thanks to this course! The structured approach really helped me succeed. The practice sessions were incredibly valuable.',
    rating: 5,
    date: 'Recent'
  },
  {
    name: 'Fatima',
    role: 'Student',
    course: 'Chemistry',
    text: 'Chemistry became my favorite subject! The interactive sessions and practice problems made all the difference. I finally understand organic chemistry!',
    rating: 5,
    date: 'Recent'
  },
  {
    name: 'Omar',
    role: 'Student',
    course: 'Mathematics',
    text: 'My math grades went from C to A in just two months! The personalized attention really works. The tutor identified my weak areas and focused on them.',
    rating: 5,
    date: 'Recent'
  },
  {
    name: 'Aisha',
    role: 'Parent',
    course: 'Quran',
    text: 'My daughter has memorized 5 Juz in 6 months! The Hafiza teacher is incredibly patient and knows how to motivate children. Best decision we made.',
    rating: 5,
    date: '2 months ago'
  },
  {
    name: 'Yusuf',
    role: 'Student',
    course: 'IELTS Prep',
    text: 'Achieved my target band score of 7.5! The practice tests and feedback were invaluable. The tutor knew exactly what I needed to work on.',
    rating: 5,
    date: '2 months ago'
  },
  {
    name: 'Layla',
    role: 'Parent',
    course: 'French',
    text: 'My kids now speak French at home! The immersion technique really works. They look forward to every lesson and practice on their own.',
    rating: 5,
    date: '2 months ago'
  },
  {
    name: 'Khalid',
    role: 'Student',
    course: 'Programming',
    text: 'Started with zero coding knowledge and now I can build my own websites! The hands-on projects were amazing. Highly recommend for beginners.',
    rating: 5,
    date: '3 months ago'
  },
  {
    name: 'Amira',
    role: 'Student',
    course: 'Biology',
    text: 'The diagrams and visual explanations make Biology so much easier to understand. I aced my exams! The tutor knows how to make complex topics simple.',
    rating: 5,
    date: '3 months ago'
  },
  {
    name: 'Ahmed',
    role: 'Parent',
    course: 'Multiple Subjects',
    text: 'All three of my children take classes here. The quality is consistent across all subjects. It\'s been a game-changer for our family.',
    rating: 5,
    date: '3 months ago'
  },
  {
    name: 'Nour',
    role: 'Student',
    course: 'Arabic for Non-Natives',
    text: 'As a non-native speaker, learning Arabic seemed impossible. But with the right teacher and method, I can now read and write! Incredible progress.',
    rating: 5,
    date: '4 months ago'
  },
  {
    name: 'Rania',
    role: 'Parent',
    course: 'ICDL',
    text: 'My son got his ICDL certification thanks to this course. The structured curriculum and practice exams prepared him perfectly.',
    rating: 5,
    date: '4 months ago'
  },
  {
    name: 'Tariq',
    role: 'Student',
    course: 'English Conversation',
    text: 'My speaking confidence has improved dramatically. I no longer hesitate to speak English at work. The conversation practice was exactly what I needed.',
    rating: 5,
    date: '5 months ago'
  },
  {
    name: 'Huda',
    role: 'Parent',
    course: 'Tajweed',
    text: 'The tajweed rules are taught so systematically. My children now recite beautifully with proper makharij. The teacher is a true expert.',
    rating: 5,
    date: '5 months ago'
  },
  {
    name: 'Bilal',
    role: 'Student',
    course: 'Spanish',
    text: 'Learning Spanish for my job has opened so many doors. The tutor made it fun and practical. I can now hold conversations with Spanish speakers!',
    rating: 5,
    date: '6 months ago'
  },
  {
    name: 'Mariam',
    role: 'Student',
    course: 'IGCSE Math',
    text: 'Went from predicted C to achieving A* in IGCSE Math! The exam-focused approach and past paper practice made all the difference.',
    rating: 5,
    date: '6 months ago'
  },
]

const stats = [
  { value: '100+', label: 'Happy Students' },
  { value: '2,500+', label: 'Lessons Completed' },
  { value: '4.8/5', label: 'Average Rating' },
  { value: '50+', label: 'Expert Tutors' },
]

export default function TestimonialsClient() {
  const [showForm, setShowForm] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    course: '',
    otherCourse: '',
    text: '',
    rating: 5
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would send to a backend
    setSubmitted(true)
    setTimeout(() => {
      setShowForm(false)
      setSubmitted(false)
      setFormData({ name: '', role: '', course: '', otherCourse: '', text: '', rating: 5 })
    }, 3000)
  }

  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader
        title="Student Testimonials"
        subtitle="Real feedback from families who have experienced the Abobakr Academy difference"
        breadcrumb="Testimonials"
      />

      {/* Stats */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <p className="text-2xl md:text-4xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-white/80 text-sm md:text-base">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Write Testimonial Button */}
      <section className="py-8 bg-[#E8F8F2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Button
            size="lg"
            onClick={() => setShowForm(true)}
            className="bg-[#1DA678] hover:bg-[#168a60] text-white px-8 py-6 rounded-full"
          >
            <PenLine className="w-5 h-5 mr-2" />
            Share Your Experience
          </Button>
        </div>
      </section>

      {/* Testimonial Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <Card className="w-full max-w-lg max-h-[90vh] overflow-y-auto bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Share Your Testimonial</h3>
                <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              {submitted ? (
                <div className="text-center py-8">
                  <CheckCircle2 className="w-16 h-16 text-[#1DA678] mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">Thank You!</h4>
                  <p className="text-gray-600">Your testimonial has been submitted successfully. We appreciate your feedback!</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Your Name</label>
                    <Input
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">I am a...</label>
                    <Input
                      required
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                      placeholder="e.g., Student, Parent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Course/Subject</label>
                    <Select 
                      value={formData.course}
                      onValueChange={(value) => setFormData({ ...formData, course: value, otherCourse: '' })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a course" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[250px]">
                        {subjectCategories.map((category) => (
                          <div key={category.label}>
                            <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 bg-gray-50">
                              {category.label}
                            </div>
                            {category.items.map((item) => (
                              <SelectItem key={item.value} value={item.value}>
                                {item.label}
                              </SelectItem>
                            ))}
                          </div>
                        ))}
                        <div className="border-t mt-1 pt-1">
                          <SelectItem value="other">
                            <span className="text-[#1DA678] font-medium">Other (specify below)</span>
                          </SelectItem>
                        </div>
                      </SelectContent>
                    </Select>
                  </div>
                  {formData.course === 'other' && (
                    <div className="animate-in fade-in slide-in-from-top-2 duration-200">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Please specify *</label>
                      <Input
                        required
                        value={formData.otherCourse}
                        onChange={(e) => setFormData({ ...formData, otherCourse: e.target.value })}
                        placeholder="e.g., Economics, Psychology, etc."
                      />
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Rating</label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setFormData({ ...formData, rating: star })}
                          className="p-1"
                        >
                          <Star
                            className={`w-6 h-6 ${star <= formData.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Your Testimonial</label>
                    <Textarea
                      required
                      value={formData.text}
                      onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                      placeholder="Share your experience with Abobakr Academy..."
                      rows={4}
                    />
                  </div>
                  <Button type="submit" className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white">
                    Submit Testimonial
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Testimonials Grid */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">What They Say</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Real Stories from <span className="text-[#1DA678]">Real Families</span>
            </h2>
            <p className="text-base md:text-xl text-gray-600 max-w-2xl mx-auto">
              Don&apos;t just take our word for it. See what our students and parents have to say about their learning journey with us.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {testimonials.map((testimonial, index) => (
              <Card
                key={index}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white"
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      ))}
                    </div>
                    <Quote className="w-8 h-8 text-[#1DA678]/20" />
                  </div>

                  <p className="text-gray-600 mb-6 leading-relaxed text-sm md:text-base">&quot;{testimonial.text}&quot;</p>

                  <div className="pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-gray-900">{testimonial.name}</p>
                        <p className="text-xs text-gray-500">{testimonial.role}</p>
                      </div>
                      <div className="text-right">
                        <Badge variant="secondary" className="bg-[#E8F8F2] text-[#1DA678] text-xs">
                          {testimonial.course}
                        </Badge>
                        <p className="text-xs text-gray-400 mt-1">{testimonial.date}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
            Ready to Start Your Success Story?
          </h2>
          <p className="text-base md:text-xl text-white/70 mb-6 md:mb-8">
            Join hundreds of satisfied students and experience the Abobakr Academy difference.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button
              size="lg"
              className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button
              size="lg"
              className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
