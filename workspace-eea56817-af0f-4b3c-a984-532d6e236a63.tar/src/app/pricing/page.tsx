'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Check,
  Star,
  HelpCircle,
  ArrowRight,
  Calendar,
  MessageCircle,
  Phone,
  Clock,
  Users,
  Gift,
  Zap,
  Crown,
  Sparkles,
  GraduationCap,
  BookOpen,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const plans = [
  {
    name: 'Starter',
    icon: Zap,
    description: 'Perfect for students who need occasional tutoring support',
    sessions: '4 sessions/month',
    duration: '60 minutes each',
    features: [
      { text: '4 one-on-one sessions', included: true },
      { text: '60 minutes per session', included: true },
      { text: 'One subject focus', included: true },
      { text: 'Progress reports', included: true },
      { text: 'Flexible scheduling', included: true },
      { text: 'WhatsApp support', included: true },
      { text: 'Multiple subjects', included: false },
      { text: 'Priority booking', included: false },
    ],
    popular: false,
  },
  {
    name: 'Standard',
    icon: Star,
    description: 'Ideal for regular tutoring with consistent progress',
    sessions: '8 sessions/month',
    duration: '60 minutes each',
    features: [
      { text: '8 one-on-one sessions', included: true },
      { text: '60 minutes per session', included: true },
      { text: 'Up to 2 subjects', included: true },
      { text: 'Detailed progress reports', included: true },
      { text: 'Flexible scheduling', included: true },
      { text: 'WhatsApp & call support', included: true },
      { text: 'Priority booking', included: true },
      { text: 'Session recordings', included: false },
    ],
    popular: true,
  },
  {
    name: 'Premium',
    icon: Crown,
    description: 'Comprehensive tutoring for serious students',
    sessions: '16 sessions/month',
    duration: '60 minutes each',
    features: [
      { text: '16 one-on-one sessions', included: true },
      { text: '60 minutes per session', included: true },
      { text: 'Unlimited subjects', included: true },
      { text: 'Weekly progress reports', included: true },
      { text: '24/7 scheduling priority', included: true },
      { text: 'Dedicated support line', included: true },
      { text: 'Priority booking', included: true },
      { text: 'Session recordings', included: true },
    ],
    popular: false,
  },
]

const pricingFactors = [
  { icon: GraduationCap, title: 'Grade Level', description: 'Primary, secondary, or university level subjects have different pricing structures.' },
  { icon: BookOpen, title: 'Subject Type', description: 'Specialized subjects like advanced sciences or programming may differ from general subjects.' },
  { icon: Clock, title: 'Session Duration', description: 'Choose from 30, 45, or 60-minute sessions based on your learning needs.' },
  { icon: Calendar, title: 'Frequency', description: 'More sessions per month often come with discounted package rates.' },
]

const faqs = [
  {
    question: 'How is pricing determined?',
    answer: 'Our pricing depends on several factors including the grade level, subject complexity, session duration, and frequency of classes. We offer personalized quotes to ensure you get the best value for your specific learning needs.',
  },
  {
    question: 'Can I get a custom package?',
    answer: 'Absolutely! We understand that every student has unique needs. Contact us to discuss a custom package tailored to your schedule, subjects, and budget requirements.',
  },
  {
    question: 'What if I miss a session?',
    answer: 'We have a 24-hour cancellation policy. If you cancel at least 24 hours before your scheduled session, you can reschedule at no extra cost.',
  },
  {
    question: 'Are there any hidden fees?',
    answer: 'No hidden fees. The price you agree on includes everything - tutoring sessions, materials, progress reports, and support. What you see is what you pay.',
  },
  {
    question: 'Do you offer family discounts?',
    answer: 'Yes! We offer special discounts for families with multiple students. Contact us for more details on family packages and sibling discounts.',
  },
  {
    question: 'What payment methods do you accept?',
    answer: 'We accept credit/debit cards, PayPal, and bank transfers. We also offer flexible payment plans for long-term packages.',
  },
]

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader
        title="Pricing"
        subtitle="Flexible plans designed to fit your learning needs and budget"
        breadcrumb="Pricing"
      />

      {/* Pricing Cards */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Our Plans</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Choose Your <span className="text-[#1DA678]">Learning Plan</span>
            </h2>
            <p className="text-base md:text-xl text-gray-600 max-w-2xl mx-auto">
              We offer flexible packages tailored to your needs. Contact us for a personalized quote.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            {plans.map((plan, index) => (
              <Card
                key={index}
                className={`border-0 shadow-lg hover:shadow-xl transition-all duration-300 relative ${
                  plan.popular ? 'ring-2 ring-[#1DA678] scale-100 md:scale-105' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <Badge className="bg-[#1DA678] text-white px-4 py-1">
                      <Star className="w-3 h-3 mr-1 fill-current" />
                      Most Popular
                    </Badge>
                  </div>
                )}
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${plan.popular ? 'bg-[#1DA678]' : 'bg-gray-100'}`}>
                      <plan.icon className={`w-6 h-6 ${plan.popular ? 'text-white' : 'text-[#1DA678]'}`} />
                    </div>
                    <h3 className="text-xl md:text-2xl font-bold text-gray-900">{plan.name}</h3>
                  </div>
                  <p className="text-gray-600 text-sm md:text-base mb-4">{plan.description}</p>

                  <div className="bg-[#E8F8F2] rounded-xl p-4 mb-6">
                    <p className="text-[#1DA678] font-bold text-lg md:text-xl mb-2">Contact for Pricing</p>
                    <p className="text-gray-600 text-xs md:text-sm">Get a personalized quote based on your needs</p>
                  </div>

                  <div className="space-y-2 mb-4 md:mb-6">
                    <div className="flex items-center gap-2 text-sm md:text-base">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>{plan.sessions}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm md:text-base">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>{plan.duration}</span>
                    </div>
                  </div>

                  <div className="space-y-3 mb-6 md:mb-8">
                    {plan.features.map((feature, fIndex) => (
                      <div key={fIndex} className="flex items-center gap-3">
                        {feature.included ? (
                          <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                        ) : (
                          <div className="w-5 h-5 flex-shrink-0" />
                        )}
                        <span className={`text-sm ${feature.included ? 'text-gray-700' : 'text-gray-400'}`}>
                          {feature.text}
                        </span>
                      </div>
                    ))}
                  </div>

                  <Button
                    className={`w-full ${plan.popular ? 'bg-[#1DA678] hover:bg-[#168a60] text-white' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'}`}
                    asChild
                  >
                    <Link href="/contact#trial">
                      Get Quote
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Factors */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Flexible Pricing</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Factors That <span className="text-[#1DA678]">Affect Pricing</span>
            </h2>
            <p className="text-base md:text-xl text-gray-600 max-w-2xl mx-auto">
              Our pricing is personalized based on your specific requirements to ensure the best value.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {pricingFactors.map((factor, index) => (
              <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4">
                    <factor.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{factor.title}</h3>
                  <p className="text-gray-600 text-sm">{factor.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">All Plans Include</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              What You <span className="text-[#1DA678]">Get</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-4 gap-6 md:gap-8">
            {[
              { icon: Users, title: 'Expert Tutors', description: 'Learn from qualified, experienced educators' },
              { icon: Clock, title: 'Flexible Scheduling', description: 'Book sessions at times that suit you' },
              { icon: Gift, title: 'Free Trial', description: 'Try before you commit with a free session' },
              { icon: MessageCircle, title: 'Ongoing Support', description: 'Get help whenever you need it' },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-7 h-7 md:w-8 md:h-8 text-white" />
                </div>
                <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm md:text-base">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">FAQ</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Frequently Asked <span className="text-[#1DA678]">Questions</span>
            </h2>
          </div>

          <div className="space-y-4 md:space-y-6">
            {faqs.map((faq, index) => (
              <Card key={index} className="border-0 shadow-md">
                <CardContent className="p-4 md:p-6">
                  <div className="flex items-start gap-3 md:gap-4">
                    <HelpCircle className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678] flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">{faq.question}</h3>
                      <p className="text-gray-600 text-sm md:text-base">{faq.answer}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Sparkles className="w-12 h-12 text-white/80 mx-auto mb-4" />
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
            Get Your Personalized Quote Today
          </h2>
          <p className="text-base md:text-xl text-white/80 mb-6 md:mb-8">
            Contact us for a free consultation and we&apos;ll create the perfect learning package for you.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button
              size="lg"
              className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button
              size="lg"
              className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full shadow-lg"
              asChild
            >
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
