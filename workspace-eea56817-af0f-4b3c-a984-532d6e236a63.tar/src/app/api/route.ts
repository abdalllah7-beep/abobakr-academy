import { NextResponse } from "next/server";
import ZAI from 'z-ai-web-dev-sdk';

export async function GET() {
  try {
    const zai = await ZAI.create();

    const searchResult = await zai.functions.invoke("web_search", {
      query: "abobakracademy.com explore courses subjects offered",
      num: 10
    });

    return NextResponse.json({ 
      success: true,
      results: searchResult 
    });
  } catch (error: any) {
    console.error('Error:', error);
    return NextResponse.json({ 
      success: false,
      error: error.message 
    }, { status: 500 });
  }
}
