'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Phone,
  Mail,
  MessageCircle,
  Clock,
  Send,
  Calendar,
  CheckCircle2,
  Users,
  Globe,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

// All subjects organized by category
const subjectCategories = [
  {
    label: 'Islamic Studies',
    items: [
      { value: 'quran', label: 'Quran - Read, Recite & Memorize' },
      { value: 'tajweed', label: 'Tajweed' },
      { value: 'qaida', label: "Qa'ida (Arabic Alphabet)" },
      { value: 'islamic-studies', label: 'Islamic Studies' },
    ]
  },
  {
    label: 'Languages',
    items: [
      { value: 'arabic', label: 'Arabic Language' },
      { value: 'english', label: 'English Language' },
      { value: 'german', label: 'German Language' },
      { value: 'french', label: 'French Language' },
      { value: 'spanish', label: 'Spanish Language' },
      { value: 'italian', label: 'Italian Language' },
    ]
  },
  {
    label: 'School Support',
    items: [
      { value: 'mathematics', label: 'Mathematics' },
      { value: 'physics', label: 'Physics' },
      { value: 'chemistry', label: 'Chemistry' },
      { value: 'biology', label: 'Biology' },
      { value: 'science', label: 'Science (General)' },
      { value: 'geography', label: 'Geography' },
      { value: 'history', label: 'History' },
      { value: 'social-studies', label: 'Social Studies' },
    ]
  },
  {
    label: 'Digital Skills',
    items: [
      { value: 'icdl', label: 'ICDL Certification' },
      { value: 'programming', label: 'Programming' },
      { value: 'microsoft-office', label: 'Microsoft Office' },
    ]
  },
]

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    otherSubject: '',
    message: '',
  })

  const [trialForm, setTrialForm] = useState({
    name: '',
    phone: '',
    subject: '',
    otherSubject: '',
    time: '',
  })

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const finalSubject = formData.subject === 'other' ? formData.otherSubject : formData.subject
    console.log('Contact form submitted:', { ...formData, subject: finalSubject })
    alert('Thank you for your message! We will get back to you within 24 hours.')
    setFormData({ name: '', email: '', phone: '', subject: '', otherSubject: '', message: '' })
  }

  const handleTrialSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const finalSubject = trialForm.subject === 'other' ? trialForm.otherSubject : trialForm.subject
    console.log('Trial form submitted:', { ...trialForm, subject: finalSubject })
    alert('Thank you! We will contact you within 24 hours to schedule your free trial.')
    setTrialForm({ name: '', phone: '', subject: '', otherSubject: '', time: '' })
  }

  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader
        title="Contact Us"
        subtitle="Have questions? We're here to help. Reach out to us through any of the channels below."
        breadcrumb="Contact"
      />

      {/* Contact Info Cards */}
      <section className="py-8 md:py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-4 md:gap-6">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-[#E8F8F2] to-white">
              <CardContent className="p-6 md:p-8 text-center">
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-7 h-7 md:w-8 md:h-8 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">Phone / WhatsApp</h3>
                <a href="https://wa.me/966566518545" className="text-[#1DA678] font-bold text-lg md:text-xl hover:underline">
                  +966 56 651 8545
                </a>
                <p className="text-gray-500 text-sm mt-2">Available 8AM - 10PM (GMT+3)</p>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-lg bg-gradient-to-br from-[#E8F8F2] to-white">
              <CardContent className="p-6 md:p-8 text-center">
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-7 h-7 md:w-8 md:h-8 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">Email</h3>
                <a href="mailto:info@abobakracademy.com" className="text-[#1DA678] font-bold text-base md:text-lg hover:underline">
                  info@abobakracademy.com
                </a>
                <p className="text-gray-500 text-sm mt-2">We respond within 24 hours</p>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-lg bg-gradient-to-br from-[#E8F8F2] to-white">
              <CardContent className="p-6 md:p-8 text-center">
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-7 h-7 md:w-8 md:h-8 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">Website</h3>
                <a href="https://www.abobakracademy.com" target="_blank" rel="noopener noreferrer" className="text-[#1DA678] font-bold text-base md:text-lg hover:underline">
                  www.abobakracademy.com
                </a>
                <p className="text-gray-500 text-sm mt-2">Visit our main website</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Free Trial Section */}
      <section id="trial" className="py-12 md:py-20 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922] scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-10 md:gap-16 items-center">
            <div className="text-white text-center lg:text-left">
              <Badge className="mb-4 md:mb-6 bg-white/20 text-white border-0">
                <Calendar className="w-3 h-3 md:w-4 md:h-4 mr-2" />
                Free Trial
              </Badge>
              <h2 className="text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold mb-4 md:mb-6">
                Book Your <span className="text-[#4ADE80]">Free Trial</span> Class
              </h2>
              <p className="text-base md:text-xl text-white/80 mb-6 md:mb-8">
                Experience our teaching methodology first-hand. No payment required, just fill the form 
                and we&apos;ll contact you within 24 hours to schedule your session.
              </p>
              
              <div className="space-y-3 md:space-y-4">
                <p className="text-base md:text-lg font-medium text-white mb-2 md:mb-4">What&apos;s included:</p>
                {[
                  '30-minute personalized session',
                  'Assessment of current level',
                  'Customized learning plan',
                  'Meet your potential tutor',
                  'No commitment required',
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-3 justify-center lg:justify-start">
                    <CheckCircle2 className="w-5 h-5 md:w-6 md:h-6 text-[#4ADE80] flex-shrink-0" />
                    <span className="text-white/90 text-sm md:text-base">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <Card className="border-0 shadow-2xl bg-white">
              <CardContent className="p-5 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6 text-center">Book Your Free Trial</h3>
                <form onSubmit={handleTrialSubmit} className="space-y-3 md:space-y-4">
                  <div>
                    <Label htmlFor="trial-name" className="text-sm md:text-base">Your Name *</Label>
                    <Input
                      id="trial-name"
                      placeholder="Enter your full name"
                      value={trialForm.name}
                      onChange={(e) => setTrialForm({ ...trialForm, name: e.target.value })}
                      className="mt-1 h-10 md:h-12"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="trial-phone" className="text-sm md:text-base">Phone Number *</Label>
                    <Input
                      id="trial-phone"
                      type="tel"
                      placeholder="+966 5XX XXX XXXX"
                      value={trialForm.phone}
                      onChange={(e) => setTrialForm({ ...trialForm, phone: e.target.value })}
                      className="mt-1 h-10 md:h-12"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label className="text-sm md:text-base">Subject *</Label>
                    <Select 
                      value={trialForm.subject}
                      onValueChange={(value) => setTrialForm({ ...trialForm, subject: value, otherSubject: '' })}
                    >
                      <SelectTrigger className="mt-1 h-10 md:h-12">
                        <SelectValue placeholder="Select a subject" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px]">
                        {subjectCategories.map((category) => (
                          <div key={category.label}>
                            <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 bg-gray-50">
                              {category.label}
                            </div>
                            {category.items.map((item) => (
                              <SelectItem key={item.value} value={item.value}>
                                {item.label}
                              </SelectItem>
                            ))}
                          </div>
                        ))}
                        <div className="border-t mt-1 pt-1">
                          <SelectItem value="other">
                            <span className="text-[#1DA678] font-medium">Other (specify below)</span>
                          </SelectItem>
                        </div>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Other Subject Input - shows when "Other" is selected */}
                  {trialForm.subject === 'other' && (
                    <div className="animate-in fade-in slide-in-from-top-2 duration-200">
                      <Label htmlFor="trial-other-subject" className="text-sm md:text-base">Please specify the subject *</Label>
                      <Input
                        id="trial-other-subject"
                        placeholder="e.g., Economics, Psychology, etc."
                        value={trialForm.otherSubject}
                        onChange={(e) => setTrialForm({ ...trialForm, otherSubject: e.target.value })}
                        className="mt-1 h-10 md:h-12"
                        required
                      />
                    </div>
                  )}
                  
                  <div>
                    <Label className="text-sm md:text-base">Preferred Time</Label>
                    <Select 
                      value={trialForm.time}
                      onValueChange={(value) => setTrialForm({ ...trialForm, time: value })}
                    >
                      <SelectTrigger className="mt-1 h-10 md:h-12">
                        <SelectValue placeholder="Select preferred time" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">Morning (8AM - 12PM)</SelectItem>
                        <SelectItem value="afternoon">Afternoon (12PM - 5PM)</SelectItem>
                        <SelectItem value="evening">Evening (5PM - 9PM)</SelectItem>
                        <SelectItem value="flexible">I&apos;m Flexible</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg rounded-xl"
                  >
                    <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                    Book My Free Trial
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-10 md:gap-16">
            <div>
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Get in Touch</Badge>
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                Send Us a <span className="text-[#1DA678]">Message</span>
              </h2>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8">
                Have a specific question or request? Fill out the form and we&apos;ll get back to you 
                within 24 hours with a detailed response.
              </p>
              
              <div className="space-y-4 md:space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#E8F8F2] flex items-center justify-center">
                    <Clock className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm md:text-base">Response Time</p>
                    <p className="text-gray-600 text-sm md:text-base">Within 24 hours</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#E8F8F2] flex items-center justify-center">
                    <Users className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm md:text-base">Support Team</p>
                    <p className="text-gray-600 text-sm md:text-base">Dedicated customer support</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#E8F8F2] flex items-center justify-center">
                    <MessageCircle className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm md:text-base">WhatsApp Support</p>
                    <p className="text-gray-600 text-sm md:text-base">Quick responses available</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 md:mt-8">
                <Button 
                  className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
                  asChild
                >
                  <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                    Chat on WhatsApp
                  </a>
                </Button>
              </div>
            </div>
            
            <Card className="border-0 shadow-xl bg-white">
              <CardContent className="p-5 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Contact Form</h3>
                <form onSubmit={handleContactSubmit} className="space-y-3 md:space-y-4">
                  <div className="grid md:grid-cols-2 gap-3 md:gap-4">
                    <div>
                      <Label htmlFor="contact-name" className="text-sm md:text-base">Your Name</Label>
                      <Input
                        id="contact-name"
                        placeholder="John Doe"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="mt-1 h-10 md:h-12"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="contact-email" className="text-sm md:text-base">Email</Label>
                      <Input
                        id="contact-email"
                        type="email"
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="mt-1 h-10 md:h-12"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-3 md:gap-4">
                    <div>
                      <Label htmlFor="contact-phone" className="text-sm md:text-base">Phone</Label>
                      <Input
                        id="contact-phone"
                        type="tel"
                        placeholder="+966 5XX XXX XXXX"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="mt-1 h-10 md:h-12"
                      />
                    </div>
                    <div>
                      <Label className="text-sm md:text-base">Topic</Label>
                      <Select 
                        value={formData.subject}
                        onValueChange={(value) => setFormData({ ...formData, subject: value, otherSubject: '' })}
                      >
                        <SelectTrigger className="mt-1 h-10 md:h-12">
                          <SelectValue placeholder="Select topic" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General Inquiry</SelectItem>
                          <SelectItem value="enrollment">Enrollment</SelectItem>
                          <SelectItem value="pricing">Pricing</SelectItem>
                          <SelectItem value="support">Support</SelectItem>
                          <SelectItem value="teaching">Become a Teacher</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Other Topic Input */}
                  {formData.subject === 'other' && (
                    <div className="animate-in fade-in slide-in-from-top-2 duration-200">
                      <Label htmlFor="contact-other" className="text-sm md:text-base">Please specify *</Label>
                      <Input
                        id="contact-other"
                        placeholder="What's your question about?"
                        value={formData.otherSubject}
                        onChange={(e) => setFormData({ ...formData, otherSubject: e.target.value })}
                        className="mt-1 h-10 md:h-12"
                        required
                      />
                    </div>
                  )}
                  
                  <div>
                    <Label htmlFor="contact-message" className="text-sm md:text-base">Message</Label>
                    <Textarea
                      id="contact-message"
                      placeholder="How can we help you?"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="mt-1 min-h-[100px] md:min-h-[120px]"
                      required
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg rounded-xl"
                  >
                    <Send className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
