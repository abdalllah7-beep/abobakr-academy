import { Metadata } from 'next'
import TermsClient from './client'

export const metadata: Metadata = {
  title: 'Terms of Service | Abobakr Academy - Online Tutoring Agreement',
  description: 'Read the terms and conditions for using Abobakr Academy\'s online tutoring services. Our terms cover services, accounts, payments, cancellations, and more.',
  keywords: 'terms of service, terms and conditions, tutoring agreement, online learning terms, user agreement',
  openGraph: {
    title: 'Terms of Service | Abobakr Academy',
    description: 'Terms and conditions for using our online tutoring services.',
    type: 'website',
  },
}

export default function TermsPage() {
  return <TermsClient />
}
