'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  FileText,
  BookOpen,
  User,
  CreditCard,
  Calendar,
  Shield,
  AlertTriangle,
  RefreshCw,
  Mail,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const sections = [
  {
    icon: FileText,
    title: '1. Acceptance of Terms',
    content: `By accessing and using Abobakr Academy's website and services, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.

These terms apply to all visitors, users, and others who access or use our services. By using our services, you represent that you are at least 13 years of age and have the legal capacity to enter into these terms. If you are using our services on behalf of an organization, you agree to these terms on behalf of that organization.`
  },
  {
    icon: BookOpen,
    title: '2. Description of Services',
    content: `Abobakr Academy provides online tutoring services, including but not limited to:

**Educational Services:** One-on-one and small group tutoring sessions in various subjects including Quran, Tajweed, Arabic, English, Mathematics, Science, and other academic and professional subjects.

**Platform Access:** Access to our learning management system, video conferencing tools, educational resources, and progress tracking features.

**Support Services:** Customer support, scheduling assistance, and technical help for our tutoring platform.

**Additional Services:** Course materials, assessments, certifications, and other educational resources we may offer.

We reserve the right to modify, suspend, or discontinue any aspect of our services at any time without prior notice.`
  },
  {
    icon: User,
    title: '3. User Accounts',
    content: `To access certain features of our services, you must create an account. When creating an account, you agree to:

**Provide Accurate Information:** Supply accurate and complete information during registration and keep your account information up to date.

**Maintain Account Security:** Keep your password confidential and not share your account credentials with others. You are responsible for all activities that occur under your account.

**Accept Responsibility:** Take responsibility for all actions taken under your account, whether by you or by others using your account.

**Report Unauthorized Use:** Notify us immediately if you discover any unauthorized use of your account or any other security breach.

**One Account Per User:** Maintain only one account per individual unless expressly permitted by us.

We reserve the right to suspend or terminate accounts that violate these terms or engage in fraudulent, abusive, or illegal activities.`
  },
  {
    icon: CreditCard,
    title: '4. Payment Terms',
    content: `**Pricing:** Our pricing is published on our website and may be updated from time to time. All prices are displayed in the applicable currency and may exclude applicable taxes.

**Payment Methods:** We accept major credit cards, debit cards, PayPal, and other payment methods as specified during checkout.

**Payment Timing:** Payment for services is due at the time of booking or as specified in your selected payment plan.

**Currency:** All transactions are processed in the currency displayed during checkout. Currency conversion fees may apply for international transactions.

**Receipts:** Electronic receipts will be provided for all transactions. You can access your payment history through your account dashboard.

**Price Changes:** We reserve the right to change our pricing at any time. Price changes will not affect previously purchased sessions or packages.`
  },
  {
    icon: Calendar,
    title: '5. Cancellation and Rescheduling Policy',
    content: `**Cancellation by Student:**
- Cancellations made 24 hours or more before the scheduled session will receive a full credit to their account.
- Cancellations made less than 24 hours before the scheduled session may be subject to a late cancellation fee or forfeiture of the session fee.
- No-shows without prior notice will be charged the full session fee.

**Rescheduling by Student:**
- Sessions can be rescheduled up to 24 hours before the scheduled time at no additional cost.
- Rescheduling requests made less than 24 hours before the session are subject to tutor availability and may incur a rescheduling fee.

**Cancellation by Abobakr Academy:**
- If we need to cancel a session due to tutor unavailability or technical issues, you will receive a full refund or credit to your account.
- We will make reasonable efforts to notify you of cancellations as soon as possible.

**Refund Policy:**
- Unused session packages can be refunded within 14 days of purchase, minus an administrative fee.
- After 14 days, refunds are available on a case-by-case basis.
- Refunds will be processed using the original payment method within 5-10 business days.`
  },
  {
    icon: Shield,
    title: '6. Intellectual Property',
    content: `**Our Content:** All content on our platform, including but not limited to text, graphics, logos, images, videos, software, and course materials, is the property of Abobakr Academy or our content providers and is protected by intellectual property laws.

**Your Content:** You retain ownership of any content you create or submit to our platform, such as assignments or communications. By submitting content, you grant us a license to use, reproduce, and display it for the purpose of providing our services.

**License to Use:** We grant you a limited, non-exclusive, non-transferable license to access and use our platform and materials for personal, non-commercial educational purposes only.

**Restrictions:** You may not:
- Copy, modify, or distribute our content without written permission
- Use our content for commercial purposes
- Remove any proprietary notices from our materials
- Create derivative works based on our content
- Share your account access with others`
  },
  {
    icon: AlertTriangle,
    title: '7. Limitation of Liability',
    content: `**Disclaimer of Warranties:** Our services are provided "as is" and "as available" without warranties of any kind, either express or implied, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement.

**Limitation of Liability:** To the maximum extent permitted by law, Abobakr Academy shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, or other intangible losses, resulting from:

- Your use or inability to use our services
- Any conduct or content of any third party on the platform
- Any content obtained from our services
- Unauthorized access, use, or alteration of your transmissions or content

**Maximum Liability:** In no event shall our total liability to you for all claims exceed the amount you paid us in the twelve (12) months preceding the claim.

**Exceptions:** Nothing in these terms shall limit our liability for death or personal injury caused by negligence, fraud, or any other liability that cannot be limited by law.`
  },
  {
    icon: RefreshCw,
    title: '8. Changes to Terms',
    content: `We reserve the right to modify these terms at any time. When we make material changes, we will:

- Notify you by email to the address associated with your account
- Post a notice on our website
- Update the "Last Updated" date at the top of this page

Your continued use of our services after such modifications constitutes your acceptance of the updated terms. If you do not agree to the modified terms, you must discontinue use of our services.

We encourage you to review these terms periodically for any changes. The most current version of the terms will always be available on our website.`
  },
  {
    icon: Mail,
    title: '9. Contact Information',
    content: `If you have questions about these Terms of Service, please contact us:

**Email:** legal@abobakracademy.com
**WhatsApp:** +966 56 651 8545
**Website:** www.abobakracademy.com
**Contact Page:** www.abobakracademy.com/contact

For general inquiries, please use the contact form on our website or email us at info@abobakracademy.com.

We will respond to your inquiry within a reasonable timeframe.`
  },
]

export default function TermsClient() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader
        title="Terms of Service"
        subtitle="Please read these terms carefully before using our services"
        breadcrumb="Terms of Service"
      />

      {/* Introduction */}
      <section className="py-8 md:py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="p-6 md:p-8">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Last Updated: January 2025</Badge>
              <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                Welcome to Abobakr Academy. These Terms of Service (&quot;Terms&quot;, &quot;Terms of Service&quot;) govern your use of our website located at www.abobakracademy.com and our online tutoring services. These Terms constitute a legally binding agreement between you and Abobakr Academy regarding your use of our services.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Terms Sections */}
      <section className="py-8 md:py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8 md:space-y-12">
            {sections.map((section, index) => (
              <div key={index} className="scroll-mt-24" id={section.title.toLowerCase().replace(/\s+/g, '-').replace(/[0-9.]/g, '')}>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-[#1DA678]/10 flex items-center justify-center flex-shrink-0">
                    <section.icon className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-3 md:mb-4">{section.title}</h2>
                    <div className="text-gray-600 leading-relaxed text-sm md:text-base whitespace-pre-line">
                      {section.content}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Agreement Notice */}
      <section className="py-8 md:py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-0 shadow-lg bg-[#1DA678]/5">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Agreement to Terms</h3>
              <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                By using Abobakr Academy&apos;s services, you acknowledge that you have read and understood these Terms of Service and agree to be bound by them. If you have any questions about these terms, please contact us before using our services.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
