'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Trophy,
  Star,
  TrendingUp,
  Award,
  Target,
  BookOpen,
  Languages,
  Calculator,
  Atom,
  GraduationCap,
  Calendar,
  MessageCircle,
  ArrowRight,
  Quote,
  CheckCircle2,
  Users,
  Clock,
  Globe,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const successStories = [
  {
    id: 1,
    name: 'Ahmed',
    age: '14',
    country: 'Saudi Arabia',
    course: 'Quran & Tajweed',
    achievement: 'Completed Quran Memorization',
    icon: BookOpen,
    color: 'bg-emerald-500',
    rating: 5,
    testimonial: 'I never thought I could memorize the entire Quran. With the help of my tutor at Abobakr Academy, I completed my Hifz in just 2 years. The patience and dedication of my teacher made all the difference. Now I can lead prayers with confidence!',
    before: 'Struggling with basic recitation',
    after: 'Hafiz (Quran memorizer)',
    duration: '2 years',
    highlights: ['Completed full Quran memorization', 'Mastered Tajweed rules', 'Can now lead Taraweeh prayers'],
  },
  {
    id: 2,
    name: 'Sarah',
    age: '16',
    country: 'UAE',
    course: 'IELTS Preparation',
    achievement: 'IELTS Band 8.0',
    icon: Languages,
    color: 'bg-blue-500',
    rating: 5,
    testimonial: 'My IELTS tutor was amazing! She identified exactly where I was losing marks and helped me improve each section. I went from a band 6.0 in my practice tests to an 8.0 on exam day. I\'ve now been accepted to my dream university in the UK!',
    before: 'IELTS Practice: Band 6.0',
    after: 'IELTS Final: Band 8.0',
    duration: '3 months',
    highlights: ['Improved by 2 band scores', 'University acceptance achieved', 'Full scholarship qualified'],
  },
  {
    id: 3,
    name: 'Omar',
    age: '13',
    country: 'Egypt',
    course: 'Mathematics',
    achievement: 'Grade Improvement from C to A',
    icon: Calculator,
    color: 'bg-purple-500',
    rating: 5,
    testimonial: 'Math used to be my worst subject. My tutor at Abobakr Academy made everything make sense. He explained things in ways I could understand and never made me feel bad for asking questions. Now I actually enjoy math and help my classmates!',
    before: 'Math Grade: C (65%)',
    after: 'Math Grade: A (94%)',
    duration: '6 months',
    highlights: ['29% grade improvement', 'Developed love for math', 'Now helps classmates'],
  },
  {
    id: 4,
    name: 'Fatima',
    age: '17',
    country: 'Qatar',
    course: 'Physics & Chemistry',
    achievement: 'IGCSE Double A*',
    icon: Atom,
    color: 'bg-rose-500',
    rating: 5,
    testimonial: 'My science tutors broke down complex concepts into simple explanations. They used real-world examples that made everything click. I was so nervous about my IGCSEs, but their preparation gave me confidence. Getting A* in both subjects opened so many doors!',
    before: 'Predicted: B grades',
    after: 'Achieved: A* in both subjects',
    duration: '8 months',
    highlights: ['A* in IGCSE Physics', 'A* in IGCSE Chemistry', 'Accepted to top A-Level program'],
  },
  {
    id: 5,
    name: 'Khalid',
    age: '12',
    country: 'Kuwait',
    course: 'Arabic Language',
    achievement: 'Arabic Reading Fluency',
    icon: BookOpen,
    color: 'bg-teal-500',
    rating: 5,
    testimonial: 'I grew up speaking Arabic at home but struggled with reading and writing. My tutor helped me connect the spoken language I knew with proper reading skills. Now I can read Arabic books fluently and write excellent essays for school.',
    before: 'Could barely read Arabic',
    after: 'Fluent reader and writer',
    duration: '1 year',
    highlights: ['Mastered Arabic reading', 'Improved school Arabic grades', 'Can write complex essays'],
  },
  {
    id: 6,
    name: 'Layla',
    age: '15',
    country: 'Jordan',
    course: 'German Language',
    achievement: 'Goethe B1 Certification',
    icon: Globe,
    color: 'bg-yellow-500',
    rating: 5,
    testimonial: 'I wanted to study in Germany and needed the Goethe B1 certificate. My tutor prepared me perfectly for the exam, focusing on all four skills. I passed on my first try! The structured lessons and practice exams made all the difference.',
    before: 'Beginner (A0)',
    after: 'Goethe B1 Certified',
    duration: '10 months',
    highlights: ['Passed Goethe B1 first attempt', 'Can study in Germany', 'All four skills mastered'],
  },
  {
    id: 7,
    name: 'Yusuf',
    age: '10',
    country: 'UK',
    course: 'Quran with Tajweed',
    achievement: 'Completed Juz Amma with Tajweed',
    icon: BookOpen,
    color: 'bg-emerald-500',
    rating: 5,
    testimonial: 'My mom wanted me to learn Quran properly. My teacher was so nice and patient. She taught me all the Tajweed rules using fun examples. I finished Juz Amma and now I\'m working on more. I love my Quran classes!',
    before: 'No Quran reading skills',
    after: 'Completed Juz Amma with Tajweed',
    duration: '8 months',
    highlights: ['Learned all Tajweed basics', 'Completed Juz Amma', 'Loves Quran classes'],
  },
  {
    id: 8,
    name: 'Mariam',
    age: '18',
    country: 'Bahrain',
    course: 'Biology',
    achievement: 'Medical School Acceptance',
    icon: GraduationCap,
    color: 'bg-indigo-500',
    rating: 5,
    testimonial: 'Biology was my weakest subject, but I needed it for medical school. My tutor at Abobakr Academy was a medical student who understood exactly what I needed. We focused on exam technique and difficult topics. I got an A and am now in my first year of med school!',
    before: 'Biology Grade: C',
    after: 'Medical School Student',
    duration: '1 year',
    highlights: ['Biology grade improved to A', 'Medical school accepted', 'Living her dream'],
  },
]

const stats = [
  { icon: Trophy, value: '500+', label: 'Success Stories' },
  { icon: TrendingUp, value: '95%', label: 'Grade Improvement' },
  { icon: Award, value: '98%', label: 'Exam Pass Rate' },
  { icon: Users, value: '100+', label: 'Active Students' },
]

const categories = [
  { name: 'All Stories', count: successStories.length, active: true },
  { name: 'Islamic Studies', count: successStories.filter(s => s.course.includes('Quran') || s.course.includes('Tajweed')).length },
  { name: 'Languages', count: successStories.filter(s => s.course.includes('Language') || s.course.includes('IELTS') || s.course.includes('German')).length },
  { name: 'School Support', count: successStories.filter(s => s.course.includes('Math') || s.course.includes('Physics') || s.course.includes('Chemistry') || s.course.includes('Biology')).length },
]

export default function SuccessStoriesClient() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader
        title="Student Success Stories"
        subtitle="Real achievements from real students. See how Abobakr Academy has helped learners reach their goals."
        breadcrumb="Success Stories"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="w-8 h-8 text-white/80 mx-auto mb-2" />
                <p className="text-2xl md:text-3xl font-bold text-white">{stat.value}</p>
                <p className="text-white/70 text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Success Stories Grid */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filter Categories */}
          <div className="flex flex-wrap justify-center gap-2 md:gap-3 mb-10 md:mb-12">
            {categories.map((category) => (
              <button
                key={category.name}
                className={`px-4 md:px-6 py-2 md:py-2.5 rounded-full text-sm font-medium transition-all ${
                  category.active
                    ? 'bg-[#1DA678] text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name} ({category.count})
              </button>
            ))}
          </div>

          {/* Stories Grid */}
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {successStories.map((story) => (
              <Card key={story.id} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                <CardContent className="p-0">
                  {/* Header */}
                  <div className={`${story.color} p-4 md:p-6 text-white`}>
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-white/20 flex items-center justify-center">
                          <story.icon className="w-6 h-6 md:w-7 md:h-7" />
                        </div>
                        <div>
                          <h3 className="text-lg md:text-xl font-bold">{story.name}, {story.age}</h3>
                          <p className="text-white/80 text-sm">{story.country}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-0.5">
                        {[...Array(story.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-white/20 text-white border-0">{story.course}</Badge>
                      <Trophy className="w-4 h-4 text-yellow-300" />
                      <span className="text-sm font-medium">{story.achievement}</span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-4 md:p-6">
                    {/* Quote */}
                    <div className="relative mb-4 md:mb-6">
                      <Quote className="absolute -top-1 -left-1 w-6 h-6 text-[#1DA678]/20" />
                      <p className="text-gray-600 text-sm md:text-base italic pl-5 leading-relaxed">
                        &ldquo;{story.testimonial}&rdquo;
                      </p>
                    </div>

                    {/* Before/After */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-red-50 rounded-lg">
                        <p className="text-xs text-red-600 font-medium mb-1">Before</p>
                        <p className="text-sm text-gray-700">{story.before}</p>
                      </div>
                      <div className="p-3 bg-green-50 rounded-lg">
                        <p className="text-xs text-green-600 font-medium mb-1">After</p>
                        <p className="text-sm text-gray-700">{story.after}</p>
                      </div>
                    </div>

                    {/* Highlights */}
                    <div className="space-y-1.5">
                      {story.highlights.map((highlight, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckCircle2 className="w-4 h-4 text-[#1DA678] flex-shrink-0" />
                          <span>{highlight}</span>
                        </div>
                      ))}
                    </div>

                    {/* Duration */}
                    <div className="mt-4 pt-4 border-t flex items-center justify-between">
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Clock className="w-4 h-4" />
                        <span>Duration: {story.duration}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Become a Success Story */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Trophy className="w-12 h-12 md:w-16 md:h-16 text-[#1DA678] mx-auto mb-4 md:mb-6" />
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
            Your Success Story Starts Here
          </h2>
          <p className="text-base md:text-xl text-white/70 mb-6 md:mb-8 max-w-2xl mx-auto">
            Join hundreds of students who have achieved their academic goals with Abobakr Academy. 
            Your success story could be next!
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button
              size="lg"
              className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Start Your Journey
              </Link>
            </Button>
            <Button
              size="lg"
              className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* How We Help */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">How We Help</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              What Makes Our Students <span className="text-[#1DA678]">Successful</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {[
              {
                icon: Target,
                title: 'Personalized Learning Plans',
                description: 'Every student gets a customized plan based on their goals, current level, and learning style. No one-size-fits-all approach.',
              },
              {
                icon: Users,
                title: 'Expert One-on-One Tutors',
                description: 'Learn from qualified tutors who specialize in their subjects. Individual attention means faster progress.',
              },
              {
                icon: TrendingUp,
                title: 'Regular Progress Tracking',
                description: 'Monitor improvement with regular assessments and progress reports. See your growth in real-time.',
              },
              {
                icon: Clock,
                title: 'Flexible Scheduling',
                description: 'Book sessions when it works for you. Consistent learning around your busy schedule.',
              },
              {
                icon: Award,
                title: 'Exam Preparation Focus',
                description: 'Targeted preparation for IGCSE, IELTS, Goethe, and other exams. Know exactly what to expect.',
              },
              {
                icon: Globe,
                title: 'Learn from Anywhere',
                description: 'Access quality education from anywhere in the world. All you need is an internet connection.',
              },
            ].map((item, index) => (
              <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-16 bg-white border-t">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4">
            Ready to Write Your Success Story?
          </h2>
          <p className="text-gray-600 mb-6">
            Join Abobakr Academy today and start your journey toward academic excellence.
          </p>
          <Button size="lg" className="bg-[#1DA678] hover:bg-[#168a60] text-white px-8 py-6 rounded-full" asChild>
            <Link href="/courses">
              Explore Our Courses
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
