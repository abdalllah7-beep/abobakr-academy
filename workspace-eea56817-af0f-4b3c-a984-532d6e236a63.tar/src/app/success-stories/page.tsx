import { Metadata } from 'next'
import SuccessStoriesClient from './client'

export const metadata: Metadata = {
  title: 'Student Success Stories | Abobakr Academy',
  description: 'Read inspiring success stories from students who achieved their academic goals with Abobakr Academy. From improved grades to exam success and beyond.',
  keywords: 'student success, tutoring success stories, academic achievements, online learning results',
  openGraph: {
    title: 'Student Success Stories | Abobakr Academy',
    description: 'Read inspiring success stories from students who achieved their academic goals with Abobakr Academy.',
    type: 'website',
  },
}

export default function SuccessStoriesPage() {
  return <SuccessStoriesClient />
}
