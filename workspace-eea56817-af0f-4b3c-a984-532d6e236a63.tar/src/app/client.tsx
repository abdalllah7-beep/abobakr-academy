'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Clock,
  Users,
  Calendar,
  Trophy,
  MessageCircle,
  Sparkles,
  BookMarked,
  Languages,
  Monitor,
  ArrowRight,
  Star,
  CheckCircle2,
  GraduationCap,
  Globe,
  Award,
  Shield,
  Atom,
  Calculator,
  Code,
  FlaskConical,
} from 'lucide-react'
import { Navigation, Footer, WhatsAppButton } from '@/components/layout'

// Counter animation hook
function useCounter(end: number, duration: number = 2000, startCounting: boolean = false) {
  const [count, setCount] = useState(0)
  const countRef = useRef(0)
  const startTimeRef = useRef<number | null>(null)

  useEffect(() => {
    if (!startCounting) return
    const animate = (timestamp: number) => {
      if (!startTimeRef.current) startTimeRef.current = timestamp
      const progress = Math.min((timestamp - startTimeRef.current) / duration, 1)
      countRef.current = Math.floor(progress * end)
      setCount(countRef.current)
      if (progress < 1) requestAnimationFrame(animate)
    }
    requestAnimationFrame(animate)
  }, [end, duration, startCounting])

  return count
}

function useInView(threshold = 0.1) {
  const [isInView, setIsInView] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsInView(true) },
      { threshold }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [threshold])
  return { ref, isInView }
}

// Hero Section - Value Proposition First
function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center pt-16 md:pt-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922]" />
      
      {/* Animated Pattern Overlay */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Glowing orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#1DA678]/20 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-[#25D366]/15 rounded-full blur-[80px] animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-12 md:gap-16 items-center">
          {/* Left Content - Main Value Proposition */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 rounded-full bg-[#1DA678]/20 border border-[#1DA678]/30">
              <div className="w-2 h-2 rounded-full bg-[#1DA678] animate-pulse" />
              <span className="text-[#4ADE80] font-medium text-sm">Now Accepting New Students</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-tight mb-6">
              Expert Tutors,
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#4ADE80] to-[#1DA678]">
                Brighter Futures
              </span>
            </h1>

            <p className="text-lg md:text-xl text-white/70 mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Personalized 1-on-1 online tutoring from certified experts. 
              Join <strong className="text-white">100+ students</strong> who have completed over <strong className="text-white">2,500 lessons</strong> with us.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-10">
              <Button
                size="lg"
                className="bg-[#1DA678] hover:bg-[#168a60] text-white px-8 py-6 text-lg rounded-full shadow-lg shadow-[#1DA678]/25 hover:shadow-xl hover:shadow-[#1DA678]/30 transition-all duration-300 group"
                asChild
              >
                <Link href="/contact#trial">
                  <Calendar className="mr-2 w-5 h-5" />
                  Start Free Trial
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button
                size="lg"
                className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-8 py-6 text-lg rounded-full shadow-lg shadow-[#25D366]/25 transition-all duration-300"
                asChild
              >
                <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="mr-2 w-5 h-5" />
                  WhatsApp Us
                </a>
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {['A', 'B', 'C', 'D'].map((letter, i) => (
                    <div key={i} className="w-9 h-9 rounded-full bg-gradient-to-br from-[#1DA678] to-[#168a60] border-2 border-[#0f2922] flex items-center justify-center text-white text-xs font-bold">
                      {letter}
                    </div>
                  ))}
                </div>
                <span className="text-white/70 text-sm">100+ Happy Students</span>
              </div>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                ))}
                <span className="text-white/70 text-sm ml-1">4.8/5 Rating</span>
              </div>
            </div>
          </div>

          {/* Right Content - Feature Cards */}
          <div className="relative hidden lg:block">
            <div className="grid grid-cols-2 gap-4">
              {/* Card 1 */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:border-[#1DA678]/50 transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 rounded-xl bg-[#1DA678] flex items-center justify-center mb-4">
                  <GraduationCap className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">Expert Tutors</h3>
                <p className="text-white/60 text-sm">50+ certified teachers with proven track records</p>
              </div>

              {/* Card 2 */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:border-[#1DA678]/50 transition-all duration-300 hover:-translate-y-1 mt-8">
                <div className="w-12 h-12 rounded-xl bg-[#25D366] flex items-center justify-center mb-4">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">Flexible Schedule</h3>
                <p className="text-white/60 text-sm">Book lessons at times that work for you</p>
              </div>

              {/* Card 3 */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:border-[#1DA678]/50 transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 rounded-xl bg-[#1DA678] flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">1-on-1 Learning</h3>
                <p className="text-white/60 text-sm">Personalized sessions at your own pace</p>
              </div>

              {/* Card 4 */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:border-[#1DA678]/50 transition-all duration-300 hover:-translate-y-1 mt-8">
                <div className="w-12 h-12 rounded-xl bg-[#25D366] flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">Free Trial</h3>
                <p className="text-white/60 text-sm">Try any course free, no commitment</p>
              </div>
            </div>

            {/* Floating Badge */}
            <div className="absolute -top-4 -right-4 bg-[#1DA678] text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg animate-bounce-subtle">
              <Sparkles className="w-4 h-4 inline mr-1" />
              Free Trial Available!
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator - Hidden on mobile to prevent overlap */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce hidden md:block">
        <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-2">
          <div className="w-1.5 h-3 bg-white/50 rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  )
}

// Stats Section
function StatsSection() {
  const { ref, isInView } = useInView()
  const students = useCounter(100, 2000, isInView)
  const lessons = useCounter(2500, 2500, isInView)
  const rating = useCounter(48, 2000, isInView)

  const stats = [
    { icon: Users, value: `${students}+`, label: 'Happy Students', color: 'from-[#1DA678] to-[#168a60]' },
    { icon: Clock, value: `${lessons}+`, label: 'Lessons Completed', color: 'from-[#25D366] to-[#1DA678]' },
    { icon: Star, value: `${(rating / 10).toFixed(1)}`, label: 'Average Rating', color: 'from-yellow-400 to-yellow-500' },
    { icon: GraduationCap, value: '50+', label: 'Expert Tutors', color: 'from-[#1DA678] to-[#25D366]' },
  ]

  return (
    <section ref={ref} className="py-16 bg-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-[#E8F8F2] via-white to-[#E8F8F2]" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group">
              <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                <stat.icon className="w-8 h-8 text-white" />
              </div>
              <p className="text-3xl md:text-4xl font-bold text-gray-900 mb-1">{stat.value}</p>
              <p className="text-gray-500 font-medium">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Why Choose Us
function WhyChooseUs() {
  const features = [
    { icon: GraduationCap, title: 'Certified Expert Tutors', description: 'Learn from qualified teachers with years of experience. Our tutors are carefully selected for their expertise.', color: 'bg-emerald-500' },
    { icon: Clock, title: 'Flexible Scheduling', description: 'Book lessons at times that work for you. Morning, afternoon, or evening - we accommodate your schedule.', color: 'bg-blue-500' },
    { icon: Users, title: 'Personalized 1-on-1 Learning', description: 'Every session is tailored to your pace and learning style. Get the individual attention you deserve.', color: 'bg-purple-500' },
    { icon: Calendar, title: 'Free Trial Class', description: 'Try any course with a free 20-minute session. Experience our teaching quality before committing.', color: 'bg-orange-500' },
    { icon: Globe, title: 'Learn from Anywhere', description: 'Online classes via Zoom and Google Meet. Access quality education from the comfort of your home.', color: 'bg-teal-500' },
    { icon: Trophy, title: 'Progress Tracking', description: 'Regular assessments and detailed reports. Parents and students stay informed about learning progress.', color: 'bg-pink-500' },
  ]

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Why Choose Us</Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Why Parents Trust <span className="text-[#1DA678]">Abobakr Academy</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto">
            We provide a comprehensive learning experience designed to help every student succeed.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 bg-white group">
              <CardContent className="p-6">
                <div className={`w-14 h-14 rounded-2xl ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

// Featured Courses - Specific courses, not categories
function FeaturedCourses() {
  const courses = [
    { icon: BookMarked, name: 'Quran & Tajweed', description: 'Learn Quran reading, recitation & memorization with certified Qaris', href: '/courses/quran', color: 'bg-emerald-500', popular: true },
    { icon: Languages, name: 'English Language', description: 'IELTS prep, conversation, business English, grammar mastery', href: '/courses/english', color: 'bg-blue-500', popular: true },
    { icon: Calculator, name: 'Mathematics', description: 'K-12 math, algebra, calculus, exam preparation & homework help', href: '/courses/mathematics', color: 'bg-purple-500', popular: true },
    { icon: Atom, name: 'Physics', description: 'Mechanics, electricity, waves, modern physics for all grades', href: '/courses/physics', color: 'bg-indigo-500' },
    { icon: Languages, name: 'Arabic Language', description: 'Modern Standard Arabic, Quranic Arabic, conversation skills', href: '/courses/arabic', color: 'bg-teal-500', popular: true },
    { icon: FlaskConical, name: 'Chemistry', description: 'Organic, inorganic, physical chemistry & lab concepts', href: '/courses/chemistry', color: 'bg-rose-500' },
    { icon: Code, name: 'Programming', description: 'Python, JavaScript fundamentals & practical projects', href: '/courses/programming', color: 'bg-violet-500' },
    { icon: Award, name: 'ICDL Certification', description: 'International Computer Driving License preparation', href: '/courses/icdl', color: 'bg-orange-500' },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Our Courses</Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Popular <span className="text-[#1DA678]">Courses</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto">
            Choose from our most popular courses taught by expert tutors.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {courses.map((course, index) => (
            <Link key={index} href={course.href}>
              <Card className="border-0 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-2 cursor-pointer group h-full">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl ${course.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                      <course.icon className="w-6 h-6 text-white" />
                    </div>
                    {course.popular && (
                      <Badge className="bg-[#1DA678] text-white text-xs">Popular</Badge>
                    )}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{course.name}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{course.description}</p>
                  <div className="mt-4 flex items-center text-[#1DA678] text-sm font-medium">
                    Learn More <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" className="bg-[#1DA678] hover:bg-[#168a60] text-white px-8 py-6 rounded-full" asChild>
            <Link href="/courses">
              View All 20+ Courses
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

// Course Categories - Brief overview
function CourseCategories() {
  const categories = [
    { icon: BookMarked, name: 'Islamic Studies', courses: 'Quran, Tajweed, Qaida, Islamic Studies', href: '/courses#islamic-studies', color: 'bg-emerald-500' },
    { icon: Languages, name: 'Languages', courses: 'Arabic, English, German, French, Spanish, Italian', href: '/courses#language-mastery', color: 'bg-blue-500' },
    { icon: GraduationCap, name: 'School Support', courses: 'Math, Science, Physics, Chemistry, Biology, History', href: '/courses#school-curriculum', color: 'bg-purple-500' },
    { icon: Monitor, name: 'Digital Skills', courses: 'ICDL, Programming, Microsoft Office', href: '/courses#computer-science', color: 'bg-indigo-500' },
  ]

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Categories</Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Browse by <span className="text-[#1DA678]">Category</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => (
            <Link key={index} href={category.href}>
              <Card className="border-0 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-2 cursor-pointer group h-full">
                <CardContent className="p-6 text-center">
                  <div className={`w-14 h-14 mx-auto rounded-2xl ${category.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <category.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{category.name}</h3>
                  <p className="text-gray-500 text-sm">{category.courses}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

// Testimonials - Fewer testimonials on homepage
function Testimonials() {
  const testimonials = [
    { name: 'Farah', course: 'Quran Student', text: 'Great efforts! I feel like reading Quran for the first time! The teacher explains everything clearly and patiently.', rating: 5 },
    { name: "Adam & Amin's Mom", course: 'English', text: 'The class was amazing, my kids loved the teacher so much! They look forward to every session now.', rating: 5 },
    { name: "Sarah", course: 'Physics Student', text: 'Physics finally makes sense! The tutor breaks down complex concepts into simple explanations. Highly recommend!', rating: 5 },
    { name: "Omar", course: 'Mathematics', text: 'My math grades went from C to A in just two months! The personalized attention really works.', rating: 5 },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Testimonials</Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            What <span className="text-[#1DA678]">Parents & Students Say</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto">
            Real feedback from families who have experienced the Abobakr Academy difference.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white">
              <CardContent className="p-6">
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4 leading-relaxed text-sm">&quot;{testimonial.text}&quot;</p>
                <div className="pt-3 border-t">
                  <p className="font-semibold text-gray-900 text-sm">{testimonial.name}</p>
                  <p className="text-xs text-[#1DA678]">{testimonial.course}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-10">
          <Button size="lg" className="bg-[#1DA678] hover:bg-[#168a60] text-white px-8 py-6 rounded-full" asChild>
            <Link href="/testimonials">
              Read All Testimonials
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

// Success Stories Preview
function SuccessStoriesPreview() {
  const stories = [
    { name: 'Ahmed', achievement: 'Completed Quran Memorization', course: 'Quran & Tajweed', color: 'bg-emerald-500' },
    { name: 'Sarah', achievement: 'IELTS Band 8.0', course: 'IELTS Preparation', color: 'bg-blue-500' },
    { name: 'Omar', achievement: 'Grade C to A', course: 'Mathematics', color: 'bg-purple-500' },
    { name: 'Fatima', achievement: 'IGCSE Double A*', course: 'Physics & Chemistry', color: 'bg-rose-500' },
  ]

  return (
    <section className="py-16 md:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10 md:mb-16">
          <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">
            <Trophy className="w-3 h-3 mr-1" />
            Success Stories
          </Badge>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
            Student <span className="text-[#1DA678]">Achievements</span>
          </h2>
          <p className="text-base md:text-xl text-gray-600 max-w-2xl mx-auto">
            Real results from real students. See how Abobakr Academy has helped learners achieve their goals.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {stories.map((story, index) => (
            <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 overflow-hidden">
              <CardContent className="p-0">
                <div className={`${story.color} p-3 md:p-4 text-white text-center`}>
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-2">
                    <Trophy className="w-5 h-5 md:w-6 md:h-6" />
                  </div>
                  <p className="font-bold text-sm md:text-base">{story.name}</p>
                  <p className="text-white/80 text-xs">{story.course}</p>
                </div>
                <div className="p-3 md:p-4 text-center">
                  <p className="text-xs md:text-sm font-semibold text-gray-900">{story.achievement}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-8 md:mt-10">
          <Button size="lg" className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
            <Link href="/success-stories">
              Read All Success Stories
              <ArrowRight className="ml-2 w-4 h-4 md:w-5 md:h-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

// CTA Section
function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922] relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-[#1DA678] rounded-full blur-[150px]" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#25D366] rounded-full blur-[150px]" />
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <Sparkles className="w-12 h-12 text-[#1DA678] mx-auto mb-6" />
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
          Ready to Start Your Learning Journey?
        </h2>
        <p className="text-lg md:text-xl text-white/70 mb-10 max-w-2xl mx-auto">
          Book a free trial class today and discover how our expert tutors can help you achieve your goals. No commitment required.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-[#1DA678] hover:bg-[#168a60] text-white px-8 py-6 text-lg rounded-full shadow-lg shadow-[#1DA678]/25" asChild>
            <Link href="/contact#trial">
              <Calendar className="w-5 h-5 mr-2" />
              Book Free Trial
            </Link>
          </Button>
          <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-8 py-6 text-lg rounded-full shadow-lg shadow-[#25D366]/25" asChild>
            <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
              <MessageCircle className="w-5 h-5 mr-2" />
              WhatsApp Us
            </a>
          </Button>
        </div>
        
        <div className="mt-10 flex flex-wrap items-center justify-center gap-6 text-white/50 text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#1DA678]" />
            <span>No credit card</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#1DA678]" />
            <span>20-minute session</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#1DA678]" />
            <span>Expert tutor</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#1DA678]" />
            <span>No commitment</span>
          </div>
        </div>
      </div>
    </section>
  )
}

// Main Home Component
export default function HomeClient() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <StatsSection />
      <WhyChooseUs />
      <FeaturedCourses />
      <CourseCategories />
      <SuccessStoriesPreview />
      <Testimonials />
      <CTASection />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
