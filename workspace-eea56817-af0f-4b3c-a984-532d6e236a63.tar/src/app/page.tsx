import { Metadata } from 'next'
import HomeClient from './client'

export const metadata: Metadata = {
  title: 'Abobakr Academy | Expert Online Private Tutors - Quran, Languages, School Support',
  description: 'Unlock your potential with expert online private tutors. Personalized 1-on-1 learning for Islamic Studies, Languages, School Curriculum Support & more. 100+ students, 2500+ lessons. Free trial available.',
  keywords: 'online tutoring, private tutors, quran classes, arabic lessons, english tutoring, math tutor, online education, islamic studies, language classes',
  openGraph: {
    title: 'Abobakr Academy | Expert Online Private Tutors',
    description: 'Personalized 1-on-1 online tutoring for Quran, Languages, School Support & more.',
    type: 'website',
  },
}

export default function Page() {
  return <HomeClient />
}
