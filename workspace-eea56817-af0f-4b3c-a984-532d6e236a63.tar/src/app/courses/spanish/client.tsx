'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Languages,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Globe,
  GraduationCap,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, ServiceSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Spanish Language – All Levels',
  category: 'Languages',
  rating: 4.8,
  students: 40,
  lessons: 100,
  description: 'Learn Spanish with native-speaking tutors. Master conversation, grammar, and explore the rich cultures of Spain and Latin America. From complete beginners to advanced speakers.',
  highlights: [
    'Native Spanish speakers',
    'Conversation focus',
    'Grammar mastery',
    'Cultural immersion',
    'All levels A1-C1',
    'Free trial available',
  ],
  programs: [
    { name: 'Beginner (A1-A2)', description: 'Basic vocabulary, greetings, simple conversations, essential grammar, and foundational skills for everyday situations.', level: 'Beginner' },
    { name: 'Intermediate (B1-B2)', description: 'Complex grammar, travel Spanish, deeper conversations, expressing opinions, and engaging with native content.', level: 'Intermediate' },
    { name: 'Advanced (C1)', description: 'Fluent expression, professional Spanish, literature analysis, cultural nuances, and native-level communication.', level: 'Advanced' },
  ],
}

const faqData = [
  {
    question: 'Is Spanish easy to learn for English speakers?',
    answer: 'Spanish is considered one of the easiest languages for English speakers to learn! The pronunciation is straightforward (what you see is what you say), and there are many cognates (similar words) between English and Spanish. With consistent practice, you can achieve conversational proficiency relatively quickly—typically 3-6 months for basic conversation.',
  },
  {
    question: 'What type of Spanish do you teach?',
    answer: 'We offer both Peninsular Spanish (Spain) and Latin American Spanish, depending on your preference and goals. Our teachers come from various Spanish-speaking countries and can adapt to the variety you wish to learn. If you\'re learning for travel or business in a specific region, we\'ll tailor your instruction accordingly.',
  },
  {
    question: 'How long does it take to become fluent in Spanish?',
    answer: 'Fluency timelines vary by individual. Basic conversational ability (A2) typically takes 3-6 months with regular study. Intermediate proficiency (B1-B2) usually takes 6-12 months. Advanced fluency (C1) can be achieved in 1-2 years with consistent immersion and practice. Our one-on-one instruction accelerates your progress significantly.',
  },
  {
    question: 'Do you prepare students for Spanish proficiency exams?',
    answer: 'Yes! We prepare students for DELE (Diploma de Español como Lengua Extranjera) and SIELE exams, which are internationally recognized Spanish proficiency certifications. Our teachers are familiar with the exam formats and provide targeted preparation including practice tests and exam strategies.',
  },
  {
    question: 'Can I learn Spanish for business purposes?',
    answer: 'Absolutely! We offer Business Spanish courses focusing on professional communication, business vocabulary, formal writing, and cultural etiquette in Spanish-speaking business environments. Spanish is valuable for careers in international business, healthcare, education, and many other fields.',
  },
  {
    question: 'What materials do you use for Spanish lessons?',
    answer: 'We use a combination of established Spanish learning curricula and authentic materials. This includes textbooks (like Aula Internacional, Gente Hoy), Spanish media, music, videos, and literature. Teachers also create custom exercises based on student interests. All materials are provided digitally.',
  },
  {
    question: 'Do you offer Spanish classes for children?',
    answer: 'Yes, we have Spanish programs specifically designed for children and teenagers. Our teachers use engaging methods including games, songs, stories, and interactive activities. Learning Spanish young gives children a valuable skill and can support Spanish language studies at school.',
  },
  {
    question: 'How are online Spanish classes conducted?',
    answer: 'Classes are conducted via video call in a one-on-one format. Each 45-60 minute session includes conversation practice, grammar instruction, vocabulary building, and listening comprehension. Teachers share their screens for visual materials and interactive exercises. You\'ll have speaking practice in every lesson.',
  },
]

export default function SpanishCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/spanish',
    category: 'Languages',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const serviceSchemaData = {
    name: `Online ${courseData.name}`,
    description: 'One-on-one online Spanish language tutoring with native speakers',
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/spanish',
    category: 'Online Education',
    areaServed: 'Worldwide',
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Spanish', url: 'https://www.abobakracademy.com/courses/spanish' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Spanish" />
      <CourseSchema course={courseSchemaData} />
      <ServiceSchema service={serviceSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Spanish Classes Online"
        subtitle="Learn Spanish with native-speaking tutors"
        breadcrumb="Courses / Spanish"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <Languages className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Done</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">8+</p>
              <p className="text-white/70 text-sm">Spanish Tutors</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Language Mastery</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Spanish Levels</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn Spanish with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Spanish is the world&apos;s second-most spoken native language with over 500 million 
                    speakers across 20+ countries. From the vibrant streets of Barcelona to the 
                    ancient ruins of Mexico, from the tango halls of Buenos Aires to the beaches 
                    of the Caribbean, Spanish opens doors to incredibly diverse cultures.
                  </p>
                  <p>
                    Our native Spanish-speaking teachers bring authentic language and cultural 
                    insights to every lesson. Whether you&apos;re interested in Peninsular Spanish 
                    from Spain or Latin American varieties from Mexico, Colombia, Argentina, or 
                    elsewhere, we match you with teachers who can provide the regional focus you want.
                  </p>
                  <p>
                    The one-on-one format ensures maximum speaking practice and personalized 
                    attention. Spanish is known for being relatively easy to start, but achieving 
                    true fluency requires dedicated practice. Our teachers guide you through 
                    each level, helping you sound natural and confident in any Spanish-speaking 
                    environment.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start learning Spanish today with a free 20-minute trial session.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Native speakers</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;¡Me encanta aprender español! My teacher makes every lesson fun and I can already have real conversations after just a few months.&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Layla</p>
                  <p className="text-xs md:text-sm text-gray-600">Spanish Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Spanish Classes"
        subtitle="Find answers to common questions about learning Spanish online"
      />

      {/* Related Courses */}
      <RelatedCourses
        courses={relatedCoursesByCategory['languages']}
        title="Explore More Language Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            ¡Aprende Español Hoy!
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Start your Spanish learning journey with a free trial. No commitment required.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
