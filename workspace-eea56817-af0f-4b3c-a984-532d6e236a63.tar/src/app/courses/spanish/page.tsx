import { Metadata } from 'next'
import SpanishCourse from './client'

export const metadata: Metadata = {
  title: 'Learn Spanish Online | Spanish Classes All Levels - Abobakr Academy',
  description: 'Learn Spanish online with certified native-speaking tutors. Master conversation, grammar, and explore Spanish-speaking cultures. All levels A1-C1. Free trial available.',
  keywords: [
    'learn spanish online',
    'spanish classes',
    'spanish tutor',
    'online spanish lessons',
    'spanish for beginners',
    'spanish conversation',
    'spanish grammar',
    'spanish language course',
    'speak spanish',
    'learn latin american spanish',
    'spanish certification',
    'spanish teachers',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/spanish',
  },
  openGraph: {
    title: 'Learn Spanish Online | Spanish Classes All Levels',
    description: 'Learn Spanish online with certified native-speaking tutors. Conversation, grammar, culture.',
    url: 'https://www.abobakracademy.com/courses/spanish',
    type: 'website',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: 'Spanish Language Classes - Abobakr Academy',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Learn Spanish Online - Abobakr Academy',
    description: 'Learn Spanish with native speakers. All levels welcome. Free trial!',
  },
}

export default function Page() {
  return <SpanishCourse />
}
