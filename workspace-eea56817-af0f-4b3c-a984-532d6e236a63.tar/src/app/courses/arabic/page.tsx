import { Metadata } from 'next'
import ArabicCourse from './client'

export const metadata: Metadata = {
  title: 'Learn Arabic Online | Arabic Language Classes with Native Tutors - Abobakr Academy',
  description: 'Learn Arabic online with native-speaking tutors. Master Modern Standard Arabic, grammar (Nahw), conversation, reading and writing. All levels A1-C2. Free trial available.',
  keywords: [
    'learn arabic online',
    'arabic classes',
    'arabic language tutor',
    'modern standard arabic',
    'arabic for beginners',
    'arabic conversation classes',
    'arabic grammar nahw',
    'online arabic course',
    'arabic reading writing',
    'arabic lessons',
    'speak arabic',
    'classical arabic',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/arabic',
  },
  openGraph: {
    title: 'Learn Arabic Online | Arabic Language Classes with Native Tutors',
    description: 'Learn Arabic online with native-speaking tutors. Master Modern Standard Arabic, grammar, conversation. All levels.',
    url: 'https://www.abobakracademy.com/courses/arabic',
    type: 'website',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: 'Arabic Language Classes - Abobakr Academy',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Learn Arabic Online - Abobakr Academy',
    description: 'Learn Arabic online with native-speaking tutors. All levels from beginner to advanced. Free trial!',
  },
}

export default function Page() {
  return <ArabicCourse />
}
