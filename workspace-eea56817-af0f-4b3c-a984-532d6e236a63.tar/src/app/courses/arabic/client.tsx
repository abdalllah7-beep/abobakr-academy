'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Languages,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  BookOpen,
  Mic,
  Globe,
  Award,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, ServiceSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Arabic Language Mastery',
  category: 'Languages',
  rating: 4.8,
  students: 120,
  lessons: 350,
  description: 'Learn Modern Standard Arabic with native-speaking instructors. Our comprehensive program covers reading, writing, speaking, and listening skills for all proficiency levels, from complete beginners to advanced learners.',
  highlights: [
    'Native Arabic Instructors',
    'Modern Standard Arabic',
    'Reading & Writing Skills',
    'Conversation Practice',
    'Grammar (Nahw) Mastery',
    'Classical Arabic Option',
    'All Levels Welcome',
    'Flexible Scheduling',
  ],
  programs: [
    { name: 'Beginner (A1-A2)', description: 'Arabic alphabet, basic vocabulary, simple sentences, everyday expressions, and foundational grammar rules.', level: 'Beginner' },
    { name: 'Intermediate (B1-B2)', description: 'Complex grammar structures, extended conversations, reading comprehension, writing skills, and media Arabic.', level: 'Intermediate' },
    { name: 'Advanced (C1-C2)', description: 'Fluent expression, literary Arabic, professional communication, cultural understanding, and classical texts.', level: 'Advanced' },
  ],
}

const faqData = [
  {
    question: 'What type of Arabic do you teach?',
    answer: 'We primarily teach Modern Standard Arabic (Fus\'ha), which is the formal Arabic used in media, literature, formal communication, and understood across all Arab countries. We can also provide instruction in Classical Arabic (Quranic Arabic) for those interested in religious studies. Our teachers can introduce you to dialectal differences if you have a specific regional interest.',
  },
  {
    question: 'Do I need to know the Arabic alphabet before starting?',
    answer: 'No, you don\'t need any prior knowledge of Arabic. Our beginner course starts with teaching the Arabic alphabet, letter recognition, and basic pronunciation. We\'ll guide you through each step, from recognizing letters to reading words and sentences. If you already know the alphabet, we\'ll assess your level and start from the appropriate point.',
  },
  {
    question: 'How long does it take to learn Arabic?',
    answer: 'Learning Arabic is a journey that varies by individual. With consistent study (2-3 classes per week plus practice), students typically reach conversational level (A2-B1) in 6-12 months. Intermediate proficiency (B2) usually takes 1-2 years. Advanced fluency requires longer commitment. Our teachers create personalized plans based on your goals and available study time.',
  },
  {
    question: 'Can I learn Arabic for Quran understanding?',
    answer: 'Yes! Many of our students learn Arabic specifically to understand the Quran. Our Classical Arabic program focuses on Quranic vocabulary, grammatical structures found in the Quran, and linguistic nuances. This complements our Quran and Tajweed courses perfectly, helping you connect more deeply with the meaning of what you recite.',
  },
  {
    question: 'What materials do you use for Arabic instruction?',
    answer: 'We use a combination of structured curricula and authentic materials. Our core curriculum includes established Arabic learning textbooks supplemented with audio-visual resources, news articles, stories, and real-world materials. Teachers also create custom exercises based on student interests. All materials are provided as part of your course.',
  },
  {
    question: 'How are speaking and listening skills developed?',
    answer: 'Speaking and listening are integral to our program. Each lesson includes conversation practice with your native-speaking teacher. We use role-plays, discussions, and interactive exercises. Listening practice includes audio materials at appropriate levels. The one-on-one format ensures maximum speaking time and immediate feedback on pronunciation.',
  },
  {
    question: 'Is Arabic grammar (Nahw) difficult to learn?',
    answer: 'Arabic grammar has a reputation for complexity, but our teachers break it down into manageable concepts. We introduce grammar progressively, connecting rules to practical usage. Starting with the essentials and building gradually, students find that Arabic grammar follows logical patterns. Our teachers make even complex concepts accessible through clear explanations and practice.',
  },
  {
    question: 'Can children learn Arabic in your program?',
    answer: 'Absolutely! We have specialized Arabic programs for children with age-appropriate teaching methods. Kids learn through games, songs, stories, and interactive activities that make language learning fun. Our teachers are experienced in engaging young learners and helping them develop a love for the Arabic language.',
  },
]

export default function ArabicCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/arabic',
    category: 'Languages',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const serviceSchemaData = {
    name: `Online ${courseData.name}`,
    description: 'One-on-one online Arabic language tutoring with native speakers',
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/arabic',
    category: 'Online Education',
    areaServed: 'Worldwide',
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Arabic', url: 'https://www.abobakracademy.com/courses/arabic' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Arabic" />
      <CourseSchema course={courseSchemaData} />
      <ServiceSchema service={serviceSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Arabic Language Course"
        subtitle="Master Arabic with native-speaking tutors - From basics to fluency"
        breadcrumb="Courses / Arabic"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <BookOpen className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Done</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <Award className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">15+</p>
              <p className="text-white/70 text-sm">Native Tutors</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Language Mastery</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Course Levels</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn Arabic with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Arabic is spoken by over 400 million people across 22 countries and is one of the 
                    six official languages of the United Nations. Learning Arabic opens doors to rich 
                    cultures, career opportunities, and a deeper understanding of the Islamic world.
                  </p>
                  <p>
                    At Abobakr Academy, our native Arabic-speaking teachers bring authentic language 
                    and cultural knowledge to every lesson. The one-on-one format allows for 
                    personalized instruction that adapts to your learning style, pace, and goals. 
                    Whether you&apos;re learning for business, travel, religious study, or personal 
                    enrichment, we tailor our approach to your needs.
                  </p>
                  <p>
                    Our comprehensive curriculum covers all four language skills—reading, writing, 
                    speaking, and listening—ensuring well-rounded proficiency. With flexible 
                    scheduling and the convenience of online learning, you can progress at your 
                    own pace while receiving expert guidance every step of the way.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start your Arabic learning journey with a free 20-minute trial session.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mic className="w-4 h-4 text-[#1DA678]" />
                      <span>Speaking practice included</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Native-speaking tutors</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;Learning Arabic with a native speaker made all the difference. My pronunciation and confidence have improved tremendously!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Sarah</p>
                  <p className="text-xs md:text-sm text-gray-600">Arabic Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Arabic Classes"
        subtitle="Find answers to common questions about learning Arabic online"
      />

      {/* Related Courses */}
      <RelatedCourses
        courses={relatedCoursesByCategory['languages']}
        title="Explore More Language Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Learn Arabic?
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Book your free trial class and start speaking Arabic with confidence.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
