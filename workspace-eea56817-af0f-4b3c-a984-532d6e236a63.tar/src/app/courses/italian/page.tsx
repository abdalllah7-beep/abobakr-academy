import { Metadata } from 'next'
import ItalianCourse from './client'

export const metadata: Metadata = {
  title: 'Learn Italian Online | Italian Classes All Levels - Abobakr Academy',
  description: 'Learn Italian online with certified native-speaking tutors. Master conversation, grammar, and discover Italian culture. All levels A1-C1. Free trial available.',
  keywords: [
    'learn italian online',
    'italian classes',
    'italian tutor',
    'online italian lessons',
    'italian for beginners',
    'italian conversation',
    'italian grammar',
    'italian language course',
    'speak italian',
    'learn italian language',
    'italian certification',
    'italian culture',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/italian',
  },
  openGraph: {
    title: 'Learn Italian Online | Italian Classes All Levels',
    description: 'Learn Italian online with certified native-speaking tutors. Conversation, grammar, culture.',
    url: 'https://www.abobakracademy.com/courses/italian',
    type: 'website',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: 'Italian Language Classes - Abobakr Academy',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Learn Italian Online - Abobakr Academy',
    description: 'Learn Italian with native speakers. All levels welcome. Free trial!',
  },
}

export default function Page() {
  return <ItalianCourse />
}
