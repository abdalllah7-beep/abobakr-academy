'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Languages,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Globe,
  GraduationCap,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, ServiceSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Italian Language – All Levels',
  category: 'Languages',
  rating: 4.8,
  students: 30,
  lessons: 80,
  description: 'Learn Italian with native-speaking tutors. Master conversation, grammar, and explore the rich Italian culture and heritage—from art and history to cuisine and contemporary life.',
  highlights: [
    'Native Italian speakers',
    'Conversation focus',
    'Grammar mastery',
    'Cultural immersion',
    'All levels A1-C1',
    'Free trial available',
  ],
  programs: [
    { name: 'Beginner (A1-A2)', description: 'Basic vocabulary, greetings, simple conversations, essential grammar, and foundational skills for travel and daily situations.', level: 'Beginner' },
    { name: 'Intermediate (B1-B2)', description: 'Complex grammar, travel Italian, deeper conversations, expressing opinions, and engaging with Italian media and literature.', level: 'Intermediate' },
    { name: 'Advanced (C1)', description: 'Fluent expression, professional Italian, literature analysis, cultural nuances, and native-level communication skills.', level: 'Advanced' },
  ],
}

const faqData = [
  {
    question: 'Is Italian difficult to learn?',
    answer: 'Italian is considered one of the easier languages for English speakers to learn! Its phonetic nature means words are pronounced as they\'re written. The grammar has some complexities (like gendered nouns and verb conjugations), but the patterns are consistent. Many English words have Italian roots or cognates, making vocabulary acquisition easier. With regular practice, you can achieve conversational ability relatively quickly.',
  },
  {
    question: 'How long does it take to learn Italian?',
    answer: 'Learning timelines vary by individual. Basic conversational ability (A2) typically takes 3-6 months with regular study. Intermediate proficiency (B1-B2) usually takes 6-12 months. Advanced fluency (C1) can be achieved in 12-18 months with consistent practice. Italian\'s similarity to other Romance languages can speed up learning if you know Spanish or French.',
  },
  {
    question: 'Do you prepare students for Italian proficiency exams?',
    answer: 'Yes! We prepare students for CILS (Certificazione di Italiano come Lingua Straniera) and CELI exams, which are internationally recognized Italian proficiency certifications. Our teachers are familiar with these exam formats and provide targeted preparation including practice tests and exam strategies.',
  },
  {
    question: 'What will I learn besides the language?',
    answer: 'Our Italian courses include cultural immersion alongside language learning. You\'ll learn about Italian art, history, cuisine, cinema, music, and contemporary life. Understanding cultural context enriches your language learning and helps you communicate more naturally. Teachers often incorporate authentic Italian media and real-life scenarios.',
  },
  {
    question: 'Can I learn Italian for travel to Italy?',
    answer: 'Absolutely! Many of our students learn Italian specifically for travel. We offer travel-focused Italian courses covering essential phrases, restaurant vocabulary, asking directions, shopping, and cultural etiquette. Even basic Italian greatly enhances your travel experience and helps you connect with locals.',
  },
  {
    question: 'What materials do you use for Italian lessons?',
    answer: 'We use established Italian learning resources (like Nuovo Espresso, Al Dente, and Domani) combined with authentic materials including Italian films, music, news articles, and literature. Teachers also create custom exercises based on student interests. All materials are provided digitally as part of your course.',
  },
  {
    question: 'Do you offer Italian classes for children?',
    answer: 'Yes, we have Italian programs for children and teenagers. Our teachers use engaging methods including games, songs, stories, and interactive activities to make learning fun. We can support heritage learners maintaining their Italian roots or introduce children to a new language and culture.',
  },
  {
    question: 'How are online Italian classes structured?',
    answer: 'Classes are conducted via video call in a one-on-one format. Each 45-60 minute session includes conversation practice, grammar instruction, vocabulary building, and listening comprehension. Teachers share their screens for visual materials and interactive exercises. You\'ll have speaking practice in every lesson with immediate feedback.',
  },
]

export default function ItalianCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/italian',
    category: 'Languages',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const serviceSchemaData = {
    name: `Online ${courseData.name}`,
    description: 'One-on-one online Italian language tutoring with native speakers',
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/italian',
    category: 'Online Education',
    areaServed: 'Worldwide',
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Italian', url: 'https://www.abobakracademy.com/courses/italian' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Italian" />
      <CourseSchema course={courseSchemaData} />
      <ServiceSchema service={serviceSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Italian Classes Online"
        subtitle="Learn Italian with native-speaking tutors"
        breadcrumb="Courses / Italian"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <Languages className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Done</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">6+</p>
              <p className="text-white/70 text-sm">Italian Tutors</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Language Mastery</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Italian Levels</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn Italian with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Italian is the language of art, music, cuisine, and romance. From the Renaissance 
                    masters to contemporary fashion, from Verdi&apos;s operas to the perfect espresso, 
                    Italy has profoundly shaped world culture. Learning Italian opens doors to 
                    understanding this rich heritage in its original language.
                  </p>
                  <p>
                    Our native Italian-speaking teachers bring authentic language and cultural 
                    knowledge to every lesson. They understand the nuances that make Italian 
                    such a beautiful and expressive language. Whether you&apos;re interested in 
                    art history, culinary traditions, opera, or simply want to travel through 
                    Italy with confidence, we tailor your learning to your interests.
                  </p>
                  <p>
                    The one-on-one format ensures you get maximum speaking practice and 
                    personalized attention. Italian&apos;s melodic nature makes it enjoyable to 
                    speak, and our teachers help you develop natural, confident pronunciation 
                    that will serve you whether you&apos;re ordering in a Roman trattoria or 
                    discussing Renaissance art in Florence.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start learning Italian today with a free 20-minute trial session.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Native speakers</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;Imparo l&apos;italiano con gioia! Learning Italian has been such a beautiful experience. My teacher makes every lesson feel like a trip to Italy!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Marco</p>
                  <p className="text-xs md:text-sm text-gray-600">Italian Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Italian Classes"
        subtitle="Find answers to common questions about learning Italian online"
      />

      {/* Related Courses */}
      <RelatedCourses
        courses={relatedCoursesByCategory['languages']}
        title="Explore More Language Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Impara l&apos;Italiano Oggi!
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Start your Italian learning journey with a free trial. No commitment required.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
