'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  BookMarked,
  Languages,
  GraduationCap,
  Monitor,
  Palette,
  Star,
  Users,
  Clock,
  ArrowRight,
  Calendar,
  MessageCircle,
  BookOpen,
  Mic,
  Globe,
  Atom,
  Calculator,
  Code,
  FlaskConical,
  PenTool,
  Sparkles,
  CheckCircle2,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const courseCategories = [
  {
    id: 'islamic-studies',
    icon: BookMarked,
    name: 'Islamic Studies',
    description: 'Deepen your connection with the Quran and Islamic knowledge through our comprehensive Islamic education programs.',
    color: 'bg-emerald-500',
    rating: 5.0,
    courses: [
      { name: 'Quran – Read, Recite & Memorize', description: 'Learn Quran with certified Qaris, master recitation and memorization.', href: '/courses/quran' },
      { name: 'Tajweed', description: 'Perfect your pronunciation using classical Tajweed rules.', href: '/courses/tajweed' },
      { name: 'Qa\'ida', description: 'Beginner\'s guide to Arabic letters and phonetics for Quran reading.', href: '/courses/qaida' },
      { name: 'Islamic Studies', description: 'Fiqh, Hadith, Tafsir & Islamic history deep-dive.', href: '/courses/islamic-studies' },
    ],
    features: ['Certified Qaris', 'One-on-one Sessions', 'Flexible Scheduling', 'All Levels Welcome'],
  },
  {
    id: 'language-mastery',
    icon: Languages,
    name: 'Language Mastery',
    description: 'Master new languages with native-speaking tutors. From beginner to advanced conversation fluency.',
    color: 'bg-blue-500',
    rating: 4.9,
    courses: [
      { name: 'Arabic Language', description: 'Modern Standard Arabic with native instructors.', href: '/courses/arabic' },
      { name: 'English Language', description: 'IELTS prep, conversation, business English and more.', href: '/courses/english' },
      { name: 'German Language', description: 'From A1 to C1 levels with certified tutors.', href: '/courses/german' },
      { name: 'French Language', description: 'Learn French, DELF/DALF exam preparation.', href: '/courses/french' },
      { name: 'Spanish Language', description: 'Learn Spanish from beginner to advanced.', href: '/courses/spanish' },
      { name: 'Italian Language', description: 'Learn Italian with native speakers.', href: '/courses/italian' },
    ],
    features: ['Speaking Labs', 'Grammar Workshops', 'Conversation Clubs', 'All Levels'],
  },
  {
    id: 'school-curriculum',
    icon: GraduationCap,
    name: 'School Curriculum Support',
    description: 'Boost grades with one-on-one tutoring aligned with school curricula. Expert support for all subjects.',
    color: 'bg-purple-500',
    rating: 4.8,
    courses: [
      { name: 'Mathematics', description: 'K-12 math tutoring, algebra, calculus, exam prep.', href: '/courses/mathematics' },
      { name: 'Science', description: 'Physics, Chemistry, Biology tutoring for all grades.', href: '/courses/science' },
      { name: 'Physics', description: 'Mechanics, electricity, waves, modern physics.', href: '/courses/physics' },
      { name: 'Chemistry', description: 'Organic, inorganic, physical chemistry.', href: '/courses/chemistry' },
      { name: 'Biology', description: 'Cell biology, genetics, anatomy, ecology.', href: '/courses/biology' },
      { name: 'Geography', description: 'Physical & human geography, map skills.', href: '/courses/geography' },
    ],
    features: ['K-12 Support', 'Homework Help', 'Exam Preparation', 'Progress Tracking'],
  },
  {
    id: 'computer-science',
    icon: Monitor,
    name: 'Computer Science & Digital Skills',
    description: 'Build essential digital skills for the modern world. From basic computer literacy to programming.',
    color: 'bg-indigo-500',
    rating: 4.8,
    courses: [
      { name: 'ICDL Certification', description: 'International Computer Driving License preparation.', href: '/courses/icdl' },
      { name: 'Microsoft Office', description: 'Master Word, Excel, PowerPoint for professional use.', href: '/courses/microsoft-office' },
      { name: 'Programming', description: 'Python, JavaScript fundamentals and practical projects.', href: '/courses/programming' },
    ],
    features: ['Hands-on Projects', 'Certification Prep', 'Real-world Skills', 'Beginner Friendly'],
  },
  {
    id: 'creative-arts',
    icon: Palette,
    name: 'Creative Arts & Crafts',
    description: 'Unleash creativity through art workshops and hands-on craft sessions with expert instructors.',
    color: 'bg-pink-500',
    rating: 4.7,
    courses: [
      { name: 'Art Workshops', description: 'Drawing, painting, digital art fundamentals.', href: '/courses#creative-arts' },
      { name: 'Handcrafts', description: 'Calligraphy, DIY decor, traditional crafts.', href: '/courses#creative-arts' },
    ],
    features: ['Live Sessions', 'All Ages', 'Materials List Provided', 'Fun & Engaging'],
  },
]

const featuredCourses = [
  { name: 'Quran with Tajweed', rating: 5.0, href: '/courses/quran', category: 'Islamic Studies' },
  { name: 'English Conversation', rating: 4.9, href: '/courses/english', category: 'Languages' },
  { name: 'Mathematics', rating: 4.8, href: '/courses/mathematics', category: 'School Support' },
  { name: 'Programming', rating: 4.8, href: '/courses/programming', category: 'Computer Science' },
  { name: 'Arabic Language', rating: 4.9, href: '/courses/arabic', category: 'Languages' },
  { name: 'French Language', rating: 4.9, href: '/courses/french', category: 'Languages' },
  { name: 'Science Tutoring', rating: 4.8, href: '/courses/science', category: 'School Support' },
  { name: 'ICDL Certification', rating: 4.9, href: '/courses/icdl', category: 'Computer Science' },
]

export default function CoursesClient() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader 
        title="Our Courses" 
        subtitle="Explore our comprehensive range of courses taught by certified expert tutors"
        breadcrumb="Courses"
      />

      {/* Stats */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <p className="text-2xl md:text-4xl font-bold text-white mb-1">5+</p>
              <p className="text-white/70 text-sm md:text-base">Categories</p>
            </div>
            <div className="text-center">
              <p className="text-2xl md:text-4xl font-bold text-white mb-1">20+</p>
              <p className="text-white/70 text-sm md:text-base">Courses</p>
            </div>
            <div className="text-center">
              <p className="text-2xl md:text-4xl font-bold text-white mb-1">50+</p>
              <p className="text-white/70 text-sm md:text-base">Expert Tutors</p>
            </div>
            <div className="text-center">
              <p className="text-2xl md:text-4xl font-bold text-white mb-1">2500+</p>
              <p className="text-white/70 text-sm md:text-base">Lessons Done</p>
            </div>
          </div>
        </div>
      </section>

      {/* Course Categories */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Course Categories</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Browse by <span className="text-[#1DA678]">Category</span>
            </h2>
            <p className="text-base md:text-xl text-gray-600 max-w-2xl mx-auto">
              Choose from our carefully designed course categories to find the perfect learning path.
            </p>
          </div>
          
          <div className="space-y-6 md:space-y-8">
            {courseCategories.map((category) => (
              <Card 
                key={category.id}
                id={category.id}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden scroll-mt-24"
              >
                <CardContent className="p-0">
                  <div className="grid lg:grid-cols-3">
                    {/* Category Header */}
                    <div className={`${category.color} p-6 md:p-8 text-white`}>
                      <div className="flex items-center gap-4 mb-4">
                        <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white/20 flex items-center justify-center">
                          <category.icon className="w-7 h-7 md:w-8 md:h-8" />
                        </div>
                        <div>
                          <h3 className="text-xl md:text-2xl font-bold">{category.name}</h3>
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`w-3 h-3 md:w-4 md:h-4 ${i < Math.floor(category.rating) ? 'text-yellow-300 fill-yellow-300' : 'text-white/30'}`} 
                              />
                            ))}
                            <span className="text-white/80 text-xs md:text-sm ml-1">{category.rating}</span>
                          </div>
                        </div>
                      </div>
                      <p className="text-white/80 text-sm md:text-base mb-4 md:mb-6">{category.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {category.features.map((feature) => (
                          <Badge key={feature} className="bg-white/20 text-white text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    {/* Courses List */}
                    <div className="lg:col-span-2 p-6 md:p-8">
                      <h4 className="text-lg font-semibold text-gray-900 mb-4">Courses in this category:</h4>
                      <div className="grid md:grid-cols-2 gap-4 mb-6">
                        {category.courses.map((course, idx) => (
                          <Link key={idx} href={course.href} className="block">
                            <div className="p-4 rounded-xl bg-gray-50 hover:bg-[#E8F8F2] transition-colors h-full">
                              <h5 className="font-semibold text-gray-900 mb-1">{course.name}</h5>
                              <p className="text-gray-600 text-sm">{course.description}</p>
                            </div>
                          </Link>
                        ))}
                      </div>
                      <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white" asChild>
                        <Link href={`/contact#trial`}>
                          Book Free Trial
                          <ArrowRight className="ml-2 w-4 h-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">
              <Sparkles className="w-3 h-3 mr-1" />
              Featured
            </Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Popular <span className="text-[#1DA678]">Courses</span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {featuredCourses.map((course, index) => (
              <Link key={index} href={course.href}>
                <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 h-full cursor-pointer">
                  <CardContent className="p-4 md:p-6">
                    <div className="flex items-center gap-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-3 h-3 md:w-4 md:h-4 ${i < Math.floor(course.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                      ))}
                      <span className="text-xs md:text-sm text-gray-600 ml-1">{course.rating}</span>
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2 text-sm md:text-base">{course.name}</h3>
                    <Badge variant="outline" className="text-xs">{course.category}</Badge>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Why Choose Us</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              The Abobakr Academy <span className="text-[#1DA678]">Difference</span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            {[
              { icon: GraduationCap, title: 'Certified Expert Tutors', description: 'Learn from qualified teachers with years of experience in their fields.' },
              { icon: Clock, title: 'Flexible Scheduling', description: 'Book lessons at times that work for you. Reschedule up to 24 hours before.' },
              { icon: Users, title: 'Personalized Learning', description: 'One-on-one sessions tailored to your pace and learning style.' },
              { icon: Globe, title: 'Learn from Anywhere', description: 'Online classes via Zoom and Google Meet. Access from any device.' },
              { icon: CheckCircle2, title: 'Progress Tracking', description: 'Regular assessments and detailed progress reports for students.' },
              { icon: Calendar, title: 'Free Trial Class', description: 'Try any course with a free 20-minute trial session. No commitment.' },
            ].map((item, index) => (
              <div key={index} className="text-center p-4 md:p-6">
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-7 h-7 md:w-8 md:h-8 text-white" />
                </div>
                <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm md:text-base">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
            Ready to Start Learning?
          </h2>
          <p className="text-base md:text-xl text-white/80 mb-6 md:mb-8">
            Book your free trial class today and discover the perfect course for you.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button 
              size="lg" 
              className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full shadow-lg"
              asChild
            >
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
