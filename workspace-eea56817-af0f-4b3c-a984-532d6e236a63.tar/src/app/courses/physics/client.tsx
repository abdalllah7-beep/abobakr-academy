'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Atom, Star, Users, Clock, Calendar, MessageCircle, CheckCircle2, Globe, Heart, GraduationCap } from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Physics – Mechanics, Electricity & Modern Physics',
  category: 'School Support',
  rating: 4.9,
  students: 90,
  lessons: 280,
  description: 'Master physics concepts from basic mechanics to advanced topics with our expert tutors. We break down complex physics principles into understandable lessons, helping you excel in your studies and exams.',
  highlights: [
    'Qualified Physics Educators',
    'Curriculum-Aligned Lessons',
    'Problem-Solving Focus',
    'Exam Preparation Included',
    'All Grade Levels Supported',
    'Free Trial Available',
  ],
  programs: [
    { name: 'Classical Mechanics', description: 'Motion, forces, energy, momentum, Newton\'s laws, and rotational dynamics. Build a strong foundation in the fundamental principles of physics.', level: 'All Levels' },
    { name: 'Electricity & Magnetism', description: 'Electric fields, circuits, magnetism, electromagnetic induction, and Maxwell\'s equations. Essential for understanding modern technology.', level: 'All Levels' },
    { name: 'Waves & Optics', description: 'Wave properties, sound, light, optical phenomena, interference, and diffraction. Connect theory to real-world applications.', level: 'All Levels' },
    { name: 'Modern Physics', description: 'Quantum mechanics, relativity, atomic structure, nuclear physics, and particle physics. Explore the frontiers of physics.', level: 'Advanced' },
  ],
}

const faqData = [
  {
    question: 'How do online physics tutoring sessions work?',
    answer: 'Our physics sessions are conducted one-on-one via Zoom or Google Meet. Tutors use digital whiteboards to work through problems, explain concepts visually, and solve equations together. Sessions are 45-60 minutes, allowing time for concept explanation, guided problem-solving, and questions. You can share your screen to show homework problems you\'re struggling with.',
  },
  {
    question: 'What physics topics do you cover?',
    answer: 'We cover all physics topics from middle school through university level: mechanics (motion, forces, energy), electricity and magnetism, waves and optics, thermodynamics, modern physics (quantum mechanics, relativity), and more. We align with your specific curriculum, whether it\'s IB, AP, A-Levels, IGCSE, or national curriculum.',
  },
  {
    question: 'Can you help with physics homework and exam preparation?',
    answer: 'Absolutely! Homework help and exam preparation are core parts of our service. Tutors can guide you through difficult problems, teach problem-solving strategies, and create practice problems. For exam preparation, we review key concepts, practice past papers, and focus on areas where you need the most improvement.',
  },
  {
    question: 'What qualifications do your physics tutors have?',
    answer: 'Our physics tutors have degrees in physics, engineering, or related fields. Many have advanced degrees and teaching experience at schools and universities. They understand how to break down complex concepts into understandable steps and have experience with various curricula including IB, AP, IGCSE, and national programs.',
  },
  {
    question: 'How do you make physics easier to understand?',
    answer: 'Physics becomes easier when concepts are connected to real-world examples and built step-by-step. Our tutors use visual demonstrations, analogies, and practical applications to make abstract concepts concrete. We focus on understanding principles rather than memorizing formulas, which leads to better retention and problem-solving ability.',
  },
  {
    question: 'Can you help with AP Physics or IB Physics?',
    answer: 'Yes! We have tutors specifically experienced with AP Physics 1, 2, and C, as well as IB Physics Standard and Higher Level. We know the exam formats, common question types, and scoring criteria. Our students have achieved significant score improvements through targeted preparation.',
  },
  {
    question: 'What equipment do I need for online physics tutoring?',
    answer: 'You need a computer or tablet with internet access, camera, and microphone. A stylus can be helpful for writing equations on shared whiteboards but isn\'t required. Your tutor will share their screen and use digital tools, so you just need to be able to see and hear clearly.',
  },
  {
    question: 'How quickly can I improve my physics grades?',
    answer: 'Most students see noticeable improvement within 4-6 weeks of regular sessions. The exact timeline depends on your starting point, session frequency, and how much you practice between sessions. Our focus on conceptual understanding rather than just memorization leads to lasting improvement.',
  },
]

export default function PhysicsCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/physics',
    category: 'School Support',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Physics', url: 'https://www.abobakracademy.com/courses/physics' },
  ]

  return (
    <main className="min-h-screen bg-white">
      <FAQSchema faqs={faqData} courseName="Physics" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader title="Physics Tutoring" subtitle="Master mechanics, electricity, waves, and modern physics" breadcrumb="Courses / Physics" />
      
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center"><Users className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p><p className="text-white/70 text-sm">Active Students</p></div>
            <div className="text-center"><Atom className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p><p className="text-white/70 text-sm">Lessons Completed</p></div>
            <div className="text-center"><Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p><p className="text-white/70 text-sm">Average Rating</p></div>
            <div className="text-center"><GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">15+</p><p className="text-white/70 text-sm">Physics Tutors</p></div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">School Support</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">{courseData.name}</h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">{courseData.description}</p>

              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3"><CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" /><span className="text-gray-700 text-sm md:text-base">{highlight}</span></div>
                ))}
              </div>

              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Our Physics Topics</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2"><h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3><Badge variant="outline" className="text-xs">{program.level}</Badge></div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Choose Our Physics Tutoring?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Physics is the foundation of engineering, medicine, and technology. Yet many students struggle with physics because concepts are taught abstractly without connecting to real understanding. Our tutors change that by making physics intuitive and engaging.
                  </p>
                  <p>
                    At Abobakr Academy, we focus on building conceptual understanding alongside problem-solving skills. Our tutors don&apos;t just show you how to solve problems—they help you understand why solutions work. This approach leads to better grades and lasting knowledge.
                  </p>
                  <p>
                    Whether you&apos;re preparing for AP Physics, IB exams, IGCSE, or just trying to understand your school curriculum better, our one-on-one tutoring adapts to your needs. We&apos;ve helped students transform from physics-phobic to confident problem solvers.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">Start mastering physics today with a free 20-minute trial session.</p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600"><Clock className="w-4 h-4 text-[#1DA678]" /><span>Flexible scheduling</span></div>
                    <div className="flex items-center gap-2 text-sm text-gray-600"><Globe className="w-4 h-4 text-[#1DA678]" /><span>Learn from anywhere</span></div>
                    <div className="flex items-center gap-2 text-sm text-gray-600"><Heart className="w-4 h-4 text-[#1DA678]" /><span>100% satisfaction guaranteed</span></div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />Book Free Trial</Link></Button>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">{[...Array(5)].map((_, i) => (<Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />))}</div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">&quot;Physics finally makes sense! My tutor explains everything so clearly. I went from failing to getting an A on my final!&quot;</p>
                  <p className="font-semibold text-gray-900 text-sm">— Sarah</p><p className="text-xs md:text-sm text-gray-600">AP Physics Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <FAQSection faqs={faqData} title="Frequently Asked Questions About Physics Tutoring" subtitle="Everything you need to know about our physics program" />
      <RelatedCourses courses={relatedCoursesByCategory['school-support']} title="Explore More Science Courses" />

      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Master Physics Today</h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">Join students who have improved their physics grades with our expert tutors.</p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />Book Free Trial</Link></Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild><a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer"><MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />Chat on WhatsApp</a></Button>
          </div>
        </div>
      </section>

      <Footer /><WhatsAppButton />
    </main>
  )
}
