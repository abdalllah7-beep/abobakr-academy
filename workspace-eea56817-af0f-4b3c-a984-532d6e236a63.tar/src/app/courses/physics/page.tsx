import { Metadata } from 'next'
import PhysicsCourse from './client'

export const metadata: Metadata = {
  title: 'Online Physics Tutoring | Mechanics, Electricity & Modern Physics - Abobakr Academy',
  description: 'Expert online physics tutoring for K-12 and university students. Master mechanics, electricity, magnetism, waves, optics, and modern physics. AP Physics, IB Physics, IGCSE preparation. Free trial available.',
  keywords: [
    'physics tutor online',
    'online physics classes',
    'AP physics tutoring',
    'IB physics tutor',
    'IGCSE physics',
    'mechanics tutoring',
    'electricity and magnetism',
    'physics homework help',
    'physics exam preparation',
    'high school physics',
    'university physics',
    'quantum physics tutor',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/physics',
  },
  openGraph: {
    title: 'Online Physics Tutoring | Mechanics, Electricity & Modern Physics',
    description: 'Expert physics tutoring for all levels. AP, IB, IGCSE preparation with qualified tutors. Free trial!',
    url: 'https://www.abobakracademy.com/courses/physics',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Online Physics Tutoring - Abobakr Academy',
    description: 'Expert physics tutoring for all levels. Mechanics, electricity, waves, and modern physics. Free trial!',
  },
}

export default function Page() {
  return <PhysicsCourse />
}
