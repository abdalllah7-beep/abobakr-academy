import { Metadata } from 'next'
import MicrosoftOfficeCourse from './client'

export const metadata: Metadata = {
  title: 'Microsoft Office Training | Word, Excel, PowerPoint - Abobakr Academy',
  description: 'Master Microsoft Office suite. Word, Excel, PowerPoint, and more. Professional skills training with certified instructors.',
  keywords: 'microsoft office, excel training, word training, powerpoint, office skills',
  openGraph: { title: 'Microsoft Office Training', description: 'Master Microsoft Office suite.', type: 'website' },
}

export default function Page() { return <MicrosoftOfficeCourse /> }
