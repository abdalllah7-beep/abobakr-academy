'use client'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { FileSpreadsheet, Star, Users, Clock, Calendar, MessageCircle, CheckCircle2, Globe, GraduationCap, FileText, Presentation } from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

export default function MicrosoftOfficeCourse() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader title="Microsoft Office" subtitle="Master Word, Excel, PowerPoint and boost your productivity" breadcrumb="Courses / Microsoft Office" />
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center"><Users className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">60+</p><p className="text-white/70 text-sm">Students</p></div>
            <div className="text-center"><FileSpreadsheet className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">150+</p><p className="text-white/70 text-sm">Lessons</p></div>
            <div className="text-center"><Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" /><p className="text-2xl md:text-3xl font-bold text-white">4.9</p><p className="text-white/70 text-sm">Rating</p></div>
            <div className="text-center"><GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">15+</p><p className="text-white/70 text-sm">Instructors</p></div>
          </div>
        </div>
      </section>
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Computer Science</Badge>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">Microsoft Office Suite</h1>
              <p className="text-base md:text-lg text-gray-600 mb-6">Master Microsoft Office applications for professional and personal use. From basic formatting to advanced formulas and automation.</p>
              <div className="grid grid-cols-2 gap-3 mb-8">
                {['Hands-on practice', 'Real-world projects', 'Certificate prep', 'All skill levels', 'Expert instructors', 'Free trial'].map((h, i) => (<div key={i} className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-[#1DA678]" /><span className="text-gray-700 text-sm">{h}</span></div>))}
              </div>
              <h2 className="text-xl font-bold text-gray-900 mb-4">Applications Covered</h2>
              <div className="space-y-4">
                {[
                  { name: 'Microsoft Word', desc: 'Document creation, formatting, templates, mail merge', icon: FileText },
                  { name: 'Microsoft Excel', desc: 'Formulas, charts, pivot tables, data analysis', icon: FileSpreadsheet },
                  { name: 'Microsoft PowerPoint', desc: 'Presentations, animations, design principles', icon: Presentation },
                ].map((p, i) => (
                  <Card key={i} className="border-0 shadow-md"><CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-[#1DA678] flex items-center justify-center"><p.icon className="w-5 h-5 text-white" /></div>
                    <div><h3 className="font-semibold text-gray-900">{p.name}</h3><p className="text-gray-600 text-sm">{p.desc}</p></div>
                  </CardContent></Card>
                ))}
              </div>
              <div className="mt-10">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Related Courses</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { name: 'ICDL Certification', href: '/courses/icdl', desc: 'International certification' },
                    { name: 'Programming', href: '/courses/programming', desc: 'Python & JavaScript' },
                  ].map((c, i) => (
                    <Link key={i} href={c.href}><Card className="border-0 shadow-md hover:shadow-lg transition-all hover:-translate-y-1"><CardContent className="p-4"><h3 className="font-semibold text-gray-900 mb-1">{c.name}</h3><p className="text-gray-500 text-sm">{c.desc}</p></CardContent></Card></Link>
                  ))}
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <Card className="border-0 shadow-xl sticky top-24"><CardContent className="p-5">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                <p className="text-gray-600 text-sm mb-4">Start mastering Microsoft Office today.</p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-2 text-sm text-gray-600"><Clock className="w-4 h-4 text-[#1DA678]" /><span>Flexible scheduling</span></div>
                  <div className="flex items-center gap-2 text-sm text-gray-600"><Globe className="w-4 h-4 text-[#1DA678]" /><span>Learn from anywhere</span></div>
                </div>
                <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 mr-2" />Book Free Trial</Link></Button>
              </CardContent></Card>
            </div>
          </div>
        </div>
      </section>
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Master Microsoft Office Today</h2>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 py-5 rounded-full" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 mr-2" />Book Free Trial</Link></Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 py-5 rounded-full" asChild><a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer"><MessageCircle className="w-4 h-4 mr-2" />Chat on WhatsApp</a></Button>
          </div>
        </div>
      </section>
      <Footer /><WhatsAppButton />
    </main>
  )
}
