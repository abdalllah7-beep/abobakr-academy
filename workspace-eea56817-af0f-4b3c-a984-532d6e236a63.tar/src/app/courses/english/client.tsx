'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Languages,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  BookOpen,
  Mic,
  Globe,
  Award,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'English Language Mastery',
  category: 'Languages',
  rating: 4.9,
  students: 150,
  lessons: 500,
  description: 'Achieve fluency in English with our certified native-speaking tutors. Whether you\'re preparing for IELTS/TOEFL, improving business communication, or learning from scratch, our personalized one-on-one classes will help you reach your goals.',
  highlights: [
    'IELTS & TOEFL Preparation',
    'Native-speaking Teachers',
    'Business English',
    'Conversation Practice',
    'Grammar & Writing',
    'All Levels Welcome',
  ],
  programs: [
    {
      name: 'General English',
      description: 'Build a strong foundation in all four skills: reading, writing, speaking, and listening. Suitable for beginners to intermediate learners.',
      duration: '3-6 months',
      level: 'All Levels',
    },
    {
      name: 'IELTS Preparation',
      description: 'Comprehensive IELTS preparation covering all four sections. Practice tests, exam strategies, and personalized feedback to achieve your target band score.',
      duration: '2-4 months',
      level: 'Intermediate+',
    },
    {
      name: 'Business English',
      description: 'Professional communication skills for the workplace. Learn business writing, presentations, negotiations, and industry-specific vocabulary.',
      duration: '2-3 months',
      level: 'Intermediate+',
    },
    {
      name: 'Conversation Classes',
      description: 'Improve fluency and confidence through real-life conversations with native speakers. Focus on pronunciation, idioms, and natural expressions.',
      duration: 'Ongoing',
      level: 'All Levels',
    },
  ],
}

const faqData = [
  {
    question: 'How long does it take to learn English online?',
    answer: 'The time required depends on your starting level and goals. Beginners typically need 6-12 months to reach conversational fluency with regular practice. For IELTS preparation, most students need 2-4 months of focused study. Our teachers create personalized learning plans based on your specific objectives and timeline.',
  },
  {
    question: 'Do you offer IELTS preparation classes?',
    answer: 'Yes! Our IELTS preparation course is one of our most popular programs. We cover all four sections (Listening, Reading, Writing, Speaking) with practice tests, proven strategies, and detailed feedback. Many of our students have achieved band scores of 7.0-8.5 after completing our program.',
  },
  {
    question: 'Are your English teachers native speakers?',
    answer: 'Yes, we have native English speakers from the UK, USA, Canada, and Australia, as well as highly qualified non-native teachers with near-native proficiency and specialized certifications (CELTA, TEFL, TESOL). You can choose your preferred teacher based on accent and teaching style.',
  },
  {
    question: 'What English levels do you teach?',
    answer: 'We teach all levels from complete beginner (A1) to advanced (C2). During your free trial, we\'ll assess your current level and create a personalized learning plan. Whether you\'re starting from scratch or refining advanced skills, we have the right program for you.',
  },
  {
    question: 'How are online English classes conducted?',
    answer: 'Classes are conducted one-on-one via Zoom or Google Meet. Your teacher will use screen sharing, interactive exercises, and real-time feedback to make lessons engaging. Sessions typically last 45-60 minutes and include a mix of conversation, grammar, vocabulary, and skills practice.',
  },
  {
    question: 'Can I choose between British and American English?',
    answer: 'Absolutely! We have teachers who specialize in both British and American English. During enrollment, let us know your preference, and we\'ll match you with an appropriate teacher. This is especially important for IELTS (British) vs TOEFL (American) preparation.',
  },
  {
    question: 'What materials do I need for English classes?',
    answer: 'You only need a device with internet access, camera, and microphone. We provide all learning materials including textbooks, worksheets, practice tests, and supplementary resources. For IELTS preparation, we use official Cambridge materials and past papers.',
  },
  {
    question: 'How much do English classes cost?',
    answer: 'Our pricing depends on the program type, lesson frequency, and teacher selection. We offer flexible packages to suit different budgets. Contact us for a personalized quote. All packages include access to our learning materials, progress tracking, and a satisfaction guarantee.',
  },
]

export default function EnglishCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/english',
    category: 'Languages',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'English', url: 'https://www.abobakracademy.com/courses/english' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="English" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader 
        title="Online English Classes" 
        subtitle="Master English with certified native-speaking tutors - IELTS prep, business & conversation"
        breadcrumb="Courses / English"
      />

      {/* Course Overview */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <BookOpen className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <Award className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">20+</p>
              <p className="text-white/70 text-sm">Certified Tutors</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Languages</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Our English Programs</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs md:text-sm text-gray-500">Duration</p>
                          <p className="font-semibold text-[#1DA678] text-sm md:text-base">{program.duration}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Learn English */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn English with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    English is the global language of business, science, and communication. Whether 
                    you&apos;re looking to advance your career, study abroad, or simply communicate 
                    more effectively, mastering English opens doors to countless opportunities worldwide.
                  </p>
                  <p>
                    At Abobakr Academy, we take a personalized approach to English learning. Our 
                    certified teachers assess your current level, understand your goals, and create 
                    a customized learning plan. One-on-one classes mean you get immediate feedback, 
                    can ask questions freely, and progress at your optimal pace.
                  </p>
                  <p>
                    Our IELTS preparation program has helped students achieve band scores of 7.0-8.5, 
                    opening doors to universities in the UK, Australia, Canada, and beyond. Our 
                    business English students have successfully improved their professional communication, 
                    leading to promotions and new career opportunities.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start your English journey with a free 20-minute trial session including a speaking assessment.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mic className="w-4 h-4 text-[#1DA678]" />
                      <span>Speaking assessment included</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Native-speaking tutors</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>Satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;I improved my IELTS score from 6.0 to 7.5 in just two months! The teacher knew exactly what I needed to work on. Highly recommend!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Sarah</p>
                  <p className="text-xs md:text-sm text-gray-600">IELTS Student, Band 7.5</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Topic - IELTS */}
      <section className="py-12 bg-[#E8F8F2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-6 md:p-8 bg-white rounded-2xl shadow-lg">
            <div className="flex-1">
              <Badge className="mb-2 bg-[#1DA678] text-white">Featured Program</Badge>
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">IELTS Preparation Course</h3>
              <p className="text-gray-600 text-sm md:text-base">
                Achieve your target IELTS band score with our comprehensive preparation course. Master all four modules with expert guidance and proven strategies.
              </p>
            </div>
            <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 rounded-full whitespace-nowrap" asChild>
              <Link href="/topics/ielts-preparation">
                Learn More About IELTS
                <Award className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection 
        faqs={faqData} 
        title="Frequently Asked Questions About English Classes"
        subtitle="Everything you need to know about learning English online"
      />

      {/* Related Courses */}
      <RelatedCourses 
        courses={relatedCoursesByCategory['languages']} 
        title="Explore More Language Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Master English?
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Book your free trial today and start speaking English with confidence. 
            Your personalized learning journey begins here.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
