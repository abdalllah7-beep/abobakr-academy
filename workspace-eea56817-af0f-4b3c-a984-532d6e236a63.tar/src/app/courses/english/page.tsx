import { Metadata } from 'next'
import EnglishCourse from './client'

export const metadata: Metadata = {
  title: 'Learn English Online | IELTS Prep, Business English & Conversation - Abobakr Academy',
  description: 'Master English online with certified tutors. IELTS/TOEFL preparation with proven results, business English, conversation practice, and grammar. All levels from beginner to advanced. Native-speaking teachers. Free trial available.',
  keywords: [
    'learn english online',
    'online english classes',
    'IELTS preparation course',
    'TOEFL preparation',
    'english tutor online',
    'business english classes',
    'english conversation practice',
    'english for beginners',
    'IELTS speaking practice',
    'english grammar course',
    'native english teacher',
    'english writing skills',
    'online english tutoring',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/english',
  },
  openGraph: {
    title: 'Learn English Online | IELTS Prep & Business English',
    description: 'Master English with certified tutors. IELTS preparation, business English, conversation practice. Native teachers. Free trial!',
    url: 'https://www.abobakracademy.com/courses/english',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Learn English Online - IELTS Prep & Business English',
    description: 'Master English with certified tutors. IELTS preparation, business English, conversation practice. Free trial!',
  },
}

export default function Page() {
  return <EnglishCourse />
}
