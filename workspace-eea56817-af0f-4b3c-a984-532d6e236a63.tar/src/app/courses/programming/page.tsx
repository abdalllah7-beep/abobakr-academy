import { Metadata } from 'next'
import ProgrammingCourse from './client'

export const metadata: Metadata = {
  title: 'Learn Programming Online | Python, JavaScript, Coding Courses - Abobakr Academy',
  description: 'Learn programming online with expert tutors. Python, JavaScript, web development, ICDL certification, Microsoft Office. Beginner to advanced courses. Free trial available.',
  keywords: 'learn programming online, python course, javascript course, coding classes, web development course, ICDL certification, programming tutor',
  openGraph: {
    title: 'Learn Programming Online | Coding Courses - Abobakr Academy',
    description: 'Learn programming online with expert tutors. Python, JavaScript & more.',
    type: 'website',
  },
}

export default function Page() {
  return <ProgrammingCourse />
}
