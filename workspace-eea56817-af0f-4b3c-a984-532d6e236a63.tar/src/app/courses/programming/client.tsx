'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Code, Star, Users, Clock, Calendar, MessageCircle, CheckCircle2, Monitor, Globe, Award, Briefcase, Heart } from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Programming & Digital Skills',
  category: 'Digital Skills',
  rating: 4.8,
  students: 45,
  lessons: 180,
  description: 'Build essential digital skills for the modern world. From basic computer literacy to professional programming, our courses prepare you for success in the digital age with hands-on, project-based learning.',
  highlights: ['Python Programming', 'JavaScript & Web Dev', 'ICDL Certification', 'MS Office Mastery', 'Hands-on Projects', 'Beginner Friendly', 'All Ages Welcome', 'Flexible Scheduling'],
  programs: [
    { name: 'Python Fundamentals', desc: 'Learn Python from scratch with variables, functions, OOP, and real projects. Perfect for beginners and aspiring developers.', level: 'Beginner' },
    { name: 'JavaScript Essentials', desc: 'Master JavaScript for web development including DOM manipulation, APIs, and modern ES6+ features.', level: 'Beginner' },
    { name: 'Web Development', desc: 'Build complete websites with HTML, CSS, JavaScript. Learn frontend and backend fundamentals.', level: 'Intermediate' },
    { name: 'Database & SQL', desc: 'Understand database design, SQL queries, and data management for applications.', level: 'Intermediate' },
  ],
}

const faqData = [
  { question: 'Do I need any prior experience to learn programming?', answer: 'No prior experience is required! Our Python Fundamentals course is designed for complete beginners. We start from the very basics—what is programming, how computers understand code—and build up step by step. Our patient tutors guide you through each concept with plenty of practice.' },
  { question: 'What programming languages do you teach?', answer: 'We primarily teach Python (great for beginners and data science) and JavaScript (essential for web development). We can also provide tutoring in HTML/CSS, SQL, and other languages based on student interest. Our focus is on building strong fundamentals that transfer to any language.' },
  { question: 'How are online programming classes conducted?', answer: 'Sessions are conducted one-on-one via Zoom with screen sharing. Tutors use online code editors (like Replit or CodePen) where both student and tutor can write and run code together in real-time. This interactive approach means you learn by doing, not just watching.' },
  { question: 'What age groups can learn programming?', answer: 'We teach programming to students of all ages, from children (8+) to adults. For younger students, we use age-appropriate tools like Scratch before transitioning to text-based languages. Many adults learn programming with us for career changes or personal projects.' },
  { question: 'How long does it take to learn programming?', answer: 'For Python basics, most students become comfortable with fundamentals in 2-3 months of regular sessions. Web development typically takes 4-6 months. Becoming job-ready requires 6-12 months depending on the path. Our tutors create personalized learning plans based on your goals.' },
  { question: 'Can programming help my career?', answer: 'Absolutely! Programming skills are in high demand across industries—not just tech companies. Whether you want to become a developer, enhance your current role with automation skills, or prepare for university CS programs, our courses provide practical, marketable skills.' },
  { question: 'What projects will I build during the course?', answer: 'Learning is project-based. Python students build games, calculators, and data analysis tools. Web development students create personal websites, interactive forms, and web applications. You\'ll leave with a portfolio of projects to showcase your skills.' },
  { question: 'Do you prepare students for ICDL certification?', answer: 'Yes! We offer comprehensive ICDL (International Computer Driving License) preparation. This globally recognized certification covers computer essentials, online collaboration, word processing, spreadsheets, and presentations. Our students have a high pass rate on ICDL exams.' },
]

export default function ProgrammingCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/programming',
    category: 'Digital Skills',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }
  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Programming', url: 'https://www.abobakracademy.com/courses/programming' },
  ]

  return (
    <main className="min-h-screen bg-white">
      <FAQSchema faqs={faqData} courseName="Programming" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />
      <Navigation />
      <PageHeader title="Programming & Digital Skills" subtitle="Learn coding, ICDL certification, and digital literacy" breadcrumb="Courses / Programming" />

      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center"><Users className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p><p className="text-white/70 text-sm">Active Students</p></div>
            <div className="text-center"><Code className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p><p className="text-white/70 text-sm">Lessons Completed</p></div>
            <div className="text-center"><Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p><p className="text-white/70 text-sm">Average Rating</p></div>
            <div className="text-center"><Award className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">10+</p><p className="text-white/70 text-sm">Certifications</p></div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Digital Skills</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">{courseData.name}</h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">{courseData.description}</p>

              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((item, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3"><CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" /><span className="text-gray-700 text-sm md:text-base">{item}</span></div>
                ))}
              </div>

              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Our Programs</h2>
              <div className="space-y-4">
                {courseData.programs.map((course, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-5">
                      <div className="flex items-center gap-2 mb-1"><h3 className="font-semibold text-gray-900 text-sm md:text-base">{course.name}</h3><Badge variant="outline" className="text-xs">{course.level}</Badge></div>
                      <p className="text-gray-600 text-sm md:text-base">{course.desc}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="mt-8 md:mt-10 p-4 md:p-6 bg-[#E8F8F2] rounded-xl md:rounded-2xl">
                <div className="flex items-center gap-3 mb-3"><Briefcase className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" /><h3 className="font-semibold text-gray-900 text-base md:text-lg">Career Opportunities</h3></div>
                <p className="text-gray-600 text-sm md:text-base">Our programming courses prepare students for careers in software development, data analysis, web development, and IT support. Many students have gone on to pursue tech careers, freelance opportunities, or computer science degrees.</p>
              </div>
            </div>

            <div className="space-y-6">
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Start Learning Today</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">Begin your programming journey with a free 20-minute trial session.</p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600"><Monitor className="w-4 h-4 text-[#1DA678]" /><span>Interactive coding sessions</span></div>
                    <div className="flex items-center gap-2 text-sm text-gray-600"><Globe className="w-4 h-4 text-[#1DA678]" /><span>Learn from anywhere</span></div>
                    <div className="flex items-center gap-2 text-sm text-gray-600"><Heart className="w-4 h-4 text-[#1DA678]" /><span>Project-based learning</span></div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />Book Free Trial</Link></Button>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">{[...Array(5)].map((_, i) => (<Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />))}</div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">&quot;I went from knowing nothing about coding to building my own website in just 4 months. Amazing tutors!&quot;</p>
                  <p className="font-semibold text-gray-900 text-sm">— Khalid</p><p className="text-xs md:text-sm text-gray-600">Python Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Topic - Python */}
      <section className="py-12 bg-[#E8F8F2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-6 md:p-8 bg-white rounded-2xl shadow-lg">
            <div className="flex-1">
              <Badge className="mb-2 bg-[#1DA678] text-white">Featured Course</Badge>
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">Python Programming Course</h3>
              <p className="text-gray-600 text-sm md:text-base">
                Learn Python from scratch with our comprehensive course. Master fundamentals, build real projects, and start your coding journey today.
              </p>
            </div>
            <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 rounded-full whitespace-nowrap" asChild>
              <Link href="/topics/python-programming">
                Explore Python Course
                <Code className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <FAQSection faqs={faqData} title="Frequently Asked Questions About Programming" subtitle="Everything you need to know about learning to code" />
      <RelatedCourses courses={relatedCoursesByCategory['digital-skills']} title="Explore More Digital Skills Courses" />

      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Ready to Code?</h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">Book your free trial and start your programming journey today.</p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />Book Free Trial</Link></Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild><a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer"><MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />Chat on WhatsApp</a></Button>
          </div>
        </div>
      </section>

      <Footer /><WhatsAppButton />
    </main>
  )
}
