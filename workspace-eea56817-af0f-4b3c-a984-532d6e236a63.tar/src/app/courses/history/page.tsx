import { Metadata } from 'next'
import HistoryCourse from './client'

export const metadata: Metadata = {
  title: 'Online History Tutoring | World & Regional History - Abobakr Academy',
  description: 'Expert history tutoring for all grades. Ancient civilizations, world history, regional studies, and historical analysis. One-on-one sessions.',
  keywords: 'history tutor, world history, ancient civilizations, historical studies',
  openGraph: { title: 'Online History Tutoring', description: 'Expert history tutoring for all grades.', type: 'website' },
}

export default function Page() { return <HistoryCourse /> }
