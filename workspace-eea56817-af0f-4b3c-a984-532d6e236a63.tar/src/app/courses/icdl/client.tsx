'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Monitor,
  Star,
  Users,
  Clock,
  ArrowRight,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Award,
  Globe,
  Heart,
  FileSpreadsheet,
  FileText,
  Presentation,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const courseData = {
  name: 'ICDL – International Computer Driving License',
  category: 'Computer Science & Digital Skills',
  rating: 4.9,
  students: 80,
  lessons: 200,
  description: 'Get ICDL certified and prove your digital literacy to employers worldwide. Our comprehensive course covers all ICDL modules with hands-on practice and exam preparation.',
  highlights: [
    'ICDL certified instructors',
    'Hands-on practice exercises',
    'Exam preparation included',
    'Internationally recognized',
    'All modules covered',
    'Free trial class available',
  ],
  programs: [
    {
      name: 'ICDL Base Modules',
      description: 'Computer Essentials, Online Essentials, Word Processing, Spreadsheets.',
      duration: '2-3 months',
      level: 'Foundation',
    },
    {
      name: 'ICDL Standard Modules',
      description: 'Presentation, Using Databases, IT Security, Online Collaboration.',
      duration: '2-3 months',
      level: 'Intermediate',
    },
    {
      name: 'ICDL Advanced Modules',
      description: 'Advanced Word Processing, Advanced Spreadsheets, Advanced Database, Advanced Presentation.',
      duration: '3-4 months',
      level: 'Advanced',
    },
    {
      name: 'Full ICDL Package',
      description: 'Complete ICDL certification preparation with all modules and exam practice.',
      duration: '4-6 months',
      level: 'All Levels',
    },
  ],
  relatedCourses: [
    { name: 'Microsoft Office', href: '/courses/microsoft-office', description: 'Master MS Office suite' },
    { name: 'Programming', href: '/courses/programming', description: 'Python & JavaScript' },
    { name: 'Computer Science', href: '/courses#computer-science', description: 'All digital skills' },
  ],
}

export default function ICDLCourse() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader 
        title="ICDL Certification" 
        subtitle="International Computer Driving License - Prove your digital skills"
        breadcrumb="Courses / ICDL"
      />

      {/* Course Overview */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Students</p>
            </div>
            <div className="text-center">
              <Monitor className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Done</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Rating</p>
            </div>
            <div className="text-center">
              <Award className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">95%</p>
              <p className="text-white/70 text-sm">Pass Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Computer Science</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">ICDL Modules</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs md:text-sm text-gray-500">Duration</p>
                          <p className="font-semibold text-[#1DA678] text-sm md:text-base">{program.duration}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Related Courses */}
              <div className="mt-10 md:mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Related Courses</h2>
                <div className="grid md:grid-cols-3 gap-4">
                  {courseData.relatedCourses.map((course, index) => (
                    <Link key={index} href={course.href}>
                      <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 h-full">
                        <CardContent className="p-4">
                          <h3 className="font-semibold text-gray-900 mb-1">{course.name}</h3>
                          <p className="text-gray-500 text-sm">{course.description}</p>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start your ICDL certification journey with a free trial session.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;Passed my ICDL exams on the first try! The structured approach really helped.&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Khalid</p>
                  <p className="text-xs md:text-sm text-gray-600">ICDL Certified</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Get ICDL Certified Today
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join thousands of professionals who have enhanced their careers with ICDL certification.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
