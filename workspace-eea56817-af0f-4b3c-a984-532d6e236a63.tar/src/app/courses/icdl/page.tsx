import { Metadata } from 'next'
import ICDLCourse from './client'

export const metadata: Metadata = {
  title: 'ICDL Certification Course | International Computer Driving License - Abobakr Academy',
  description: 'Prepare for ICDL certification online. Learn essential computer skills including word processing, spreadsheets, presentations, and more. Certified instructors, flexible scheduling.',
  keywords: 'icdl course, icdl certification, computer driving license, digital literacy, computer skills, online icdl training',
  openGraph: {
    title: 'ICDL Certification Course | International Computer Driving License',
    description: 'Prepare for ICDL certification with certified instructors and flexible scheduling.',
    type: 'website',
  },
}

export default function Page() {
  return <ICDLCourse />
}
