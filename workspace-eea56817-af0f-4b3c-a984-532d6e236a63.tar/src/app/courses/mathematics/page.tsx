import { Metadata } from 'next'
import MathCourse from './client'

export const metadata: Metadata = {
  title: 'Online Math Tutoring | K-12 Maths Tutor, Algebra & Calculus - Abobakr Academy',
  description: 'Expert online math tutoring for K-12 students. Algebra, Geometry, Calculus, Statistics, and more. One-on-one personalized sessions with certified teachers. 95% grade improvement rate. Free trial available.',
  keywords: [
    'math tutor online',
    'online maths classes',
    'algebra tutoring',
    'geometry help',
    'calculus tutor',
    'K-12 math tutoring',
    'math homework help',
    'online math teacher',
    'SAT math prep',
    'ACT math tutoring',
    'IB math tutor',
    'AP calculus tutor',
    'math for kids',
    'high school math',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/mathematics',
  },
  openGraph: {
    title: 'Online Math Tutoring | K-12 Maths Classes - Abobakr Academy',
    description: 'Expert math tutoring for K-12. Algebra, Geometry, Calculus & more. 95% grade improvement. Free trial!',
    url: 'https://www.abobakracademy.com/courses/mathematics',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Online Math Tutoring - K-12 Maths Tutor',
    description: 'Expert math tutoring for K-12. Algebra, Geometry, Calculus & more. 95% grade improvement!',
  },
}

export default function Page() {
  return <MathCourse />
}
