'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Calculator,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  BookOpen,
  Globe,
  Award,
  TrendingUp,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Mathematics Tutoring (K-12)',
  category: 'School Support',
  rating: 4.9,
  students: 85,
  lessons: 450,
  improvement: '95%',
  description: 'Master mathematics with our expert tutors. From basic arithmetic to advanced calculus, we provide personalized one-on-one instruction tailored to each student\'s level, curriculum, and learning style.',
  highlights: [
    'All Grade Levels (K-12)',
    'Curriculum Aligned',
    'Exam Preparation',
    'Homework Help',
    'One-on-One Sessions',
    'Progress Tracking',
  ],
  programs: [
    {
      name: 'Elementary Math',
      description: 'Build strong foundations with basic arithmetic, fractions, decimals, and problem-solving strategies. Perfect for grades 1-5.',
      duration: 'Ongoing',
      level: 'Grades 1-5',
    },
    {
      name: 'Middle School Math',
      description: 'Master Pre-Algebra, Algebra I, Geometry basics, and introductory Statistics. Build confidence for high school math.',
      duration: 'Ongoing',
      level: 'Grades 6-8',
    },
    {
      name: 'High School Math',
      description: 'Excel in Algebra II, Trigonometry, Pre-Calculus, and Calculus. Prepare for college-level mathematics.',
      duration: 'Ongoing',
      level: 'Grades 9-12',
    },
    {
      name: 'Test Preparation',
      description: 'SAT/ACT Math, AP Calculus AB/BC, IB Mathematics, and college placement exam preparation.',
      duration: '2-4 months',
      level: 'Test Prep',
    },
  ],
}

const faqData = [
  {
    question: 'How do online math tutoring sessions work?',
    answer: 'Our online math sessions are conducted one-on-one via Zoom or Google Meet. Your tutor will use screen sharing, digital whiteboards, and interactive tools to explain concepts and work through problems together. Sessions are typically 45-60 minutes, allowing time for instruction, guided practice, and questions.',
  },
  {
    question: 'What math topics do you cover?',
    answer: 'We cover all K-12 mathematics including: Elementary (arithmetic, fractions, word problems), Middle School (pre-algebra, algebra I, geometry basics), High School (algebra II, trigonometry, pre-calculus, calculus), and Test Prep (SAT/ACT, AP Calculus, IB Math). We align with your school curriculum.',
  },
  {
    question: 'How do you help students who struggle with math anxiety?',
    answer: 'Our tutors are trained to work with students who have math anxiety. We create a supportive, judgment-free environment where mistakes are learning opportunities. We break down complex problems into manageable steps, build confidence through small wins, and focus on understanding rather than memorization.',
  },
  {
    question: 'Can you help with homework and exam preparation?',
    answer: 'Absolutely! Homework help and exam preparation are core parts of our service. Tutors can help explain homework problems, review for upcoming tests, create practice problems, and teach test-taking strategies. We recommend regular sessions for best results, but we also offer intensive exam prep packages.',
  },
  {
    question: 'What curriculum do you follow?',
    answer: 'We align with your specific school curriculum, whether it\'s Common Core, IB, Cambridge, national curriculum, or another program. During your free trial, we\'ll discuss your textbooks, current topics, and upcoming assessments to create a personalized plan.',
  },
  {
    question: 'How quickly will I see improvement in my grades?',
    answer: 'Most students see noticeable improvement within 4-6 weeks of regular sessions. Our average grade improvement is 95% - many students improve by one or two letter grades. However, results depend on session frequency, practice outside class, and the student\'s starting point.',
  },
  {
    question: 'Do you offer math tutoring for college students?',
    answer: 'Yes, we tutor college-level mathematics including College Algebra, Statistics, Calculus I-III, and Linear Algebra. Many of our tutors have advanced degrees and experience teaching at the university level.',
  },
  {
    question: 'What makes your math tutoring effective?',
    answer: 'Our effectiveness comes from: one-on-one personalized attention, tutors who understand different learning styles, curriculum-aligned instruction, building conceptual understanding rather than rote memorization, regular progress tracking, and a supportive environment that builds confidence.',
  },
]

export default function MathCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/mathematics',
    category: 'School Support',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Mathematics', url: 'https://www.abobakracademy.com/courses/mathematics' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Mathematics" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader 
        title="Online Math Tutoring" 
        subtitle="Expert K-12 Math tutoring - Algebra, Geometry, Calculus & more"
        breadcrumb="Courses / Mathematics"
      />

      {/* Course Overview */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <Calculator className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <TrendingUp className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.improvement}</p>
              <p className="text-white/70 text-sm">Grade Improvement</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">School Support</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Topics We Cover</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Math Tutoring */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Choose Our Math Tutoring?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Mathematics is fundamental to academic success and future career opportunities. 
                    Yet many students struggle with math because of gaps in understanding, lack of 
                    personalized attention, or math anxiety. Our one-on-one tutoring addresses all 
                    these challenges.
                  </p>
                  <p>
                    At Abobakr Academy, we believe every student can excel in mathematics with the 
                    right guidance. Our tutors don&apos;t just teach procedures—they build conceptual 
                    understanding, helping students grasp the &quot;why&quot; behind mathematical concepts. 
                    This approach leads to lasting mastery rather than temporary memorization.
                  </p>
                  <p>
                    With a 95% grade improvement rate, our results speak for themselves. Students 
                    who once dreaded math class develop confidence and even enjoyment. Whether your 
                    child needs to catch up, keep up, or get ahead, our personalized approach will 
                    help them achieve their goals.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start improving your math skills with a free 20-minute trial session with an expert tutor.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>95% grade improvement</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;My math grades went from C to A in just two months! The tutor explained things in a way that finally made sense. Now I actually enjoy math!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Omar</p>
                  <p className="text-xs md:text-sm text-gray-600">High School Math Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Topic - Algebra */}
      <section className="py-12 bg-[#E8F8F2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-6 md:p-8 bg-white rounded-2xl shadow-lg">
            <div className="flex-1">
              <Badge className="mb-2 bg-[#1DA678] text-white">Featured Topic</Badge>
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">Algebra Tutoring</h3>
              <p className="text-gray-600 text-sm md:text-base">
                Master algebra concepts from basic equations to advanced functions. Get personalized help with linear equations, quadratic functions, polynomials, and more.
              </p>
            </div>
            <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 rounded-full whitespace-nowrap" asChild>
              <Link href="/topics/algebra-tutoring">
                Explore Algebra Tutoring
                <Calculator className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection 
        faqs={faqData} 
        title="Frequently Asked Questions About Math Tutoring"
        subtitle="Everything you need to know about our online math program"
      />

      {/* Related Courses */}
      <RelatedCourses 
        courses={relatedCoursesByCategory['school-support']} 
        title="Explore More School Support Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Excel in Math?
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Book your free trial and start improving your math skills today. 
            Join the 95% of students who see grade improvement.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
