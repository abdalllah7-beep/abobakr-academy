import { Metadata } from 'next'
import QaidaCourse from './client'

export const metadata: Metadata = {
  title: 'Noorani Qaida Classes | Learn Arabic Alphabet & Quran Reading - Abobakr Academy',
  description: 'Learn Noorani Qaida online with certified tutors. Master Arabic alphabet, pronunciation, and Quran reading fundamentals. Perfect for beginners of all ages. Free trial available.',
  keywords: [
    'noorani qaida',
    'learn arabic alphabet',
    'quran reading for beginners',
    'arabic letters',
    'qaida classes online',
    'quran basics',
    'learn quran online',
    'arabic for beginners',
    'quran for kids',
    'online qaida classes',
    'noorani qaida course',
    'arabic alphabet course',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/qaida',
  },
  openGraph: {
    title: 'Noorani Qaida Classes | Learn Arabic Alphabet & Quran Reading',
    description: 'Learn Noorani Qaida online with certified tutors. Master Arabic alphabet and Quran reading fundamentals. Perfect for beginners.',
    url: 'https://www.abobakracademy.com/courses/qaida',
    type: 'website',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: 'Noorani Qaida Classes - Abobakr Academy',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Noorani Qaida Classes - Abobakr Academy',
    description: 'Learn Noorani Qaida online with certified tutors. Master Arabic alphabet and Quran reading. Free trial!',
  },
}

export default function Page() {
  return <QaidaCourse />
}
