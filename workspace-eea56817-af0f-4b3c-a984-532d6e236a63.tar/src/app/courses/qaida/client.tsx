'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  BookOpen,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Globe,
  GraduationCap,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, ServiceSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Noorani Qaida – Foundation of Quran Reading',
  category: 'Islamic Studies',
  rating: 5.0,
  students: 80,
  lessons: 200,
  description: 'Perfect for beginners of all ages. Learn Arabic letters, pronunciation, and basic reading skills using the renowned Noorani Qaida method. The essential first step in your Quran journey.',
  highlights: [
    'Patient, experienced teachers',
    'Step-by-step learning approach',
    'Perfect for kids & adults',
    'Adult beginners welcome',
    'Interactive lessons',
    'Free trial class available',
  ],
  programs: [
    { name: 'Arabic Alphabet', description: 'Recognize and pronounce all 28 Arabic letters correctly from their proper points of articulation.', level: 'Beginner' },
    { name: 'Letter Forms', description: 'Learn letters in their different forms (beginning, middle, end of words) for fluent reading.', level: 'Beginner' },
    { name: 'Vowels & Diacritics', description: 'Master Fatha, Kasra, Damma, Sukoon, Shadda, and other essential Arabic marks.', level: 'Beginner' },
    { name: 'Basic Words & Sentences', description: 'Combine letters to form simple Quranic words and begin reading basic verses.', level: 'Beginner' },
  ],
}

const faqData = [
  {
    question: 'What is Noorani Qaida and why is it important?',
    answer: 'Noorani Qaida is a foundational book for learning Quranic Arabic, designed to teach beginners the Arabic alphabet, pronunciation rules, and basic reading skills. It\'s named after Sheikh Noor Muhammad Haqqani and has been used for generations as the first step in Quran education. Mastering Noorani Qaida ensures correct pronunciation from the start, making it easier to progress to Quran recitation with Tajweed.',
  },
  {
    question: 'At what age should my child start learning Noorani Qaida?',
    answer: 'Children can begin learning Noorani Qaida as early as 4-5 years old. At this age, they can start recognizing Arabic letters and developing an ear for proper pronunciation. Our teachers are experienced in working with young children, using engaging methods and age-appropriate pacing. However, it\'s never too late to start—we have students of all ages, from young children to adults.',
  },
  {
    question: 'How long does it take to complete Noorani Qaida?',
    answer: 'The time to complete Noorani Qaida varies depending on the student\'s age, practice consistency, and learning pace. On average, children take 3-6 months with regular classes, while adults may complete it faster, often in 2-4 months. Our teachers customize the pace to each student\'s needs, ensuring thorough understanding before moving to the next level.',
  },
  {
    question: 'Can adults learn Noorani Qaida online?',
    answer: 'Absolutely! Many adults learn Noorani Qaida with us, whether they\'re new Muslims wanting to read the Quran, reconnecting with their faith, or simply wanting to improve their recitation. Our teachers provide a comfortable, judgment-free environment where adults can learn at their own pace with one-on-one attention.',
  },
  {
    question: 'Do I need any prior knowledge to start Noorani Qaida?',
    answer: 'No prior knowledge is required. Noorani Qaida is designed for absolute beginners. Our teachers start from the very basics, teaching each letter and its pronunciation step by step. Whether you\'re completely new to Arabic or have some exposure, we\'ll meet you where you are and help you build a strong foundation.',
  },
  {
    question: 'What happens after completing Noorani Qaida?',
    answer: 'After completing Noorani Qaida, students are ready to begin reading the Quran directly. They can then progress to our Quran reading course, start learning Tajweed rules to perfect their recitation, or even begin memorization (Hifz). Our teachers will guide you to the appropriate next step based on your goals and progress.',
  },
  {
    question: 'How do online Noorani Qaida classes work?',
    answer: 'Our online classes are conducted via video call in a one-on-one setting. The teacher shares their screen showing the Noorani Qaida, and the student follows along. Teachers use interactive methods including repetition, visual aids, and pronunciation exercises. Classes typically last 30 minutes, and students are given practice exercises to complete between sessions.',
  },
  {
    question: 'What materials do I need for Noorani Qaida classes?',
    answer: 'You\'ll need a device with a camera and microphone (computer, tablet, or smartphone), a stable internet connection, and a quiet place for learning. We provide digital access to Noorani Qaida materials. Some students also prefer to have a physical copy for practice between classes. No other materials are required.',
  },
]

export default function QaidaCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/qaida',
    category: 'Islamic Studies',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const serviceSchemaData = {
    name: `Online ${courseData.name}`,
    description: 'One-on-one online Noorani Qaida tutoring for beginners',
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/qaida',
    category: 'Online Education',
    areaServed: 'Worldwide',
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: "Qa'ida", url: 'https://www.abobakracademy.com/courses/qaida' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Qaida" />
      <CourseSchema course={courseSchemaData} />
      <ServiceSchema service={serviceSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Noorani Qaida Classes"
        subtitle="Learn Quran reading from the very beginning with Arabic alphabet mastery"
        breadcrumb="Courses / Qaida"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <BookOpen className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">30+</p>
              <p className="text-white/70 text-sm">Expert Teachers</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Islamic Studies</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">What You&apos;ll Learn</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Start with Noorani Qaida at Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Noorani Qaida is the gateway to Quranic recitation, and learning it correctly from the beginning 
                    sets the foundation for a lifetime of proper Quran reading. At Abobakr Academy, our teachers 
                    understand the importance of patience and repetition when teaching beginners, especially young 
                    children.
                  </p>
                  <p>
                    Our structured approach ensures that students master each concept before moving forward. 
                    We focus not just on recognizing letters, but on proper pronunciation from the correct 
                    points of articulation (Makharij). This attention to detail prevents the need for 
                    correction later and makes the transition to Tajweed much smoother.
                  </p>
                  <p>
                    Whether you&apos;re a parent wanting to give your child the best start in Quran education, 
                    or an adult taking your first steps in learning to read the Quran, our personalized 
                    one-on-one classes provide the attention and support you need. Join the hundreds of 
                    students who have successfully learned to read Quran with our Noorani Qaida program.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start your Quran reading journey today with a free 20-minute trial session.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;My child learned to read Quran in just 3 months! The teacher was incredibly patient and made every lesson engaging. Highly recommend!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Parent</p>
                  <p className="text-xs md:text-sm text-gray-600">Qaida Course Graduate</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Noorani Qaida"
        subtitle="Find answers to common questions about learning Arabic alphabet and Quran reading basics"
      />

      {/* Related Courses */}
      <RelatedCourses
        courses={relatedCoursesByCategory['islamic-studies']}
        title="Continue Your Quran Journey"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Begin Your Quran Journey Today
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join hundreds of students who have learned to read Quran with our expert tutors.
            Book a free trial and start your journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
