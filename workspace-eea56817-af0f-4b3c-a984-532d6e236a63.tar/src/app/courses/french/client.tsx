'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Languages,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Globe,
  GraduationCap,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, ServiceSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'French Language – A1 to C1 Levels',
  category: 'Languages',
  rating: 4.9,
  students: 35,
  lessons: 90,
  description: 'Learn French with native-speaking tutors from beginner to advanced. Master conversation, grammar, prepare for DELF/DALF exams, and explore the rich French-speaking cultures around the world.',
  highlights: [
    'Native French speakers',
    'DELF/DALF preparation',
    'Conversation focus',
    'Grammar mastery',
    'All levels A1-C1',
    'Free trial available',
  ],
  programs: [
    { name: 'Beginner (A1-A2)', description: 'Basic vocabulary, greetings, simple conversations, essential grammar, and everyday situations.', level: 'Beginner' },
    { name: 'Intermediate (B1-B2)', description: 'Complex grammar, travel French, professional communication, extended conversations, and DELF B1/B2 preparation.', level: 'Intermediate' },
    { name: 'Advanced (C1)', description: 'Fluent expression, academic French, DALF preparation, literature, and cultural nuances.', level: 'Advanced' },
  ],
}

const faqData = [
  {
    question: 'How long does it take to learn French?',
    answer: 'Learning French varies by individual and goals. A1 level (basic) typically takes 2-3 months with regular study. B1 (intermediate) takes about 6-8 months, while C1 (advanced) can take 12-18 months. French is considered one of the easier languages for English speakers due to shared vocabulary. Our one-on-one instruction helps you progress efficiently.',
  },
  {
    question: 'Do you prepare students for DELF/DALF exams?',
    answer: 'Yes! We specialize in DELF (Diplôme d\'Études en Langue Française) and DALF (Diplôme Approfondi de Langue Française) exam preparation. Our teachers are familiar with the exam format and requirements at all levels. We provide practice tests, exam strategies, and targeted skills training to help you succeed.',
  },
  {
    question: 'Is French difficult to learn for English speakers?',
    answer: 'French is considered one of the easiest languages for English speakers to learn. English has borrowed many words from French, so you\'ll recognize vocabulary. The grammar has some complexities (like gendered nouns and verb conjugations), but our teachers break these down into manageable concepts. With consistent practice, you\'ll make steady progress.',
  },
  {
    question: 'What materials do you use for French lessons?',
    answer: 'We use established French learning resources (like Alter Ego, Cosmopolite, and Edito) combined with authentic materials including French media, literature excerpts, podcasts, and videos. For exam preparation, we use official DELF/DALF practice materials. All materials are provided digitally as part of your course.',
  },
  {
    question: 'Can I learn French for immigration or study in France?',
    answer: 'Absolutely! Many students learn French for immigration to French-speaking countries or university studies. For French university admission, B2 is typically required. For immigration to Quebec, different levels may be required depending on the program. We can tailor your learning to meet specific requirements.',
  },
  {
    question: 'How are online French classes structured?',
    answer: 'Each 45-60 minute class combines grammar instruction, vocabulary building, conversation practice, and listening comprehension. You\'ll have speaking practice in every lesson with immediate feedback on pronunciation. Teachers use screen sharing for materials and interactive exercises. Homework reinforces learning between sessions.',
  },
  {
    question: 'Do you offer French classes for children?',
    answer: 'Yes, we have French programs for children and teenagers. Our teachers use age-appropriate methods including games, songs, and interactive activities. We can support French school curriculum or prepare young learners for French certifications. Learning French young gives children a valuable skill for life.',
  },
  {
    question: 'What career opportunities does knowing French provide?',
    answer: 'French is an official language in 29 countries and many international organizations (UN, EU, African Union). It opens career opportunities in diplomacy, international business, tourism, and humanitarian work. French companies operate globally, and France is a major economy. Knowing French can significantly enhance your career prospects.',
  },
]

export default function FrenchCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/french',
    category: 'Languages',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const serviceSchemaData = {
    name: `Online ${courseData.name}`,
    description: 'One-on-one online French language tutoring with native speakers',
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/french',
    category: 'Online Education',
    areaServed: 'Worldwide',
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'French', url: 'https://www.abobakracademy.com/courses/french' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="French" />
      <CourseSchema course={courseSchemaData} />
      <ServiceSchema service={serviceSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="French Classes Online"
        subtitle="Learn French from A1 to C1 with native-speaking tutors"
        breadcrumb="Courses / French"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <Languages className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Done</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">6+</p>
              <p className="text-white/70 text-sm">French Tutors</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Language Mastery</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">French Levels</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn French with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    French is spoken on five continents and is an official language in 29 countries. 
                    It&apos;s the language of diplomacy, international relations, arts, and culture. 
                    Whether you&apos;re drawn to French literature, planning to study or work in a 
                    French-speaking country, or simply want to connect with French speakers worldwide, 
                    we&apos;re here to guide your journey.
                  </p>
                  <p>
                    Our native French-speaking teachers bring authentic language and cultural knowledge 
                    to every lesson. They understand the nuances of French pronunciation and can help 
                    you master the sounds that make French unique. With experience preparing students 
                    for DELF/DALF exams, they provide focused, effective instruction.
                  </p>
                  <p>
                    The one-on-one format ensures you get maximum speaking practice and personalized 
                    feedback. From Paris to Montreal, Dakar to Geneva, learning French opens doors 
                    to diverse cultures and opportunities around the world.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start learning French today with a free 20-minute trial session.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Native speakers</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;J&apos;adore mes cours de français! My teacher makes learning so enjoyable. I passed my DELF B1 on the first try!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Amira</p>
                  <p className="text-xs md:text-sm text-gray-600">DELF B1 Certified</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About French Classes"
        subtitle="Find answers to common questions about learning French online"
      />

      {/* Related Courses */}
      <RelatedCourses
        courses={relatedCoursesByCategory['languages']}
        title="Explore More Language Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Apprenez le Français Aujourd&apos;hui!
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Start your French learning journey with a free trial. No commitment required.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
