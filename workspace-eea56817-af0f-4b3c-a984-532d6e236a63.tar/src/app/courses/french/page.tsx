import { Metadata } from 'next'
import FrenchCourse from './client'

export const metadata: Metadata = {
  title: 'Learn French Online | French Classes A1-C1 & DELF Preparation - Abobakr Academy',
  description: 'Learn French online with certified native-speaking tutors. From A1 to C1, conversation, grammar, and DELF/DALF exam preparation. All levels welcome. Free trial available.',
  keywords: [
    'learn french online',
    'french classes',
    'french tutor',
    'delf preparation',
    'dalf exam',
    'french conversation',
    'french grammar',
    'online french lessons',
    'french for beginners',
    'french language course',
    'french certification',
    'speak french',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/french',
  },
  openGraph: {
    title: 'Learn French Online | French Classes A1-C1 & DELF Preparation',
    description: 'Learn French online with certified native-speaking tutors. DELF/DALF exam preparation.',
    url: 'https://www.abobakracademy.com/courses/french',
    type: 'website',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: 'French Language Classes - Abobakr Academy',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Learn French Online - Abobakr Academy',
    description: 'Learn French from A1 to C1 with native speakers. DELF/DALF prep. Free trial!',
  },
}

export default function Page() {
  return <FrenchCourse />
}
