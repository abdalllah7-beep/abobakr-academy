import { Metadata } from 'next'
import SocialStudiesCourse from './client'

export const metadata: Metadata = {
  title: 'Social Studies Tutoring | History, Geography, Civics - Abobakr Academy',
  description: 'Expert social studies tutoring for all grades. History, geography, civics, and social sciences. One-on-one sessions with qualified tutors.',
  keywords: 'social studies tutor, history tutor, geography classes, civics, social sciences',
  openGraph: { title: 'Social Studies Tutoring', description: 'Expert social studies tutoring for all grades.', type: 'website' },
}

export default function Page() { return <SocialStudiesCourse /> }
