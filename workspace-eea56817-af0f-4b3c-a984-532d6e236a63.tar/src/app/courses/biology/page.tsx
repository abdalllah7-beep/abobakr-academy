import { Metadata } from 'next'
import BiologyCourse from './client'

export const metadata: Metadata = {
  title: 'Online Biology Tutoring | Expert Biology Tutors - Abobakr Academy',
  description: 'Expert online biology tutoring for all grades. Cell biology, genetics, ecology, human anatomy, and more. One-on-one sessions with qualified tutors.',
  keywords: 'biology tutor, online biology classes, genetics, anatomy, ecology, biology homework help',
  openGraph: { title: 'Online Biology Tutoring', description: 'Expert online biology tutoring for all grades.', type: 'website' },
}

export default function Page() { return <BiologyCourse /> }
