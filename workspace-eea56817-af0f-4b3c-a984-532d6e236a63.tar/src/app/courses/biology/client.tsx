'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Leaf, Star, Users, Clock, Calendar, MessageCircle, CheckCircle2, Globe, GraduationCap, Heart, BookOpen } from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Biology – Cell Biology, Genetics & Anatomy',
  category: 'School Support',
  rating: 4.8,
  students: 65,
  lessons: 180,
  description: 'Explore the fascinating world of living organisms. From cellular processes to human anatomy, our biology tutors help you understand life sciences and excel in your studies with personalized one-on-one instruction.',
  highlights: ['Qualified biology educators', 'Visual learning approach', 'Lab concepts explained', 'Exam preparation', 'All grade levels', 'Free trial available'],
  programs: [
    { name: 'Cell Biology', description: 'Cell structure, organelles, cellular processes, and cell division. Understand the fundamental unit of life and how cells function.', duration: 'Ongoing', level: 'Middle & High School' },
    { name: 'Genetics', description: 'DNA, RNA, heredity, genetic disorders, and biotechnology. Master the science of inheritance and genetic variation.', duration: 'Ongoing', level: 'High School' },
    { name: 'Human Anatomy', description: 'Body systems, organs, physiology, and health. Learn about the structure and function of the human body.', duration: 'Ongoing', level: 'High School' },
    { name: 'Ecology', description: 'Ecosystems, biodiversity, conservation, and environmental science. Understand organisms and their environments.', duration: 'Ongoing', level: 'Middle & High School' },
  ],
}

const faqData = [
  {
    question: 'What biology topics do you cover?',
    answer: 'We cover the complete biology curriculum from middle school through university level. This includes cell biology, genetics, evolution, ecology, human anatomy and physiology, botany, zoology, microbiology, and molecular biology. We align with your specific school curriculum and exam requirements.',
  },
  {
    question: 'How do online biology classes work?',
    answer: 'Classes are conducted one-on-one via Zoom or Google Meet. Tutors use screen sharing to present diagrams, animations, and visual materials. Sessions typically last 45-60 minutes and include interactive discussions, diagram labeling, and problem-solving. Visual learning makes complex biological processes easier to understand.',
  },
  {
    question: 'Can you help with biology lab concepts?',
    answer: 'Yes! While we can\'t do physical labs online, we thoroughly explain lab concepts, experimental design, data analysis, and scientific methodology. We use virtual labs, animations, and detailed explanations of experimental procedures to help you understand the practical aspects of biology.',
  },
  {
    question: 'Do you prepare students for biology exams?',
    answer: 'Absolutely! Exam preparation is a core part of our biology tutoring. We help with chapter tests, midterms, finals, AP Biology, IB Biology, A-Level Biology, and university courses. Our approach includes reviewing concepts, practicing past papers, teaching exam strategies, and focusing on commonly tested topics.',
  },
  {
    question: 'What resources do you use for biology tutoring?',
    answer: 'We use a combination of digital textbooks, scientific animations, virtual lab simulations, diagram work, and past exam papers. Visual aids are especially important in biology for understanding complex structures and processes. All materials are provided digitally as part of your course.',
  },
  {
    question: 'Can you help with AP Biology or IB Biology?',
    answer: 'Yes, we specialize in AP Biology and IB Biology preparation. Our tutors are familiar with the specific curriculum requirements, lab components, and exam formats for both programs. We can help you prepare for the AP exam, IB assessments, and complete internal assessments (IAs).',
  },
  {
    question: 'How quickly can I improve my biology grades?',
    answer: 'Most students see noticeable improvement within 4-6 weeks of regular sessions. The timeline depends on your starting point, session frequency, and the complexity of topics you\'re studying. We focus on building understanding rather than memorization, which leads to lasting improvement.',
  },
  {
    question: 'Is biology tutoring helpful for medical school preparation?',
    answer: 'Absolutely! Strong biology foundations are essential for medical school entrance exams and future medical studies. Our advanced biology tutoring covers topics that prepare you for MCAT, UCAT, and medical school courses. We can also advise on study strategies for aspiring medical professionals.',
  },
]

export default function BiologyCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/biology',
    category: 'School Support',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Biology', url: 'https://www.abobakracademy.com/courses/biology' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Biology" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader title="Biology Tutoring" subtitle="Explore cell biology, genetics, ecology, and human anatomy" breadcrumb="Courses / Biology" />
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center"><Users className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p><p className="text-white/70 text-sm">Students</p></div>
            <div className="text-center"><Leaf className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p><p className="text-white/70 text-sm">Lessons Done</p></div>
            <div className="text-center"><Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p><p className="text-white/70 text-sm">Rating</p></div>
            <div className="text-center"><GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">15+</p><p className="text-white/70 text-sm">Biology Tutors</p></div>
          </div>
        </div>
      </section>
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">School Support</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">{courseData.name}</h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8">{courseData.description}</p>
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((h, i) => (<div key={i} className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-[#1DA678]" /><span className="text-gray-700 text-sm">{h}</span></div>))}
              </div>
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4">Biology Topics</h2>
              <div className="space-y-4">
                {courseData.programs.map((p, i) => (
                  <Card key={i} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{p.name}</h3>
                            <Badge variant="outline" className="text-xs">{p.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{p.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Study Biology with Us?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Biology is the study of life itself—from the molecular machinery inside cells to entire ecosystems spanning the globe. Understanding biology helps us make informed decisions about health, environment, and the world around us. It&apos;s also essential for careers in medicine, research, environmental science, and biotechnology.
                  </p>
                  <p>
                    Our biology tutors use visual teaching methods that make complex processes understandable. Through animations, diagrams, and interactive discussions, we break down difficult concepts into manageable pieces. Whether you&apos;re struggling with photosynthesis or preparing for AP Biology, our personalized approach adapts to your learning style.
                  </p>
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <Card className="border-0 shadow-xl sticky top-24"><CardContent className="p-5">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                <p className="text-gray-600 text-sm mb-4">Start exploring biology today with a free trial session.</p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-2 text-sm text-gray-600"><Clock className="w-4 h-4 text-[#1DA678]" /><span>Flexible scheduling</span></div>
                  <div className="flex items-center gap-2 text-sm text-gray-600"><Globe className="w-4 h-4 text-[#1DA678]" /><span>Learn from anywhere</span></div>
                  <div className="flex items-center gap-2 text-sm text-gray-600"><Heart className="w-4 h-4 text-[#1DA678]" /><span>Visual learning approach</span></div>
                </div>
                <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 mr-2" />Book Free Trial</Link></Button>
              </CardContent></Card>
              <Card className="border-0 shadow-md bg-[#E8F8F2]"><CardContent className="p-5">
                <div className="flex items-center gap-1 mb-3">{[...Array(5)].map((_, i) => (<Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />))}</div>
                <p className="text-gray-700 text-sm italic mb-4">&quot;Biology became my favorite subject! The tutor explains complex processes in such a simple way. My grades improved from C to A in just two months!&quot;</p>
                <p className="font-semibold text-gray-900 text-sm">— Noor</p>
                <p className="text-xs text-gray-600">AP Biology Student</p>
              </CardContent></Card>
            </div>
          </div>
        </div>
      </section>
      <FAQSection faqs={faqData} title="Frequently Asked Questions About Biology Tutoring" subtitle="Everything you need to know about our online biology program" />
      <RelatedCourses courses={relatedCoursesByCategory['school-support']} title="Explore More School Support Courses" />
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Explore Biology Today</h2>
          <p className="text-base text-white/80 mb-6">Join students discovering the wonders of life sciences with expert tutoring.</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 py-5 rounded-full" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 mr-2" />Book Free Trial</Link></Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 py-5 rounded-full" asChild><a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer"><MessageCircle className="w-4 h-4 mr-2" />Chat on WhatsApp</a></Button>
          </div>
        </div>
      </section>
      <Footer /><WhatsAppButton />
    </main>
  )
}
