import { Metadata } from 'next'
import GeographyCourse from './client'

export const metadata: Metadata = {
  title: 'Online Geography Tutoring | Physical & Human Geography - Abobakr Academy',
  description: 'Expert geography tutoring for all grades. Physical geography, human geography, map skills, and environmental studies.',
  keywords: 'geography tutor, physical geography, human geography, map skills, environmental studies',
  openGraph: { title: 'Online Geography Tutoring', description: 'Expert geography tutoring for all grades.', type: 'website' },
}

export default function Page() { return <GeographyCourse /> }
