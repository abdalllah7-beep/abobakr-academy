import { Metadata } from 'next'
import CoursesClient from './client'

export const metadata: Metadata = {
  title: 'Online Courses | Abobakr Academy - Quran, Languages, School Support',
  description: 'Explore our comprehensive online courses: Islamic Studies (Quran, Tajweed), Language Mastery (Arabic, English, German), School Curriculum Support, Computer Science & Digital Skills, Creative Arts. Expert tutors, flexible scheduling.',
  keywords: 'online courses, quran classes, tajweed, arabic lessons, english tutoring, online tutoring, islamic studies, computer courses, ICDL certification',
  openGraph: {
    title: 'Online Courses | Abobakr Academy',
    description: 'Explore our comprehensive online courses with expert tutors. Islamic Studies, Languages, School Support & more.',
    type: 'website',
  },
}

export default function CoursesPage() {
  return <CoursesClient />
}
