'use client'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { FlaskConical, Star, Users, Clock, Calendar, MessageCircle, CheckCircle2, Globe, Heart, GraduationCap } from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Chemistry – Organic, Inorganic & Physical',
  category: 'School Support',
  rating: 4.8,
  students: 70,
  lessons: 220,
  description: 'Master chemistry from atomic structure to organic reactions with our expert tutors. We break down complex chemical principles into understandable concepts, helping you excel in your studies and exams.',
  highlights: ['Qualified Chemistry Educators', 'Lab Techniques Explained', 'Problem-Solving Focus', 'Exam Preparation Included', 'All Grade Levels', 'Free Trial Available'],
  programs: [
    { name: 'General Chemistry', description: 'Atomic structure, bonding, stoichiometry, chemical reactions, and the periodic table. Build a strong foundation in chemistry fundamentals.', level: 'All Levels' },
    { name: 'Organic Chemistry', description: 'Hydrocarbons, functional groups, reaction mechanisms, synthesis, and spectroscopy. Master the chemistry of carbon compounds.', level: 'Advanced' },
    { name: 'Inorganic Chemistry', description: 'Metals, non-metals, coordination compounds, periodic trends, and chemical bonding. Understand the full periodic table.', level: 'All Levels' },
    { name: 'Physical Chemistry', description: 'Thermodynamics, kinetics, equilibrium, electrochemistry, and quantum chemistry. Connect physics with chemistry.', level: 'Advanced' },
  ],
}

const faqData = [
  { question: 'How do online chemistry tutoring sessions work?', answer: 'Our chemistry sessions are conducted one-on-one via Zoom or Google Meet. Tutors use digital whiteboards to draw molecular structures, explain reactions, and solve problems visually. Sessions are 45-60 minutes and include concept explanation, guided practice, and time for questions.' },
  { question: 'What chemistry topics do you cover?', answer: 'We cover all chemistry topics from middle school through university: general chemistry (atoms, bonding, reactions), organic chemistry (functional groups, mechanisms), inorganic chemistry (metals, coordination compounds), physical chemistry (thermodynamics, kinetics), biochemistry, and analytical chemistry. We align with your specific curriculum.' },
  { question: 'Can you help with organic chemistry?', answer: 'Yes! Organic chemistry is one of our most requested subjects. Our tutors help you understand reaction mechanisms, functional groups, stereochemistry, and synthesis strategies. We break down complex mechanisms into logical steps and provide plenty of practice problems.' },
  { question: 'Do you help with AP Chemistry or IB Chemistry?', answer: 'Absolutely! We have tutors experienced with AP Chemistry, IB Chemistry (SL and HL), A-Level Chemistry, and IGCSE Chemistry. We know the exam formats, required practicals, and common question types. Our students consistently achieve high scores.' },
  { question: 'How do you teach lab concepts online?', answer: 'While we can\'t perform physical labs, we use videos, simulations, and detailed explanations to teach lab concepts. We cover experimental design, safety procedures, data analysis, and interpretation of results. Many exam questions about labs can be answered through understanding concepts rather than hands-on experience.' },
  { question: 'What qualifications do your chemistry tutors have?', answer: 'Our chemistry tutors hold degrees in chemistry, chemical engineering, biochemistry, or related fields. Many have advanced degrees and teaching experience. They understand how to explain abstract concepts like molecular orbitals and reaction mechanisms in understandable ways.' },
  { question: 'How do I memorize chemical formulas and reactions?', answer: 'Effective chemistry learning isn\'t about rote memorization—it\'s about understanding patterns. Our tutors teach you to recognize periodic trends, understand bonding patterns, and predict reactions based on principles. This approach means you remember more with less memorization.' },
  { question: 'Can you help with chemistry homework and exam prep?', answer: 'Yes! Homework help and exam preparation are core services. Tutors guide you through difficult problems, teach problem-solving strategies, and create practice problems. For exams, we review key concepts, practice past papers, and focus on your weak areas.' },
]

export default function ChemistryCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/chemistry',
    category: 'School Support',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }
  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Chemistry', url: 'https://www.abobakracademy.com/courses/chemistry' },
  ]

  return (
    <main className="min-h-screen bg-white">
      <FAQSchema faqs={faqData} courseName="Chemistry" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />
      <Navigation />
      <PageHeader title="Chemistry Tutoring" subtitle="Master organic, inorganic, and physical chemistry" breadcrumb="Courses / Chemistry" />
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center"><Users className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p><p className="text-white/70 text-sm">Active Students</p></div>
            <div className="text-center"><FlaskConical className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p><p className="text-white/70 text-sm">Lessons Completed</p></div>
            <div className="text-center"><Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" /><p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p><p className="text-white/70 text-sm">Average Rating</p></div>
            <div className="text-center"><GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" /><p className="text-2xl md:text-3xl font-bold text-white">20+</p><p className="text-white/70 text-sm">Chemistry Tutors</p></div>
          </div>
        </div>
      </section>
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">School Support</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">{courseData.name}</h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">{courseData.description}</p>
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((h, i) => (<div key={i} className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-[#1DA678]" /><span className="text-gray-700 text-sm md:text-base">{h}</span></div>))}
              </div>
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Chemistry Topics</h2>
              <div className="space-y-4">
                {courseData.programs.map((p, i) => (
                  <Card key={i} className="border-0 shadow-md hover:shadow-lg transition-shadow"><CardContent className="p-4 md:p-6">
                    <div className="flex items-center gap-2 mb-2"><h3 className="font-semibold text-gray-900">{p.name}</h3><Badge variant="outline" className="text-xs">{p.level}</Badge></div>
                    <p className="text-gray-600 text-sm md:text-base">{p.description}</p>
                  </CardContent></Card>
                ))}
              </div>
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Choose Our Chemistry Tutoring?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>Chemistry is often called the central science because it connects physics with biology and earth sciences. Yet many students find chemistry challenging because it requires understanding both abstract concepts and mathematical problem-solving.</p>
                  <p>At Abobakr Academy, our chemistry tutors make the invisible visible. Using digital tools, we draw molecular structures, animate reactions, and break down complex mechanisms into understandable steps. Our students don&apos;t just memorize—they understand.</p>
                  <p>Whether you&apos;re struggling with balancing equations, grasping organic mechanisms, or preparing for AP/IB exams, our one-on-one tutoring provides the personalized attention you need to succeed.</p>
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <Card className="border-0 shadow-xl sticky top-24"><CardContent className="p-5 md:p-6">
                <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                <p className="text-gray-600 text-sm md:text-base mb-4">Start mastering chemistry today with a free 20-minute trial session.</p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-2 text-sm text-gray-600"><Clock className="w-4 h-4 text-[#1DA678]" /><span>Flexible scheduling</span></div>
                  <div className="flex items-center gap-2 text-sm text-gray-600"><Globe className="w-4 h-4 text-[#1DA678]" /><span>Learn from anywhere</span></div>
                  <div className="flex items-center gap-2 text-sm text-gray-600"><Heart className="w-4 h-4 text-[#1DA678]" /><span>100% satisfaction guaranteed</span></div>
                </div>
                <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 mr-2" />Book Free Trial</Link></Button>
              </CardContent></Card>
              <Card className="border-0 shadow-md bg-[#E8F8F2]"><CardContent className="p-5 md:p-6">
                <div className="flex items-center gap-1 mb-3">{[...Array(5)].map((_, i) => (<Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />))}</div>
                <p className="text-gray-700 text-sm md:text-base italic mb-4">&quot;Chemistry finally makes sense! I got A* in my IGCSE after just 3 months of tutoring.&quot;</p>
                <p className="font-semibold text-gray-900 text-sm">— Fatima</p><p className="text-xs md:text-sm text-gray-600">IGCSE Chemistry Student</p>
              </CardContent></Card>
            </div>
          </div>
        </div>
      </section>
      <FAQSection faqs={faqData} title="Frequently Asked Questions About Chemistry Tutoring" subtitle="Everything you need to know about our chemistry program" />
      <RelatedCourses courses={relatedCoursesByCategory['school-support']} title="Explore More Science Courses" />
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Master Chemistry Today</h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">Join students excelling in chemistry with our expert tutors.</p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild><Link href="/contact#trial"><Calendar className="w-4 h-4 mr-2" />Book Free Trial</Link></Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild><a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer"><MessageCircle className="w-4 h-4 mr-2" />Chat on WhatsApp</a></Button>
          </div>
        </div>
      </section>
      <Footer /><WhatsAppButton />
    </main>
  )
}
