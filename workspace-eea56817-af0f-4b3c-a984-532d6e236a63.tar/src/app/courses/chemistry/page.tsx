import { Metadata } from 'next'
import ChemistryCourse from './client'

export const metadata: Metadata = {
  title: 'Online Chemistry Tutoring | Expert Chemistry Tutors - Abobakr Academy',
  description: 'Expert online chemistry tutoring for all grades. Organic, inorganic, physical chemistry, and lab techniques. One-on-one sessions with qualified tutors.',
  keywords: 'chemistry tutor, online chemistry classes, organic chemistry, chemistry homework help, chemistry exam prep',
  openGraph: { title: 'Online Chemistry Tutoring', description: 'Expert online chemistry tutoring for all grades.', type: 'website' },
}

export default function Page() { return <ChemistryCourse /> }
