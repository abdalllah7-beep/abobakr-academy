import { Metadata } from 'next'
import GermanCourse from './client'

export const metadata: Metadata = {
  title: 'Learn German Online | German Classes A1-C1 & Goethe Exam Prep - Abobakr Academy',
  description: 'Learn German online with certified native-speaking tutors. From A1 to C1 levels, conversation, grammar, and Goethe certification exam preparation. Free trial available.',
  keywords: [
    'learn german online',
    'german classes',
    'german tutor',
    'a1 german course',
    'goethe exam preparation',
    'german conversation',
    'german grammar',
    'online german lessons',
    'german for beginners',
    'german language course',
    'b1 german',
    'german certification',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/german',
  },
  openGraph: {
    title: 'Learn German Online | German Classes A1-C1 & Goethe Exam Prep',
    description: 'Learn German online with certified native-speaking tutors. From A1 to C1, Goethe exam preparation.',
    url: 'https://www.abobakracademy.com/courses/german',
    type: 'website',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: 'German Language Classes - Abobakr Academy',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Learn German Online - Abobakr Academy',
    description: 'Learn German from A1 to C1 with native speakers. Goethe exam prep. Free trial!',
  },
}

export default function Page() {
  return <GermanCourse />
}
