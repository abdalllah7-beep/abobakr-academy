'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Languages,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Globe,
  GraduationCap,
  Heart,
  Award,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, ServiceSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'German Language – A1 to C1 Levels',
  category: 'Languages',
  rating: 4.9,
  students: 55,
  lessons: 150,
  description: 'Learn German from beginner to advanced with certified native-speaking tutors. Master grammar, vocabulary, conversation, and prepare for Goethe certification exams with structured, effective lessons.',
  highlights: [
    'Native German speakers',
    'Goethe exam preparation',
    'Conversation practice',
    'Grammar mastery',
    'All levels A1-C1',
    'Free trial available',
  ],
  programs: [
    { name: 'A1 - Beginner', description: 'Basic vocabulary, simple sentences, everyday expressions, introductions, and foundational grammar.', level: 'Beginner' },
    { name: 'A2 - Elementary', description: 'Simple conversations, routine topics, basic grammar structures, and practical daily situations.', level: 'Elementary' },
    { name: 'B1 - Intermediate', description: 'Complex texts, travel situations, expressing opinions, and preparation for B1 certification.', level: 'Intermediate' },
    { name: 'B2/C1 - Advanced', description: 'Fluent conversations, professional German, academic language, and Goethe exam preparation.', level: 'Advanced' },
  ],
}

const faqData = [
  {
    question: 'How long does it take to learn German?',
    answer: 'The time to learn German varies based on your starting point and goals. A1 level typically takes 2-3 months with regular study, while B1 (intermediate) takes about 6-8 months. Reaching C1 (advanced) usually requires 12-18 months of consistent learning. Our structured approach and one-on-one instruction help you progress efficiently at your own pace.',
  },
  {
    question: 'Do you prepare students for Goethe Institute exams?',
    answer: 'Yes, we specialize in Goethe Institute exam preparation! Our teachers are familiar with all Goethe exam levels (A1-C1) and provide targeted preparation including practice tests, exam strategies, and specific skills training. Many of our students have successfully passed their Goethe certifications after studying with us.',
  },
  {
    question: 'Is German difficult to learn?',
    answer: 'German has a reputation for being challenging, but it\'s also very logical and structured. While the grammar cases and compound words can seem intimidating at first, our teachers break down concepts into manageable lessons. Many English speakers find German easier than expected because of shared vocabulary and language roots.',
  },
  {
    question: 'What materials do you use for German lessons?',
    answer: 'We use a combination of established German learning textbooks (such as Menschen, Netzwerk, and Studio D) and supplementary authentic materials like news articles, videos, and podcasts. For exam preparation, we use official Goethe practice materials. All materials are provided digitally as part of your course.',
  },
  {
    question: 'Can I learn German for work or study in Germany?',
    answer: 'Absolutely! Many of our students learn German specifically for professional or academic purposes. We offer Business German courses focusing on professional communication, and we can tailor lessons to your field. For university preparation, we help you reach the required language level and can include academic German in your curriculum.',
  },
  {
    question: 'How are the online German classes structured?',
    answer: 'Each 45-60 minute class combines grammar instruction, vocabulary building, conversation practice, and listening comprehension. Teachers use screen sharing for visual materials and interactive exercises. You\'ll have speaking practice in every lesson, along with homework assignments to reinforce learning between sessions.',
  },
  {
    question: 'Do you offer German classes for children?',
    answer: 'Yes, we have German programs designed specifically for children and teenagers. Our teachers use age-appropriate methods including games, songs, and interactive activities to make learning fun and engaging. We can also help young learners prepare for German school exams or support their German language studies at school.',
  },
  {
    question: 'What level of German do I need to work in Germany?',
    answer: 'The required German level depends on your job. For most professional positions, B2 level is expected, while C1 is required for roles involving extensive communication or technical fields. For basic employment or jobs in international companies, B1 may suffice. We can assess your current level and create a plan to reach your target proficiency.',
  },
]

export default function GermanCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/german',
    category: 'Languages',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const serviceSchemaData = {
    name: `Online ${courseData.name}`,
    description: 'One-on-one online German language tutoring with native speakers',
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/german',
    category: 'Online Education',
    areaServed: 'Worldwide',
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'German', url: 'https://www.abobakracademy.com/courses/german' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="German" />
      <CourseSchema course={courseSchemaData} />
      <ServiceSchema service={serviceSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="German Classes Online"
        subtitle="Learn German from A1 to C1 with native-speaking tutors"
        breadcrumb="Courses / German"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <Languages className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Done</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">10+</p>
              <p className="text-white/70 text-sm">German Tutors</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Language Mastery</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">German Levels</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn German with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    German is the most widely spoken native language in the European Union and opens 
                    doors to opportunities in Germany, Austria, Switzerland, and beyond. Whether 
                    you&apos;re planning to study at a German university, advance your career with 
                    German companies, or simply explore the rich German-speaking cultures, we&apos;re 
                    here to help you succeed.
                  </p>
                  <p>
                    Our native German-speaking teachers bring authentic language and cultural insights 
                    to every lesson. With years of teaching experience and familiarity with the Goethe 
                    exam format, they provide targeted instruction that helps you progress efficiently. 
                    The one-on-one format ensures personalized attention and maximum speaking practice.
                  </p>
                  <p>
                    From your first &quot;Guten Tag&quot; to professional fluency, we guide you through 
                    each level of the Common European Framework of Reference (CEFR). Our structured 
                    curriculum, combined with flexible scheduling, makes it easy to fit German learning 
                    into your life.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start learning German today with a free 20-minute trial session.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Native speakers</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;Passed my Goethe B1 exam thanks to this course! The exam preparation was exactly what I needed.&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Hassan</p>
                  <p className="text-xs md:text-sm text-gray-600">Goethe B1 Certified</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About German Classes"
        subtitle="Find answers to common questions about learning German online"
      />

      {/* Related Courses */}
      <RelatedCourses
        courses={relatedCoursesByCategory['languages']}
        title="Explore More Language Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Start Learning German Today
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join students mastering German with our expert tutors. Book your free trial now.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
