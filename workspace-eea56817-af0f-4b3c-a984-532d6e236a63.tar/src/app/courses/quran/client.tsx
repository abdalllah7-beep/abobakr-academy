'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  BookMarked,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Award,
  Globe,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, ServiceSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Quran – Read, Recite & Memorize',
  category: 'Islamic Studies',
  rating: 5.0,
  students: 200,
  lessons: 500,
  description: 'Master the recitation and memorization of the Holy Quran with our certified Qaris. Our comprehensive Quran program covers reading fundamentals, proper Tajweed, and Hifz (memorization) techniques.',
  highlights: [
    'Certified Qaris with Ijazah',
    'One-on-one personalized sessions',
    'Flexible scheduling - learn at your pace',
    'Progress tracking and reports',
    'Suitable for all ages and levels',
    'Free trial class available',
  ],
  programs: [
    {
      name: 'Quran Reading (Noorani Qaida)',
      description: 'Perfect for beginners. Learn Arabic letters, pronunciation, and basic reading skills using the Noorani Qaida method. Build a strong foundation for Quranic recitation.',
      duration: '3-6 months',
      level: 'Beginner',
    },
    {
      name: 'Tajweed Mastery',
      description: 'Learn the rules of Tajweed including Makharij (articulation points), Sifaat (attributes), Ghunna, Madd, and proper recitation. Perfect your Quranic pronunciation.',
      duration: '6-12 months',
      level: 'Intermediate',
    },
    {
      name: 'Hifz (Memorization)',
      description: 'Structured memorization program with revision schedules and retention techniques. Suitable for those who can read fluently and want to commit the Quran to memory.',
      duration: '2-4 years',
      level: 'Advanced',
    },
    {
      name: 'Tafsir Studies',
      description: 'Understand the meanings, context, and scholarly interpretation of Quranic verses. Deepen your connection with the Holy Quran through comprehensive study.',
      duration: 'Ongoing',
      level: 'All Levels',
    },
  ],
}

const faqData = [
  {
    question: 'How do online Quran classes work?',
    answer: 'Our online Quran classes are conducted via Zoom or Google Meet in a one-on-one setting. You\'ll be matched with a certified Quran teacher who will guide you through personalized lessons at your pace. Classes are typically 30-60 minutes long, and you can schedule them at times convenient for you. All you need is a stable internet connection, a device with a camera and microphone, and a quiet space to learn.',
  },
  {
    question: 'What qualifications do your Quran teachers have?',
    answer: 'All our Quran teachers are certified Qaris with Ijazah (authorization) in Quranic recitation. They have memorized the entire Quran and have extensive training in Tajweed rules. Many of our teachers are graduates of renowned Islamic universities and have years of experience teaching Quran to students of all ages and levels.',
  },
  {
    question: 'Can my child learn Quran online effectively?',
    answer: 'Yes! Online Quran classes can be highly effective for children. Our teachers are trained to engage young learners through interactive teaching methods, visual aids, and age-appropriate pacing. Many parents find that one-on-one online classes actually work better than group classes because children receive undivided attention and can progress at their own pace.',
  },
  {
    question: 'How long does it take to memorize the Quran (Hifz)?',
    answer: 'The time required for Hifz varies depending on the student\'s dedication, prior Quran knowledge, and memorization ability. On average, students complete memorization in 2-4 years with consistent daily lessons and revision. Our structured program includes regular revision to ensure retention of memorized portions.',
  },
  {
    question: 'What is Tajweed and why is it important?',
    answer: 'Tajweed is the science of proper Quranic recitation, ensuring each letter is pronounced correctly from its point of articulation with its proper attributes. Learning Tajweed is essential because incorrect pronunciation can change the meaning of Quranic words. It\'s a religious obligation to recite the Quran with Tajweed to the best of one\'s ability.',
  },
  {
    question: 'Do you offer a free trial class?',
    answer: 'Yes, we offer a free 20-minute trial class for all new students. This allows you to experience our teaching methodology, meet your potential teacher, and discuss your learning goals before committing. There\'s no obligation and no payment required for the trial.',
  },
  {
    question: 'What is the best age to start learning Quran?',
    answer: 'Children can start learning Quran as early as 4-5 years old with basic Qaida (Arabic alphabet). For structured Tajweed and memorization, ages 6-7 are ideal. However, it\'s never too late to learn—we have successful students of all ages, from young children to seniors.',
  },
  {
    question: 'How much do online Quran classes cost?',
    answer: 'Our pricing is competitive and depends on the program type, lesson frequency, and duration. We offer flexible packages to suit different budgets. Contact us for a personalized quote based on your learning goals. All packages include access to our learning materials and progress tracking.',
  },
]

const testimonials = [
  {
    author: 'Farah',
    rating: 5,
    text: 'Great efforts! I feel like reading Quran for the first time! The teacher is patient and explains everything clearly.',
  },
  {
    author: 'Ahmed\'s Mom',
    rating: 5,
    text: 'My son memorized 10 Juz in just one year. The structured approach and regular revision made all the difference.',
  },
]

export default function QuranCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/quran',
    category: 'Islamic Studies',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const serviceSchemaData = {
    name: `Online ${courseData.name} Classes`,
    description: 'One-on-one online Quran tutoring with certified Qaris',
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/quran',
    category: 'Online Education',
    areaServed: 'Worldwide',
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Quran', url: 'https://www.abobakracademy.com/courses/quran' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Quran" />
      <CourseSchema course={courseSchemaData} />
      <ServiceSchema service={serviceSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader 
        title="Online Quran Classes with Tajweed" 
        subtitle="Learn Quran reading, recitation & memorization with certified Qaris"
        breadcrumb="Courses / Quran"
      />

      {/* Course Overview */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <BookMarked className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <Award className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">50+</p>
              <p className="text-white/70 text-sm">Certified Qaris</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Islamic Studies</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Our Quran Programs</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs md:text-sm text-gray-500">Duration</p>
                          <p className="font-semibold text-[#1DA678] text-sm md:text-base">{program.duration}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Learn Quran with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    At Abobakr Academy, we understand that learning the Quran is a spiritual journey that requires 
                    dedication, patience, and expert guidance. Our Quran program is designed to provide personalized 
                    attention to each student, ensuring that you or your child develops a strong foundation in Quranic 
                    recitation and understanding.
                  </p>
                  <p>
                    Our certified Qaris have years of experience teaching students of all ages and backgrounds. 
                    Whether you&apos;re a complete beginner starting with Noorani Qaida or an advanced student 
                    working on Hifz, our teachers will tailor their approach to meet your specific needs and goals.
                  </p>
                  <p>
                    With flexible scheduling, progress tracking, and a supportive learning environment, 
                    we make it easy to incorporate Quran learning into your daily routine. Join hundreds of 
                    students who have transformed their relationship with the Holy Quran through our program.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start your Quran journey today with a free 20-minute trial session with a certified Qari.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;Great efforts! I feel like reading Quran for the first time! The teacher is patient and explains everything clearly.&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Farah</p>
                  <p className="text-xs md:text-sm text-gray-600">Quran Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Topics */}
      <section className="py-12 bg-[#E8F8F2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-6 bg-white rounded-2xl shadow-lg">
              <div className="flex-1 text-center md:text-left">
                <Badge className="mb-2 bg-[#1DA678] text-white">Featured Program</Badge>
                <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-1">Quran Memorization (Hifz)</h3>
                <p className="text-gray-600 text-sm">
                  Structured Hifz program with certified Huffaz. Learn memorization techniques and revision schedules.
                </p>
              </div>
              <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white px-5 py-4 rounded-full whitespace-nowrap" asChild>
                <Link href="/topics/quran-memorization">
                  Learn More
                </Link>
              </Button>
            </div>
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-6 bg-white rounded-2xl shadow-lg">
              <div className="flex-1 text-center md:text-left">
                <Badge className="mb-2 bg-[#1DA678] text-white">Featured Program</Badge>
                <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-1">Tajweed Rules</h3>
                <p className="text-gray-600 text-sm">
                  Master Makharij, Sifaat, and all Tajweed rules with expert guidance for perfect recitation.
                </p>
              </div>
              <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white px-5 py-4 rounded-full whitespace-nowrap" asChild>
                <Link href="/topics/tajweed-rules">
                  Learn More
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection 
        faqs={faqData} 
        title="Frequently Asked Questions About Quran Classes"
        subtitle="Find answers to common questions about our online Quran program"
      />

      {/* Related Courses */}
      <RelatedCourses 
        courses={relatedCoursesByCategory['islamic-studies']} 
        title="Explore More Islamic Studies Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Begin Your Quran Journey Today
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join hundreds of students who have improved their Quran recitation with our expert tutors. 
            Book a free trial and experience the difference.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
