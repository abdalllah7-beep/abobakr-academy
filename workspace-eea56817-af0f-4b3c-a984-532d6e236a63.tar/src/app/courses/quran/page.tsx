import { Metadata } from 'next'
import QuranCourse from './client'

export const metadata: Metadata = {
  title: 'Online Quran Classes with Tajweed | Certified Qari Tutors - Abobakr Academy',
  description: 'Learn Quran online with certified Qaris and Tajweed experts. Master Quran reading, recitation, memorization (Hifz), and Tajweed rules. One-on-one personalized classes for kids and adults. Book your free trial today.',
  keywords: [
    'online quran classes',
    'learn quran online',
    'tajweed classes online',
    'quran memorization course',
    'hifz online',
    'quran tutor online',
    'quran classes for kids',
    'quran classes for adults',
    'online quran teacher',
    'tajweed for beginners',
    'quran recitation course',
    'islamic studies online',
    'noorani qaida online',
    'quran with tajweed',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/quran',
  },
  openGraph: {
    title: 'Online Quran Classes with Tajweed | Certified Qari Tutors',
    description: 'Learn Quran online with certified Qaris. Master reading, recitation, memorization (Hifz) and Tajweed. Free trial available.',
    url: 'https://www.abobakracademy.com/courses/quran',
    type: 'website',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: 'Online Quran Classes - Abobakr Academy',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Online Quran Classes with Tajweed - Abobakr Academy',
    description: 'Learn Quran online with certified Qaris. Master reading, recitation, memorization and Tajweed. Free trial!',
  },
}

export default function Page() {
  return <QuranCourse />
}
