import { Metadata } from 'next'
import IslamicStudiesCourse from './client'

export const metadata: Metadata = {
  title: 'Islamic Studies Classes Online | Fiqh, Hadith, Tafsir, Seerah - Abobakr Academy',
  description: 'Learn Islamic studies online with qualified scholars. Comprehensive courses in Fiqh, Hadith, Tafsir, Seerah, Islamic history. One-on-one classes for all ages. Free trial available.',
  keywords: [
    'islamic studies online',
    'learn fiqh online',
    'hadith studies',
    'tafsir course',
    'seerah classes',
    'islamic education',
    'online islamic classes',
    'islamic history',
    'quran tafsir',
    'islamic jurisprudence',
    'prophet biography',
    'islamic knowledge',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/islamic-studies',
  },
  openGraph: {
    title: 'Islamic Studies Classes Online | Fiqh, Hadith, Tafsir',
    description: 'Learn Islamic studies online with qualified scholars. Comprehensive courses in Fiqh, Hadith, Tafsir, Seerah.',
    url: 'https://www.abobakracademy.com/courses/islamic-studies',
    type: 'website',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: 'Islamic Studies Classes - Abobakr Academy',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Islamic Studies Classes - Abobakr Academy',
    description: 'Learn Islamic studies online with qualified scholars. Fiqh, Hadith, Tafsir & more. Free trial!',
  },
}

export default function Page() {
  return <IslamicStudiesCourse />
}
