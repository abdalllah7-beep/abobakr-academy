'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  BookMarked,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Globe,
  GraduationCap,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, ServiceSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Islamic Studies – Fiqh, Hadith, Tafsir & More',
  category: 'Islamic Studies',
  rating: 5.0,
  students: 100,
  lessons: 300,
  description: 'Deepen your understanding of Islam with comprehensive courses covering Fiqh (jurisprudence), Hadith, Tafsir, Seerah, and Islamic history. Learn from qualified scholars in a supportive, interactive environment.',
  highlights: [
    'Qualified Islamic scholars',
    'Authentic sources',
    'All ages welcome',
    'Interactive sessions',
    'Q&A opportunities',
    'Free trial available',
  ],
  programs: [
    { name: 'Fiqh (Jurisprudence)', description: 'Islamic rulings on worship, transactions, family matters, and daily life according to authentic sources.', level: 'All Levels' },
    { name: 'Hadith Studies', description: 'Prophetic traditions, their authentication, classification, and practical application in daily life.', level: 'All Levels' },
    { name: 'Tafsir (Quran Explanation)', description: 'In-depth understanding of Quranic verses, context of revelation, and scholarly interpretations.', level: 'Intermediate' },
    { name: 'Seerah (Prophet\'s Biography)', description: 'Life of Prophet Muhammad ﷺ, his character, teachings, and lessons applicable to modern life.', level: 'All Levels' },
    { name: 'Islamic History', description: 'Golden age of Islam, the caliphates, scholars, and contributions to human civilization.', level: 'All Levels' },
  ],
}

const faqData = [
  {
    question: 'What topics are covered in Islamic Studies classes?',
    answer: 'Our Islamic Studies program covers a comprehensive range of subjects including Fiqh (Islamic jurisprudence), Hadith sciences, Tafsir (Quran interpretation), Seerah (Prophetic biography), Islamic history, Aqeedah (beliefs), and Islamic etiquette. The curriculum is designed to provide a well-rounded understanding of Islam for practical application in daily life.',
  },
  {
    question: 'Who teaches the Islamic Studies courses?',
    answer: 'Our Islamic Studies courses are taught by qualified scholars who have graduated from renowned Islamic universities and institutions. They have extensive knowledge in various Islamic sciences and are skilled at explaining complex concepts in an accessible manner. Many of our teachers hold ijazah (authorization) in various Islamic disciplines.',
  },
  {
    question: 'Is this course suitable for children?',
    answer: 'Yes, we offer Islamic Studies classes tailored specifically for different age groups. Children learn through engaging, age-appropriate content that includes stories of the prophets, basic Islamic beliefs, manners, and simplified Fiqh. Our teachers are experienced in making Islamic education interesting and relevant for young learners.',
  },
  {
    question: 'Can adults benefit from Islamic Studies classes?',
    answer: 'Absolutely! Many of our students are adults seeking to deepen their Islamic knowledge. Whether you\'re a new Muslim wanting to learn the fundamentals, someone who wants to reconnect with their faith, or a lifelong learner seeking more advanced knowledge, our scholars can tailor the content to your level and interests.',
  },
  {
    question: 'Which school of thought (madhab) do you follow?',
    answer: 'We respect all four major schools of Islamic jurisprudence (Hanafi, Maliki, Shafi\'i, and Hanbali). Our teachers can teach according to your preferred madhab or provide comparative perspectives. We focus on providing authentic knowledge from qualified sources while respecting the diversity of Islamic scholarship.',
  },
  {
    question: 'How long does it take to complete Islamic Studies?',
    answer: 'Islamic Studies is an ongoing journey of learning. We offer structured courses that can be completed in 6-12 months for foundational topics, but many students continue studying for years. Our teachers create personalized learning paths based on your goals, whether you want a comprehensive education or focused study in specific areas.',
  },
  {
    question: 'What resources and materials are provided?',
    answer: 'Students receive access to curated learning materials including recommended books, articles, and multimedia resources. Our teachers provide notes and handouts during lessons. We also recommend authentic sources for further reading. All materials are selected to ensure accuracy and relevance to contemporary life.',
  },
  {
    question: 'How are the classes conducted online?',
    answer: 'Classes are conducted via video conferencing in a one-on-one setting. Teachers share their screens to present materials, use interactive whiteboards, and engage students through discussion. Screen sharing allows for text study, and students can ask questions in real-time. Sessions are typically 45-60 minutes with flexible scheduling.',
  },
]

export default function IslamicStudiesCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/islamic-studies',
    category: 'Islamic Studies',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const serviceSchemaData = {
    name: `Online ${courseData.name}`,
    description: 'One-on-one online Islamic Studies tutoring with qualified scholars',
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/islamic-studies',
    category: 'Online Education',
    areaServed: 'Worldwide',
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Islamic Studies', url: 'https://www.abobakracademy.com/courses/islamic-studies' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Islamic Studies" />
      <CourseSchema course={courseSchemaData} />
      <ServiceSchema service={serviceSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Islamic Studies Classes"
        subtitle="Deepen your knowledge of Islam with qualified scholars"
        breadcrumb="Courses / Islamic Studies"
      />

      {/* Stats Section */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <BookMarked className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">20+</p>
              <p className="text-white/70 text-sm">Qualified Scholars</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Islamic Studies</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Topics Covered</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Choose Section */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Study Islamic Studies with Abobakr Academy?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    In today&apos;s world, access to authentic Islamic knowledge is more important than ever. 
                    At Abobakr Academy, we connect you with qualified scholars who have dedicated their 
                    lives to studying and teaching Islamic sciences. Our teachers bring knowledge from 
                    renowned Islamic institutions and years of teaching experience.
                  </p>
                  <p>
                    Our Islamic Studies program goes beyond mere information transfer. We focus on 
                    understanding, reflection, and practical application. Whether you&apos;re studying 
                    Fiqh to improve your worship, Hadith to understand the Sunnah, or Tafsir to 
                    connect with the Quran, our scholars guide you through authentic sources with 
                    proper context and understanding.
                  </p>
                  <p>
                    The one-on-one format allows for personalized learning at your pace. You can 
                    ask questions, seek clarification, and engage in discussions that deepen your 
                    understanding. Our scholars adapt their teaching to your level of knowledge 
                    and areas of interest, ensuring a meaningful learning experience.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start your Islamic education journey today with a free trial session with a qualified scholar.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;The scholars explain complex topics in a way that everyone can understand. I&apos;ve learned so much about my faith that I never knew before.&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Yusuf</p>
                  <p className="text-xs md:text-sm text-gray-600">Islamic Studies Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Islamic Studies"
        subtitle="Find answers to common questions about our Islamic Studies program"
      />

      {/* Related Courses */}
      <RelatedCourses
        courses={relatedCoursesByCategory['islamic-studies']}
        title="Explore More Islamic Studies Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Deepen Your Islamic Knowledge Today
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join students around the world learning Islamic sciences with our qualified scholars.
            Book a free trial and begin your journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
