'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  BookMarked,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Award,
  Globe,
  Heart,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Tajweed – Master Quran Recitation Rules',
  category: 'Islamic Studies',
  rating: 5.0,
  students: 150,
  lessons: 400,
  description: 'Master the art of Quran recitation with proper Tajweed rules. Our certified Qaris will guide you through Makharij (articulation points), Sifaat (attributes of letters), and all the essential rules for beautiful, correct Quran recitation.',
  highlights: [
    'Certified Qaris with Ijazah',
    'One-on-one personalized sessions',
    'Learn Makharij and Sifaat',
    'Practice with live feedback',
    'Suitable for all levels',
    'Free trial class available',
  ],
  programs: [
    {
      name: 'Basic Tajweed',
      description: 'Learn the fundamental rules including Noon Sakinah, Tanween, Meem Sakinah, and basic Madd rules. Perfect for those who can read Quran but want to improve pronunciation.',
      duration: '3-6 months',
      level: 'Beginner',
    },
    {
      name: 'Intermediate Tajweed',
      description: 'Master advanced rules including Waqf (stopping rules), Hamzat, and complex Madd scenarios. Focus on applying rules fluently during recitation.',
      duration: '6-9 months',
      level: 'Intermediate',
    },
    {
      name: 'Advanced Tajweed',
      description: 'Perfect your recitation with detailed study of all Tajweed rules and their application. Learn the finer points that distinguish excellent reciters.',
      duration: '6-12 months',
      level: 'Advanced',
    },
    {
      name: 'Ijazah Preparation',
      description: 'Prepare for Ijazah certification with intensive practice and evaluation by certified scholars. This is the path to becoming a qualified Quran teacher.',
      duration: '1-2 years',
      level: 'Expert',
    },
  ],
}

const faqData = [
  {
    question: 'What is Tajweed and why is it important?',
    answer: 'Tajweed is the science of proper Quranic recitation, ensuring each Arabic letter is pronounced correctly from its point of articulation with its proper attributes. It\'s important because incorrect pronunciation can change the meaning of Quranic words. Learning Tajweed is considered a religious obligation to recite the Quran as it was revealed.',
  },
  {
    question: 'What are Makharij and Sifaat in Tajweed?',
    answer: 'Makharij (articulation points) are the specific places in the mouth, throat, or lips where each Arabic letter originates. Sifaat (attributes) are the characteristics of each letter, such as whether it\'s heavy (Tafkhim) or light (Tarqiq), whispered or voiced. Understanding both is essential for correct Quranic pronunciation.',
  },
  {
    question: 'How long does it take to learn Tajweed?',
    answer: 'The time varies based on your starting point and dedication. Basic Tajweed rules can be learned in 3-6 months with regular practice. Achieving fluency in applying all rules typically takes 6-12 months. For those seeking Ijazah (certification to teach), it may take 1-2 years of intensive study.',
  },
  {
    question: 'Do I need to know Arabic to learn Tajweed?',
    answer: 'While knowing Arabic helps, it\'s not required to start learning Tajweed. Many of our students begin with basic Quran reading skills and learn Tajweed alongside. Our teachers explain rules in English and provide practical demonstrations, making it accessible to non-Arabic speakers.',
  },
  {
    question: 'Can children learn Tajweed online?',
    answer: 'Absolutely! Children often learn Tajweed faster than adults because they\'re developing their speech patterns. Our teachers use engaging methods, visual aids, and age-appropriate explanations. We recommend starting Tajweed instruction around age 6-7, once the child can identify Arabic letters.',
  },
  {
    question: 'What Tajweed rules will I learn?',
    answer: 'Our comprehensive curriculum covers: Makharij (articulation points), Sifaat (letter attributes), rules of Noon Sakinah and Tanween (Idhar, Idgham, Iqlab, Ikhfa), rules of Meem Sakinah, Madd (prolongation) rules, Waqf (stopping rules), and the pronunciation of specific challenging letters.',
  },
  {
    question: 'How are online Tajweed classes conducted?',
    answer: 'Classes are conducted one-on-one via Zoom or Google Meet. The teacher demonstrates proper pronunciation, you practice, and receive immediate feedback. Screen sharing allows teachers to highlight specific verses and rules. Sessions are typically 30-45 minutes, allowing time for explanation, practice, and revision.',
  },
  {
    question: 'What is Ijazah and who needs it?',
    answer: 'An Ijazah is a certification granting permission to teach Quran recitation, indicating that you\'ve memorized the Quran and can recite it flawlessly according to Tajweed rules. It\'s essential for anyone who wants to teach Quran professionally or lead Taraweeh prayers. Our advanced program prepares students for Ijazah examination.',
  },
]

export default function TajweedCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/tajweed',
    category: 'Islamic Studies',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Tajweed', url: 'https://www.abobakracademy.com/courses/tajweed' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Tajweed" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader 
        title="Online Tajweed Classes" 
        subtitle="Master the art of Quran recitation with proper Tajweed rules"
        breadcrumb="Courses / Tajweed"
      />

      {/* Course Overview */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Active Students</p>
            </div>
            <div className="text-center">
              <BookMarked className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Completed</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Average Rating</p>
            </div>
            <div className="text-center">
              <Award className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">50+</p>
              <p className="text-white/70 text-sm">Certified Qaris</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Islamic Studies</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Our Tajweed Programs</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs md:text-sm text-gray-500">Duration</p>
                          <p className="font-semibold text-[#1DA678] text-sm md:text-base">{program.duration}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Learn Tajweed */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Master Tajweed?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    The Quran was revealed with specific rules of recitation that have been preserved 
                    through generations. Tajweed ensures that you recite the Quran exactly as it was 
                    revealed to Prophet Muhammad (peace be upon him), preserving both its beauty and 
                    its meaning.
                  </p>
                  <p>
                    Many Muslims recite the Quran without proper Tajweed, unknowingly making errors 
                    that can alter meanings. For example, a slight difference in pronunciation can 
                    change &quot;qalb&quot; (heart) to &quot;kalb&quot; (dog). Learning Tajweed protects 
                    you from such mistakes and enhances your spiritual connection with the Quran.
                  </p>
                  <p>
                    At Abobakr Academy, our certified Qaris provide personalized instruction that 
                    addresses your specific challenges. Whether you&apos;re struggling with certain 
                    letters, need to correct established habits, or want to perfect your recitation 
                    for Ijazah, our structured programs will guide you to success.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start your Tajweed journey today with a free 20-minute trial session with a certified Qari.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;I never knew Tajweed could be so interesting. The teacher explained each rule so clearly and gave me practical exercises. My recitation has improved dramatically!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Ahmed</p>
                  <p className="text-xs md:text-sm text-gray-600">Tajweed Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection 
        faqs={faqData} 
        title="Frequently Asked Questions About Tajweed"
        subtitle="Everything you need to know about learning Tajweed online"
      />

      {/* Related Courses */}
      <RelatedCourses 
        courses={relatedCoursesByCategory['islamic-studies']} 
        title="Explore More Islamic Studies Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Perfect Your Quran Recitation Today
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join hundreds of students who have mastered Tajweed with our expert tutors. 
            Your journey to beautiful Quran recitation starts here.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
