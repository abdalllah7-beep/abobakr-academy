import { Metadata } from 'next'
import TajweedCourse from './client'

export const metadata: Metadata = {
  title: 'Online Tajweed Classes | Master Quran Recitation Rules - Abobakr Academy',
  description: 'Learn Tajweed online with certified Qaris. Master Makharij (articulation points), Sifaat (letter attributes), Ghunna, Madd, and all Quran recitation rules. One-on-one personalized classes for beginners to advanced. Free trial available.',
  keywords: [
    'online tajweed classes',
    'learn tajweed online',
    'quran recitation rules',
    'makharij al huruf',
    'sifaat letters',
    'tajweed for beginners',
    'quran pronunciation rules',
    'tajweed tutor',
    'noorani qaida tajweed',
    'quran reading with tajweed',
    'tajweed course online',
    'ijazah preparation',
  ],
  alternates: {
    canonical: 'https://www.abobakracademy.com/courses/tajweed',
  },
  openGraph: {
    title: 'Online Tajweed Classes | Master Quran Recitation Rules',
    description: 'Learn Tajweed online with certified Qaris. Master Makharij, Sifaat, and proper Quran recitation. Free trial available.',
    url: 'https://www.abobakracademy.com/courses/tajweed',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Online Tajweed Classes - Master Quran Recitation Rules',
    description: 'Learn Tajweed online with certified Qaris. Master proper Quran recitation rules. Free trial!',
  },
}

export default function Page() {
  return <TajweedCourse />
}
