'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  FlaskConical,
  Star,
  Users,
  Clock,
  Calendar,
  MessageCircle,
  CheckCircle2,
  Globe,
  Heart,
  GraduationCap,
  ArrowRight,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { FAQSchema, CourseSchema, BreadcrumbSchema } from '@/components/seo'
import { FAQSection } from '@/components/faq-section'
import { RelatedCourses, relatedCoursesByCategory } from '@/components/related-courses'

const courseData = {
  name: 'Science – Physics, Chemistry & Biology',
  category: 'School Support',
  rating: 4.9,
  students: 120,
  lessons: 350,
  description: 'Excel in science with expert tutoring in Physics, Chemistry, and Biology. Our qualified tutors provide comprehensive support for all grade levels, from elementary to high school, aligned with your school curriculum.',
  highlights: [
    'Qualified science educators',
    'Curriculum-aligned lessons',
    'Homework help & exam prep',
    'Interactive experiments demos',
    'All grade levels supported',
    'Free trial class available',
  ],
  programs: [
    {
      name: 'General Science (Grades 4-8)',
      description: 'Build a strong foundation in basic scientific concepts and develop curiosity about the natural world.',
      duration: 'Ongoing',
      level: 'Elementary',
    },
    {
      name: 'Physics',
      description: 'Master mechanics, thermodynamics, waves, electricity, and modern physics concepts.',
      duration: 'Ongoing',
      level: 'Middle & High School',
    },
    {
      name: 'Chemistry',
      description: 'Learn atomic structure, chemical reactions, organic chemistry, and laboratory techniques.',
      duration: 'Ongoing',
      level: 'Middle & High School',
    },
    {
      name: 'Biology',
      description: 'Explore cell biology, genetics, ecology, human anatomy, and life sciences.',
      duration: 'Ongoing',
      level: 'Middle & High School',
    },
  ],
}

const faqData = [
  {
    question: 'What science subjects do you tutor?',
    answer: 'We provide comprehensive tutoring in all major science subjects: Physics (mechanics, electricity, waves, modern physics), Chemistry (general, organic, inorganic, physical chemistry), Biology (cell biology, genetics, ecology, anatomy), and General Science for elementary and middle school students. We align our instruction with your specific curriculum.',
  },
  {
    question: 'How do online science classes work?',
    answer: 'Online science classes are conducted one-on-one via Zoom or Google Meet. Tutors use screen sharing to present diagrams, animations, and visual materials. For problem-solving subjects like Physics and Chemistry, we use digital whiteboards to work through equations together. Sessions are interactive and include plenty of opportunities for questions.',
  },
  {
    question: 'Can you help with science homework and exam preparation?',
    answer: 'Absolutely! Homework help and exam preparation are core parts of our science tutoring. We guide you through difficult problems, teach problem-solving strategies, review key concepts, and practice with past exam papers. For standardized tests like AP, IB, or IGCSE exams, we provide targeted preparation focusing on exam-specific skills.',
  },
  {
    question: 'What qualifications do your science tutors have?',
    answer: 'Our science tutors hold degrees in their respective fields (Physics, Chemistry, Biology, or related sciences). Many have advanced degrees and teaching experience at schools and universities. They understand how to explain complex scientific concepts in accessible ways and are familiar with various curricula including IB, AP, IGCSE, and national programs.',
  },
  {
    question: 'How do you teach lab concepts online?',
    answer: 'While we cannot perform physical labs online, we use videos, virtual lab simulations, and detailed explanations to teach laboratory concepts. We cover experimental design, safety procedures, data analysis, and interpretation of results. Many exam questions about lab work can be answered through understanding concepts and procedures.',
  },
  {
    question: 'Can you help with AP or IB Science courses?',
    answer: 'Yes! We have tutors specifically experienced with AP Physics, AP Chemistry, AP Biology, and IB Science courses at both Standard and Higher Level. We know the exam formats, required practicals, and assessment criteria. Our students have achieved excellent results in these challenging courses.',
  },
  {
    question: 'What age groups do you teach science to?',
    answer: 'We teach science to students of all ages, from elementary school (Grade 4) through high school and into university-level courses. Our elementary program focuses on building curiosity and foundational understanding, while high school and university tutoring delves deeper into specific subjects and prepares students for advanced studies.',
  },
  {
    question: 'How quickly can I improve my science grades?',
    answer: 'Most students see noticeable improvement within 4-6 weeks of regular sessions. The timeline depends on your starting point, session frequency, and how much you practice between sessions. Our focus on conceptual understanding rather than rote memorization leads to lasting improvement that shows in grades and test scores.',
  },
]

export default function ScienceCourse() {
  const courseSchemaData = {
    name: courseData.name,
    description: courseData.description,
    provider: 'Abobakr Academy',
    url: 'https://www.abobakracademy.com/courses/science',
    category: 'School Support',
    rating: courseData.rating,
    reviewCount: courseData.students,
  }

  const breadcrumbItems = [
    { name: 'Home', url: 'https://www.abobakracademy.com' },
    { name: 'Courses', url: 'https://www.abobakracademy.com/courses' },
    { name: 'Science', url: 'https://www.abobakracademy.com/courses/science' },
  ]

  return (
    <main className="min-h-screen bg-white">
      {/* Schema Markup */}
      <FAQSchema faqs={faqData} courseName="Science" />
      <CourseSchema course={courseSchemaData} />
      <BreadcrumbSchema items={breadcrumbItems} />

      <Navigation />
      <PageHeader
        title="Science Tutoring"
        subtitle="Expert support for Physics, Chemistry, Biology & General Science"
        breadcrumb="Courses / Science"
      />

      {/* Course Overview */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center">
              <Users className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.students}+</p>
              <p className="text-white/70 text-sm">Students</p>
            </div>
            <div className="text-center">
              <FlaskConical className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.lessons}+</p>
              <p className="text-white/70 text-sm">Lessons Done</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-yellow-300 mx-auto mb-2 fill-yellow-300" />
              <p className="text-2xl md:text-3xl font-bold text-white">{courseData.rating}</p>
              <p className="text-white/70 text-sm">Rating</p>
            </div>
            <div className="text-center">
              <GraduationCap className="w-8 h-8 text-white/80 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">30+</p>
              <p className="text-white/70 text-sm">Science Tutors</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10 md:gap-16">
            {/* Left Content */}
            <div className="lg:col-span-2">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">School Support</Badge>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                {courseData.name}
              </h1>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                {courseData.description}
              </p>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-3 md:gap-4 mb-8 md:mb-10">
                {courseData.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center gap-2 md:gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-700 text-sm md:text-base">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Programs */}
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6">Our Science Programs</h2>
              <div className="space-y-4 md:space-y-6">
                {courseData.programs.map((program, index) => (
                  <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">{program.name}</h3>
                            <Badge variant="outline" className="text-xs">{program.level}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm md:text-base">{program.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs md:text-sm text-gray-500">Duration</p>
                          <p className="font-semibold text-[#1DA678] text-sm md:text-base">{program.duration}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Why Science Tutoring */}
              <div className="mt-12">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">Why Choose Our Science Tutoring?</h2>
                <div className="prose prose-lg text-gray-600 max-w-none">
                  <p>
                    Science education is fundamental to understanding our world and preparing for careers in
                    medicine, engineering, technology, and research. Yet many students struggle with science
                    because concepts are taught abstractly without connecting to real understanding.
                  </p>
                  <p>
                    At Abobakr Academy, we make science accessible and engaging. Our tutors use visual
                    demonstrations, real-world examples, and interactive problem-solving to bring scientific
                    concepts to life. We focus on building conceptual understanding that enables students to
                    tackle unfamiliar problems with confidence.
                  </p>
                  <p>
                    Whether you&apos;re preparing for AP exams, IB assessments, IGCSE, or just trying to
                    understand your school curriculum better, our personalized one-on-one tutoring adapts
                    to your needs. We&apos;ve helped students transform from science-phobic to confident
                    problem solvers ready for advanced studies.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Booking Card */}
              <Card className="border-0 shadow-xl sticky top-24">
                <CardContent className="p-5 md:p-6">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Book Your Free Trial</h3>
                  <p className="text-gray-600 text-sm md:text-base mb-4">
                    Start excelling in science today with a free trial session.
                  </p>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#1DA678]" />
                      <span>Flexible scheduling</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4 text-[#1DA678]" />
                      <span>Learn from anywhere</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="w-4 h-4 text-[#1DA678]" />
                      <span>100% satisfaction guaranteed</span>
                    </div>
                  </div>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-5 md:py-6 text-base md:text-lg" asChild>
                    <Link href="/contact#trial">
                      <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                      Book Free Trial
                    </Link>
                  </Button>
                  <p className="text-center text-xs md:text-sm text-gray-500 mt-4">
                    No credit card required
                  </p>
                </CardContent>
              </Card>

              {/* Testimonial */}
              <Card className="border-0 shadow-md bg-[#E8F8F2]">
                <CardContent className="p-5 md:p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm md:text-base italic mb-4">
                    &quot;My daughter finally understands Chemistry! The tutor makes complex concepts so simple. Her grades went from C to A in just two months!&quot;
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">— Sarah</p>
                  <p className="text-xs md:text-sm text-gray-600">Parent of Science Student</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection
        faqs={faqData}
        title="Frequently Asked Questions About Science Tutoring"
        subtitle="Everything you need to know about our online science program"
      />

      {/* Related Courses */}
      <RelatedCourses
        courses={relatedCoursesByCategory['school-support']}
        title="Explore More School Support Courses"
      />

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#1DA678] via-[#168a60] to-[#0f4d3a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Excel in Science Today
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Join students who have improved their science grades with our expert tutors.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button size="lg" className="bg-[#25D366] hover:bg-[#20BA5C] text-white shadow-lg shadow-[#25D366]/25 px-6 md:px-8 py-5 md:py-6 rounded-full" asChild>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
