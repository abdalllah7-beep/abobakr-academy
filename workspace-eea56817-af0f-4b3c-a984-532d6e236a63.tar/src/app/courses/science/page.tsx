import { Metadata } from 'next'
import ScienceCourse from './client'

export const metadata: Metadata = {
  title: 'Online Science Tutoring | Physics, Chemistry, Biology - Abobakr Academy',
  description: 'Expert online science tutoring for all grades. Physics, Chemistry, Biology, and general science. One-on-one sessions with qualified tutors. Free trial available.',
  keywords: 'online science tutor, physics tutoring, chemistry classes, biology tutor, science homework help, k-12 science',
  openGraph: {
    title: 'Online Science Tutoring | Physics, Chemistry, Biology',
    description: 'Expert online science tutoring for all grades with qualified tutors.',
    type: 'website',
  },
}

export default function Page() {
  return <ScienceCourse />
}
