'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Shield,
  Lock,
  Eye,
  Cookie,
  Users,
  Baby,
  Mail,
  Database,
  Globe,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const sections = [
  {
    icon: Database,
    title: '1. Information We Collect',
    content: `We collect information you provide directly to us, including:

**Personal Information:** When you register for an account, schedule classes, or contact us, we collect your name, email address, phone number, and payment information.

**Educational Information:** To provide personalized tutoring, we collect information about your learning goals, educational background, course preferences, and progress.

**Technical Information:** When you use our platform, we automatically collect information about your device, browser type, IP address, time zone, and browsing activities through cookies and similar technologies.

**Communication Records:** We keep records of your communications with us, including emails, chat messages, and session recordings (when enabled).`
  },
  {
    icon: Eye,
    title: '2. How We Use Your Information',
    content: `We use the information we collect to:

- Provide, maintain, and improve our tutoring services
- Process transactions and send related information
- Send you technical notices, updates, security alerts, and support messages
- Respond to your comments, questions, and customer service requests
- Communicate with you about products, services, and events offered by Abobakr Academy
- Monitor and analyze trends, usage, and activities in connection with our services
- Detect, investigate, and prevent fraudulent transactions and other illegal activities
- Personalize your learning experience and recommend relevant courses
- Facilitate the scheduling and conduct of tutoring sessions`
  },
  {
    icon: Lock,
    title: '3. Data Security',
    content: `We implement appropriate technical and organizational measures to protect your personal information, including:

**Encryption:** All data transmitted between your device and our servers is encrypted using SSL/TLS technology.

**Access Controls:** We restrict access to personal information to authorized personnel who need it to provide our services.

**Secure Storage:** Your data is stored on secure servers with industry-standard security measures.

**Regular Audits:** We conduct regular security assessments to identify and address vulnerabilities.

**However, no method of transmission over the Internet or electronic storage is 100% secure. While we strive to protect your personal information, we cannot guarantee its absolute security.**`
  },
  {
    icon: Cookie,
    title: '4. Cookies and Tracking Technologies',
    content: `We use cookies and similar tracking technologies to collect and track information about your activities on our platform. We use the following types of cookies:

**Essential Cookies:** Required for the platform to function properly, including session management and security.

**Functional Cookies:** Remember your preferences and settings to provide a personalized experience.

**Analytics Cookies:** Help us understand how you use our platform so we can improve our services.

**Marketing Cookies:** Used to deliver relevant advertisements and measure their effectiveness.

You can control cookies through your browser settings. Disabling certain cookies may affect your ability to use some features of our platform.`
  },
  {
    icon: Users,
    title: '5. Information Sharing',
    content: `We may share your information with:

**Tutors:** We share necessary information with your assigned tutor(s) to facilitate your learning sessions.

**Service Providers:** We work with third-party companies that process payments, host our platform, and provide other services necessary to operate our business.

**Legal Requirements:** We may disclose information if required by law or in response to lawful requests from public authorities.

**Business Transfers:** If Abobakr Academy is involved in a merger, acquisition, or sale of assets, your information may be transferred as part of that transaction.

**We do not sell your personal information to third parties for their marketing purposes.**`
  },
  {
    icon: Globe,
    title: '6. International Data Transfers',
    content: `Your information may be transferred to and processed in countries other than your own. These countries may have different data protection laws.

When we transfer your data internationally, we implement appropriate safeguards to ensure your information remains protected in accordance with this privacy policy. These safeguards may include:

- Standard contractual clauses approved by relevant data protection authorities
- Adequacy decisions recognizing certain countries as providing adequate protection
- Other legally valid mechanisms for international data transfers`
  },
  {
    icon: Baby,
    title: '7. Children\'s Privacy',
    content: `Our services are available to students of all ages, including children. We take special care to protect the privacy of children:

**Parental Consent:** For children under 13 years of age (or the applicable age in your jurisdiction), we obtain parental consent before collecting personal information.

**Limited Collection:** We collect only the minimal information necessary to provide our tutoring services to children.

**Parental Access:** Parents or guardians can review, update, or request deletion of their child's personal information.

**No Marketing to Children:** We do not send marketing communications directly to children.

If you are a parent or guardian and have questions about your child's use of our services, please contact us using the information below.`
  },
  {
    icon: Shield,
    title: '8. Your Rights and Choices',
    content: `Depending on your location, you may have certain rights regarding your personal information:

**Access:** You can request a copy of the personal information we hold about you.

**Correction:** You can request correction of inaccurate or incomplete information.

**Deletion:** You can request deletion of your personal information, subject to certain exceptions.

**Portability:** You may have the right to receive your information in a structured, machine-readable format.

**Opt-Out:** You can opt out of marketing communications at any time.

**Withdrawal of Consent:** Where we rely on consent, you can withdraw it at any time.

To exercise any of these rights, please contact us at privacy@abobakracademy.com.`
  },
  {
    icon: Mail,
    title: '9. Contact Information',
    content: `If you have questions or concerns about this privacy policy or our data practices, please contact us:

**Email:** privacy@abobakracademy.com
**WhatsApp:** +966 56 651 8545
**Website:** www.abobakracademy.com

We will respond to your inquiry within 30 days. If you are not satisfied with our response, you may have the right to lodge a complaint with your local data protection authority.`
  },
]

export default function PrivacyClient() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader
        title="Privacy Policy"
        subtitle="How we collect, use, and protect your personal information"
        breadcrumb="Privacy Policy"
      />

      {/* Introduction */}
      <section className="py-8 md:py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="p-6 md:p-8">
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Last Updated: January 2025</Badge>
              <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                Welcome to Abobakr Academy. We are committed to protecting your personal information and your right to privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our online tutoring services. Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the site or use our services.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Policy Sections */}
      <section className="py-8 md:py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8 md:space-y-12">
            {sections.map((section, index) => (
              <div key={index} className="scroll-mt-24" id={section.title.toLowerCase().replace(/\s+/g, '-').replace(/[0-9.]/g, '')}>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-[#1DA678]/10 flex items-center justify-center flex-shrink-0">
                    <section.icon className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-3 md:mb-4">{section.title}</h2>
                    <div className="text-gray-600 leading-relaxed text-sm md:text-base whitespace-pre-line">
                      {section.content}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Updates Notice */}
      <section className="py-8 md:py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-0 shadow-lg bg-[#1DA678]/5">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Policy Updates</h3>
              <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                We may update this privacy policy from time to time. The updated version will be indicated by an updated &quot;Last Updated&quot; date and the updated version will be effective as soon as it is accessible. We encourage you to review this privacy policy frequently to stay informed.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
