import { Metadata } from 'next'
import PrivacyClient from './client'

export const metadata: Metadata = {
  title: 'Privacy Policy | Abobakr Academy - Your Data Protection',
  description: 'Learn how Abobakr Academy collects, uses, and protects your personal information. Our comprehensive privacy policy covers data security, cookies, children\'s privacy, and more.',
  keywords: 'privacy policy, data protection, online tutoring privacy, student data security, GDPR compliance, children privacy',
  openGraph: {
    title: 'Privacy Policy | Abobakr Academy',
    description: 'How we collect, use, and protect your personal information.',
    type: 'website',
  },
}

export default function PrivacyPage() {
  return <PrivacyClient />
}
