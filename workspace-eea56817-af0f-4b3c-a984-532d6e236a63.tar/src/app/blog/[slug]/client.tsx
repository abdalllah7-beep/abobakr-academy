'use client'

import { useParams } from 'next/navigation'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Clock,
  Calendar,
  ArrowLeft,
  Twitter,
  Facebook,
  MessageCircle,
  Linkedin,
  BookOpen,
  CheckCircle2,
} from 'lucide-react'
import { Navigation, Footer, WhatsAppButton } from '@/components/layout'
import { blogPosts, getRelatedPosts } from '../posts-data'

function getIconComponent(iconName: string) {
  const icons: Record<string, React.ComponentType<{ className?: string }>> = {
    BookOpen: BookOpen,
    Languages: BookOpen,
    Calculator: BookOpen,
    Lightbulb: BookOpen,
    GraduationCap: BookOpen,
    Users: BookOpen,
    FlaskConical: BookOpen,
  }
  return icons[iconName] || BookOpen
}

function getColorClass(color: string) {
  return color || 'bg-emerald-500'
}

export default function BlogPostClient({ slug }: { slug: string }) {
  const params = useParams()
  const currentSlug = (params?.slug as string) || slug
  const post = blogPosts.find((p) => p.slug === currentSlug)

  if (!post) {
    return (
      <main className="min-h-screen bg-white">
        <Navigation />
        <div className="pt-32 pb-20 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Post Not Found</h1>
          <p className="text-gray-600 mb-8">The blog post you&apos;re looking for doesn&apos;t exist.</p>
          <Button asChild>
            <Link href="/blog">Back to Blog</Link>
          </Button>
        </div>
        <Footer />
        <WhatsAppButton />
      </main>
    )
  }

  const relatedPosts = getRelatedPosts(post.slug, post.category, 3)
  const IconComponent = getIconComponent(post.icon)
  const colorClass = getColorClass(post.color)

  const shareUrl = typeof window !== 'undefined' ? window.location.href : `https://www.abobakracademy.com/blog/${post.slug}`

  const shareButtons = [
    { icon: Twitter, label: 'Twitter', href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(shareUrl)}` },
    { icon: Facebook, label: 'Facebook', href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}` },
    { icon: Linkedin, label: 'LinkedIn', href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}` },
    { icon: MessageCircle, label: 'WhatsApp', href: `https://wa.me/?text=${encodeURIComponent(post.title + ' ' + shareUrl)}` },
  ]

  return (
    <main className="min-h-screen bg-white">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-24 md:pt-32 pb-8 md:pb-12 bg-gradient-to-br from-[#E8F8F2] via-white to-[#F0FDF7]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb */}
          <nav className="mb-6" aria-label="Breadcrumb">
            <ol className="flex items-center gap-2 flex-wrap">
              <li>
                <Link 
                  href="/" 
                  className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-gray-600 bg-white rounded-full border border-gray-200 hover:text-[#1DA678] hover:border-[#1DA678] transition-colors shadow-sm"
                >
                  Home
                </Link>
              </li>
              <li className="text-gray-400">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </li>
              <li>
                <Link 
                  href="/blog" 
                  className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-gray-600 bg-white rounded-full border border-gray-200 hover:text-[#1DA678] hover:border-[#1DA678] transition-colors shadow-sm"
                >
                  Blog
                </Link>
              </li>
              <li className="text-gray-400">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </li>
              <li>
                <span className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-white bg-[#1DA678] rounded-full shadow-sm">
                  {post.category}
                </span>
              </li>
            </ol>
          </nav>

          {/* Category Badge */}
          <div className="flex items-center gap-3 mb-4">
            <Badge className={`${colorClass} text-white`}>{post.category}</Badge>
            {post.featured && (
              <Badge className="bg-yellow-100 text-yellow-700 border border-yellow-200">Featured</Badge>
            )}
          </div>

          {/* Title */}
          <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 md:mb-6 leading-tight">
            {post.title}
          </h1>

          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-4 md:gap-6 text-gray-600 mb-6 md:mb-8">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#1DA678]" />
              <span className="text-sm">{post.date}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#1DA678]" />
              <span className="text-sm">{post.readTime}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#1DA678] flex items-center justify-center text-white text-xs font-bold">
                AA
              </div>
              <span className="text-sm">{post.author}</span>
            </div>
          </div>

          {/* Share Buttons */}
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-600 font-medium">Share:</span>
            {shareButtons.map((button) => (
              <a
                key={button.label}
                href={button.href}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-gray-100 hover:bg-[#1DA678] flex items-center justify-center transition-colors group"
                aria-label={`Share on ${button.label}`}
              >
                <button.icon className="w-4 h-4 text-gray-600 group-hover:text-white" />
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Article Content */}
      <article className="py-8 md:py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-none">
            <div 
              className="text-gray-700 leading-relaxed space-y-6"
              dangerouslySetInnerHTML={{ __html: post.content.replace(/\n/g, '<br />').replace(/## /g, '<h2 class="text-xl md:text-2xl font-bold text-gray-900 mt-8 mb-4">').replace(/### /g, '<h3 class="text-lg md:text-xl font-semibold text-gray-900 mt-6 mb-3">').replace(/\*\*(.*?)\*\*/g, '<strong class="text-gray-900">$1</strong>').replace(/- /g, '</div><div class="flex items-start gap-2"><CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0 mt-0.5" /><span>').replace(/<h2/g, '</div><h2').replace(/<h3/g, '</div><h3') }}
            />
          </div>

          {/* Related Courses */}
          <div className="mt-12 pt-8 border-t">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Related Courses</h3>
            <div className="flex flex-wrap gap-3">
              {post.relatedCourses.map((course) => (
                <Link key={course.href} href={course.href}>
                  <Badge className="bg-[#E8F8F2] text-[#1DA678] hover:bg-[#1DA678] hover:text-white transition-colors cursor-pointer px-4 py-2">
                    {course.name}
                  </Badge>
                </Link>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="mt-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {post.keywords.split(', ').map((keyword) => (
                <Badge key={keyword} variant="outline" className="text-gray-600">
                  {keyword}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </article>

      {/* CTA Section */}
      <section className="py-12 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Start Learning?
          </h2>
          <p className="text-base md:text-lg text-white/70 mb-6 md:mb-8">
            Apply what you&apos;ve learned with our expert tutors. Book a free trial class today.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button
              size="lg"
              className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button
              size="lg"
              className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                WhatsApp Us
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="py-12 md:py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6 md:mb-8">Related Articles</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {relatedPosts.map((relatedPost) => (
                <Link key={relatedPost.slug} href={`/blog/${relatedPost.slug}`}>
                  <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 h-full cursor-pointer group">
                    <CardContent className="p-5">
                      <Badge className={`${getColorClass(relatedPost.color)} text-white text-xs mb-3`}>
                        {relatedPost.category}
                      </Badge>
                      <h3 className="text-base font-semibold text-gray-900 mb-2 group-hover:text-[#1DA678] transition-colors line-clamp-2">
                        {relatedPost.title}
                      </h3>
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">{relatedPost.excerpt}</p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{relatedPost.readTime}</span>
                        </div>
                        <span>{relatedPost.date}</span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Back to Blog */}
      <section className="py-8 bg-white border-t">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link 
            href="/blog" 
            className="inline-flex items-center text-[#1DA678] hover:text-[#168a60] font-medium transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to All Articles
          </Link>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />

      {/* JSON-LD Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Article',
            headline: post.title,
            description: post.excerpt,
            author: {
              '@type': 'Organization',
              name: post.author,
            },
            datePublished: post.date,
            dateModified: post.date,
            publisher: {
              '@type': 'Organization',
              name: 'Abobakr Academy',
              logo: {
                '@type': 'ImageObject',
                url: 'https://www.abobakracademy.com/logo.png',
              },
            },
            mainEntityOfPage: {
              '@type': 'WebPage',
              '@id': `https://www.abobakracademy.com/blog/${post.slug}`,
            },
            articleSection: post.category,
            keywords: post.keywords,
          }),
        }}
      />
    </main>
  )
}
