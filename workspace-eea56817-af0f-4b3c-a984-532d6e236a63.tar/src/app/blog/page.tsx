import { Metadata } from 'next'
import BlogClient from './client'

export const metadata: Metadata = {
  title: 'Blog | Abobakr Academy - Educational Tips & Learning Resources',
  description: 'Explore our educational blog for tips on online learning, Quran studies, language learning, exam preparation, and more. Expert advice from qualified tutors.',
  keywords: 'education blog, online learning tips, quran learning tips, language learning, exam preparation, study tips, tutoring advice',
  openGraph: {
    title: 'Blog | Abobakr Academy',
    description: 'Educational tips, learning resources, and insights from expert tutors.',
    type: 'website',
  },
}

export default function BlogPage() {
  return <BlogClient />
}
