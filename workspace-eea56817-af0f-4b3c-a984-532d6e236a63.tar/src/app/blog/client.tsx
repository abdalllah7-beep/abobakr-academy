'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Calendar,
  Clock,
  ArrowRight,
  BookOpen,
  Lightbulb,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'
import { blogPosts } from './posts-data'

const categories = [
  { name: 'All Posts', count: blogPosts.length },
  { name: 'Islamic Studies', count: blogPosts.filter(p => p.category === 'Islamic Studies').length },
  { name: 'Languages', count: blogPosts.filter(p => p.category === 'Languages').length },
  { name: 'School Support', count: blogPosts.filter(p => p.category === 'School Support').length },
  { name: 'Study Tips', count: blogPosts.filter(p => p.category === 'Study Tips').length },
  { name: 'Education', count: blogPosts.filter(p => p.category === 'Education').length },
]

export default function BlogClient() {
  const featuredPosts = blogPosts.filter(p => p.featured)

  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader
        title="Our Blog"
        subtitle="Educational insights, learning tips, and resources from our expert tutors"
        breadcrumb="Blog"
      />

      {/* Featured Posts */}
      <section className="py-12 md:py-16 bg-[#E8F8F2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 mb-6 md:mb-8">
            <Lightbulb className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
            <h2 className="text-xl md:text-2xl font-bold text-gray-900">Featured Articles</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredPosts.map((post, index) => (
              <Link key={post.slug} href={`/blog/${post.slug}`}>
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white h-full cursor-pointer group">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge className="bg-[#1DA678]/10 text-[#1DA678]">{post.category}</Badge>
                      {index === 0 && <Badge className="bg-yellow-100 text-yellow-700">Featured</Badge>}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-[#1DA678] transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">{post.excerpt}</p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{post.readTime}</span>
                      </div>
                      <span>{post.date}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* All Posts with Categories */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-4 gap-8 md:gap-12">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Categories</h3>
                <div className="space-y-2">
                  {categories.map((cat) => (
                    <button
                      key={cat.name}
                      className="flex items-center justify-between w-full px-3 py-2 text-left text-sm rounded-lg hover:bg-[#E8F8F2] transition-colors text-gray-700 hover:text-[#1DA678]"
                    >
                      <span>{cat.name}</span>
                      <Badge variant="secondary" className="bg-gray-100 text-gray-600">{cat.count}</Badge>
                    </button>
                  ))}
                </div>

                <div className="mt-8 p-4 bg-[#E8F8F2] rounded-xl">
                  <h4 className="font-semibold text-gray-900 mb-2">Subscribe to Updates</h4>
                  <p className="text-sm text-gray-600 mb-3">Get the latest articles delivered to your inbox.</p>
                  <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white" asChild>
                    <Link href="/contact">Subscribe</Link>
                  </Button>
                </div>
              </div>
            </div>

            {/* Posts Grid */}
            <div className="lg:col-span-3">
              <div className="flex items-center gap-2 mb-6">
                <BookOpen className="w-5 h-5 text-[#1DA678]" />
                <h2 className="text-xl font-bold text-gray-900">All Articles</h2>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {blogPosts.map((post) => (
                  <Link key={post.slug} href={`/blog/${post.slug}`}>
                    <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-white h-full cursor-pointer group">
                      <CardContent className="p-5">
                        <Badge className="bg-[#1DA678]/10 text-[#1DA678] text-xs mb-3">{post.category}</Badge>
                        <h3 className="text-base font-semibold text-gray-900 mb-2 group-hover:text-[#1DA678] transition-colors line-clamp-2">
                          {post.title}
                        </h3>
                        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{post.excerpt}</p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{post.readTime}</span>
                          </div>
                          <span>{post.date}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
            Ready to Start Learning?
          </h2>
          <p className="text-base md:text-xl text-white/70 mb-6 md:mb-8">
            Apply what you&apos;ve learned with our expert tutors. Book a free trial class today.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button
              size="lg"
              className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button
              size="lg"
              className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/courses">
                View All Courses
                <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
