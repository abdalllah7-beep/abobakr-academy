import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://www.abobakracademy.com"),
  title: {
    default: "Abobakr Academy | Expert Online Private Tutors - Quran, Languages & School Support",
    template: "%s | Abobakr Academy",
  },
  description: "Expert online private tutors for personalized 1-on-1 learning. Islamic Studies (Quran, Tajweed), Languages (Arabic, English, German, French), School Support (Math, Science, Physics), Digital Skills. 100+ students, 2500+ lessons. Free trial available!",
  keywords: [
    "online tutoring", 
    "private tutors", 
    "quran classes", 
    "tajweed classes", 
    "arabic lessons", 
    "english tutoring", 
    "math tutor online",
    "physics tutor",
    "chemistry tutor",
    "islamic studies", 
    "language classes",
    "ICDL certification",
    "programming courses",
    "online education",
    "1-on-1 tutoring",
    "K-12 tutoring",
    "DELF preparation",
    "IELTS preparation"
  ],
  authors: [{ name: "Abobakr Academy", url: "https://www.abobakracademy.com" }],
  creator: "Abobakr Academy",
  publisher: "Abobakr Academy",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: "/logo.png",
    apple: "/logo.png",
  },
  openGraph: {
    title: "Abobakr Academy | Expert Online Private Tutors",
    description: "Personalized 1-on-1 online tutoring for Quran, Languages, School Support & Digital Skills. Free trial available!",
    url: "https://www.abobakracademy.com",
    siteName: "Abobakr Academy",
    type: "website",
    locale: "en_US",
    images: [
      {
        url: "/logo.png",
        width: 1200,
        height: 630,
        alt: "Abobakr Academy - Expert Online Private Tutors",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Abobakr Academy | Expert Online Private Tutors",
    description: "Personalized 1-on-1 online tutoring for Quran, Languages, School Support & more. Free trial!",
    images: ["/logo.png"],
  },
  alternates: {
    canonical: "https://www.abobakracademy.com",
  },
  category: "Education",
};

// JSON-LD Structured Data
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  name: "Abobakr Academy",
  description: "Expert online private tutors for personalized 1-on-1 learning. Islamic Studies, Languages, School Support & Digital Skills.",
  url: "https://www.abobakracademy.com",
  logo: "https://www.abobakracademy.com/logo.png",
  telephone: "+966566518545",
  email: "info@abobakracademy.com",
  address: {
    "@type": "PostalAddress",
    addressCountry: "SA",
  },
  sameAs: [
    "https://facebook.com/profile.php?id=100094681973805",
    "https://t.me/abobakracademy",
    "https://tiktok.com/@abobakracademy",
  ],
  offers: {
    "@type": "Offer",
    description: "Online tutoring services for various subjects",
    price: "Contact for pricing",
    priceCurrency: "USD",
  },
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "4.8",
    reviewCount: "100",
    bestRating: "5",
    worstRating: "1",
  },
  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "Course Categories",
    itemListElement: [
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Course",
          name: "Quran & Tajweed",
          description: "Learn Quran reading, recitation and memorization",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Course",
          name: "Arabic Language",
          description: "Modern Standard Arabic with native instructors",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Course",
          name: "English Language",
          description: "IELTS prep, conversation, business English",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Course",
          name: "Mathematics",
          description: "K-12 math tutoring and exam preparation",
        },
      },
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
