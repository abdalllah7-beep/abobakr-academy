'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import {
  Calendar,
  MessageCircle,
  HelpCircle,
  BookOpen,
  CreditCard,
  Settings,
  Users,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const faqCategories = [
  {
    title: 'General Questions',
    icon: HelpCircle,
    color: 'bg-blue-500',
    questions: [
      {
        question: 'What is Abobakr Academy?',
        answer: 'Abobakr Academy is a leading online tutoring platform providing personalized 1-on-1 education for students of all ages. We offer expert tutors in Islamic Studies (Quran, Tajweed), Languages (Arabic, English, German, French, Spanish, Italian), School Curriculum Support (Math, Physics, Chemistry, Biology), and Digital Skills (Programming, ICDL). Our mission is to make quality education accessible to everyone, anywhere in the world.'
      },
      {
        question: 'How does online tutoring work?',
        answer: 'Our online tutoring sessions are conducted via video conferencing platforms like Zoom and Google Meet. After booking a session, you\'ll receive a link to join your private class. During the session, you\'ll have live video interaction with your tutor, share screens for collaborative learning, and use digital whiteboards for explanations. All you need is a stable internet connection, a computer or tablet with a camera and microphone.'
      },
      {
        question: 'Is Abobakr Academy suitable for all ages?',
        answer: 'Yes! We welcome students of all ages, from young children learning Quran basics to adults preparing for language certifications. Our tutors are experienced in adapting their teaching methods to suit different age groups and learning styles. We have specialized programs for kids, teenagers, and adult learners.'
      },
      {
        question: 'What makes Abobakr Academy different from other tutoring platforms?',
        answer: 'We stand out through our carefully vetted expert tutors, personalized learning approach, flexible scheduling, and commitment to student success. We offer a free trial class so you can experience our teaching quality before committing. Our tutors are not just teachers - they\'re mentors who care about your progress and success.'
      },
      {
        question: 'Do you offer a free trial?',
        answer: 'Yes! We offer a free 20-minute trial class for any course. This allows you to meet your potential tutor, experience our teaching style, and discuss your learning goals before making any commitment. There\'s no credit card required to book a trial.'
      },
    ]
  },
  {
    title: 'Courses & Subjects',
    icon: BookOpen,
    color: 'bg-emerald-500',
    questions: [
      {
        question: 'What courses do you offer?',
        answer: 'We offer a wide range of courses across four main categories: Islamic Studies (Quran Reading, Quran Memorization, Tajweed, Qaida, Islamic Studies), Languages (Arabic, English, German, French, Spanish, Italian), School Support (Mathematics, Physics, Chemistry, Biology, Science, History, Geography), and Digital Skills (Programming, ICDL, Microsoft Office). We also offer exam preparation courses for IELTS, Goethe, and IGCSE.'
      },
      {
        question: 'What teaching methods do your tutors use?',
        answer: 'Our tutors use a variety of proven teaching methods tailored to each student\'s needs. These include interactive discussions, visual aids, practical exercises, real-world applications, and regular assessments. For Quran and Tajweed, we use traditional methods combined with modern technology. Language courses incorporate immersion techniques and conversation practice.'
      },
      {
        question: 'Can I request a specific tutor?',
        answer: 'Yes, you can request a specific tutor based on their profile, expertise, and student reviews. After your trial session, if you feel the tutor is a good fit, you can continue with them. If not, we\'ll happily match you with another qualified tutor who better suits your learning style.'
      },
      {
        question: 'Do you provide study materials?',
        answer: 'Yes, our tutors provide comprehensive study materials including digital textbooks, practice worksheets, video resources, and interactive exercises. For Quran courses, we provide Tajweed charts and memorization plans. All materials are included in your course fee.'
      },
      {
        question: 'Can I take multiple courses simultaneously?',
        answer: 'Absolutely! Many of our students take multiple courses. For example, a student might take Quran classes in the morning and Math tutoring in the afternoon. Our flexible scheduling system allows you to coordinate multiple courses without conflicts.'
      },
    ]
  },
  {
    title: 'Pricing & Payments',
    icon: CreditCard,
    color: 'bg-purple-500',
    questions: [
      {
        question: 'How is pricing determined?',
        answer: 'Our pricing is based on the subject, level, and session duration. We offer competitive rates starting from affordable hourly rates. We have flexible packages including monthly plans and pay-per-session options. Contact us for a detailed quote based on your specific learning needs.'
      },
      {
        question: 'What payment methods do you accept?',
        answer: 'We accept various payment methods including credit/debit cards, PayPal, bank transfers, and local payment options in many countries. For students in Saudi Arabia and the Gulf region, we accept local payment methods. Payment is typically made in advance for scheduled sessions.'
      },
      {
        question: 'Do you offer discounts for multiple sessions?',
        answer: 'Yes! We offer discounted rates for students who book multiple sessions or commit to monthly packages. The more sessions you book, the greater the discount. Families with multiple children also qualify for special family discounts. Contact us to learn about current promotions.'
      },
      {
        question: 'What is your refund policy?',
        answer: 'If you\'re not satisfied with a session, please contact us within 24 hours and we\'ll work to resolve the issue or provide a credit for a future session. For package purchases, unused sessions can be refunded within 14 days of purchase, minus a small administrative fee.'
      },
      {
        question: 'Are there any hidden fees?',
        answer: 'No hidden fees whatsoever. The price you agree to covers your tutoring sessions, study materials, and access to our learning platform. There are no registration fees, platform fees, or additional charges unless you request extra services like certification exams.'
      },
    ]
  },
  {
    title: 'Technical Support',
    icon: Settings,
    color: 'bg-orange-500',
    questions: [
      {
        question: 'What platform do you use for classes?',
        answer: 'We primarily use Zoom and Google Meet for our live tutoring sessions. These platforms offer excellent video quality, screen sharing, interactive whiteboards, and recording capabilities. You\'ll receive a direct link to join each session - no account required for most sessions.'
      },
      {
        question: 'What equipment do I need?',
        answer: 'You need a computer, tablet, or smartphone with a stable internet connection (minimum 5 Mbps recommended), a working camera and microphone, and a quiet space for learning. Headphones are recommended for better audio quality. For programming courses, a laptop or desktop computer is preferred.'
      },
      {
        question: 'What if I have technical issues during a session?',
        answer: 'If you experience technical difficulties, contact us immediately via WhatsApp. Our support team can help troubleshoot common issues. If a session is disrupted due to technical problems on our end, we\'ll reschedule at no extra cost. We recommend testing your setup before your first session.'
      },
      {
        question: 'Can I record my sessions?',
        answer: 'Yes, sessions can be recorded upon request. Recorded sessions are great for reviewing complex topics and for practice between sessions. Recordings are stored securely and shared only with you. Some courses include complimentary session recordings as part of the package.'
      },
      {
        question: 'Do I need to download any software?',
        answer: 'For Zoom sessions, you may need to download the free Zoom app, though you can also join via web browser. For Google Meet, no download is required - just click the link and join. Our technical support team can guide you through setup if needed.'
      },
    ]
  },
  {
    title: 'Scheduling & Attendance',
    icon: Calendar,
    color: 'bg-teal-500',
    questions: [
      {
        question: 'How flexible is the scheduling?',
        answer: 'Very flexible! Our tutors are available from early morning to late evening, seven days a week. You can schedule sessions at times that work best for you. We accommodate students in different time zones worldwide. Rescheduling is easy with at least 24 hours notice.'
      },
      {
        question: 'What is your cancellation policy?',
        answer: 'We request at least 24 hours notice for cancellations or rescheduling. Late cancellations (less than 24 hours) may result in the session being counted as used. However, we understand emergencies happen and will work with you on a case-by-case basis.'
      },
      {
        question: 'How long is each session?',
        answer: 'Standard sessions are typically 45-60 minutes, depending on the subject and student preference. We also offer 30-minute sessions for younger children and 90-minute intensive sessions for exam preparation. Session length can be customized to your needs.'
      },
      {
        question: 'What if I miss a session?',
        answer: 'If you miss a session without prior notice, it will be counted as used. However, we understand that unexpected situations arise. Contact us as soon as possible, and we\'ll do our best to reschedule or provide a make-up session. Regular attendance helps maintain learning momentum.'
      },
      {
        question: 'Can I change my regular time slot?',
        answer: 'Yes, you can change your regular time slot if your schedule changes. Just inform us at least one week in advance so we can coordinate with your tutor. We\'ll work to find a new time that works for both you and your tutor.'
      },
    ]
  },
]

export default function FAQClient() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader
        title="Frequently Asked Questions"
        subtitle="Find answers to common questions about our online tutoring services"
        breadcrumb="FAQ"
      />

      {/* FAQ Categories */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {faqCategories.map((category, categoryIndex) => (
            <div key={categoryIndex} className="mb-8 md:mb-12">
              <div className="flex items-center gap-3 mb-4 md:mb-6">
                <div className={`w-10 h-10 md:w-12 md:h-12 rounded-xl ${category.color} flex items-center justify-center`}>
                  <category.icon className="w-5 h-5 md:w-6 md:h-6 text-white" />
                </div>
                <h2 className="text-xl md:text-2xl font-bold text-gray-900">{category.title}</h2>
              </div>

              <Accordion type="single" collapsible className="space-y-3 md:space-y-4">
                {category.questions.map((item, index) => (
                  <AccordionItem
                    key={index}
                    value={`${categoryIndex}-${index}`}
                    className="bg-white rounded-xl shadow-md border-0 px-4 md:px-6"
                  >
                    <AccordionTrigger className="text-left font-semibold text-gray-900 hover:text-[#1DA678] hover:no-underline py-4 md:py-5 text-sm md:text-base">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600 pb-4 md:pb-5 leading-relaxed text-sm md:text-base">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}
        </div>
      </section>

      {/* Still Have Questions */}
      <section className="py-12 md:py-20 bg-[#1DA678]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Still Have Questions?
          </h2>
          <p className="text-base md:text-lg text-white/80 mb-6 md:mb-8">
            Our support team is here to help. Contact us and we&apos;ll get back to you as soon as possible.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button
              size="lg"
              className="bg-white text-[#1DA678] hover:bg-gray-100 px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact">
                Contact Support
              </Link>
            </Button>
            <Button
              size="lg"
              className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                WhatsApp Us
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
