import { Metadata } from 'next'
import FAQClient from './client'

export const metadata: Metadata = {
  title: 'Frequently Asked Questions | Abobakr Academy - Online Tutoring Help',
  description: 'Find answers to common questions about Abobakr Academy\'s online tutoring services. Learn about our courses, pricing, scheduling, platform requirements, and more.',
  keywords: 'online tutoring FAQ, tutoring questions, how online tutoring works, tutor pricing FAQ, platform requirements, course information',
  openGraph: {
    title: 'FAQ | Abobakr Academy',
    description: 'Get answers to your questions about our online tutoring services.',
    type: 'website',
  },
}

export default function FAQPage() {
  return <FAQClient />
}
