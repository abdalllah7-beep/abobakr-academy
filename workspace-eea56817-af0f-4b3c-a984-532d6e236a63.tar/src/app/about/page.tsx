'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Target,
  Eye,
  Heart,
  Award,
  Globe,
  CheckCircle2,
  Users,
  BookOpen,
  Clock,
  Trophy,
  ArrowRight,
  Calendar,
  MessageCircle,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const values = [
  {
    icon: Target,
    title: 'Excellence',
    description: 'We strive for the highest quality in every lesson, ensuring each student reaches their full potential through rigorous standards and continuous improvement.',
  },
  {
    icon: Heart,
    title: 'Care',
    description: 'Every student matters to us. We provide personalized attention, emotional support, and a nurturing environment throughout their learning journey.',
  },
  {
    icon: Award,
    title: 'Integrity',
    description: 'We maintain the highest ethical standards in all our interactions with students, parents, and tutors. Trust is the foundation of our relationships.',
  },
  {
    icon: Globe,
    title: 'Accessibility',
    description: 'Quality education should be accessible to everyone, regardless of location or background. We bridge geographical gaps through online learning.',
  },
]

const milestones = [
  { year: '2020', title: 'Founded', description: 'Abobakr Academy was established with a vision to transform online education.' },
  { year: '2021', title: '50+ Students', description: 'Reached our first milestone of 50 active students across multiple subjects.' },
  { year: '2022', title: '1000+ Lessons', description: 'Completed over 1000 successful tutoring sessions with excellent feedback.' },
  { year: '2023', title: 'Curriculum Expansion', description: 'Added new subjects including Chemistry, Physics, and Biology to our curriculum.' },
  { year: '2024', title: '100+ Active Students', description: 'Now serving over 100 active students with 50+ qualified tutors worldwide.' },
]

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader 
        title="About Us" 
        subtitle="Empowering students through personalized online tutoring since 2020"
        breadcrumb="About"
      />

      {/* Story Section */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-10 md:gap-16 items-center">
            <div>
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Our Story</Badge>
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                Building the Future of <span className="text-[#1DA678]">Online Education</span>
              </h2>
              <p className="text-base md:text-lg text-gray-600 mb-6 leading-relaxed">
                Abobakr Academy was founded in 2020 with a simple but powerful mission: to make quality education 
                accessible to every student, regardless of their location. What started as a small team of 
                passionate educators has grown into a thriving online tutoring platform.
              </p>
              <p className="text-base md:text-lg text-gray-600 mb-6 leading-relaxed">
                We noticed that many students struggled to find qualified tutors who could provide personalized 
                attention. Traditional tutoring centers were often expensive and inflexible. We set out to change 
                that by connecting students with expert teachers through a convenient online platform.
              </p>
              <p className="text-base md:text-lg text-gray-600 mb-8 leading-relaxed">
                Today, we serve over 100 active students and have completed more than 2,500 lessons. Our success 
                is measured not just in numbers, but in the academic achievements and confidence growth of our students.
              </p>
              
              <div className="grid grid-cols-2 gap-4 md:gap-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#E8F8F2] flex items-center justify-center">
                    <Users className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div>
                    <p className="text-xl md:text-2xl font-bold text-[#1DA678]">100+</p>
                    <p className="text-xs md:text-sm text-gray-600">Active Students</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#E8F8F2] flex items-center justify-center">
                    <BookOpen className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div>
                    <p className="text-xl md:text-2xl font-bold text-[#1DA678]">2500+</p>
                    <p className="text-xs md:text-sm text-gray-600">Lessons Completed</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#E8F8F2] flex items-center justify-center">
                    <Clock className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div>
                    <p className="text-xl md:text-2xl font-bold text-[#1DA678]">4+ Years</p>
                    <p className="text-xs md:text-sm text-gray-600">Experience</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#E8F8F2] flex items-center justify-center">
                    <Trophy className="w-5 h-5 md:w-6 md:h-6 text-[#1DA678]" />
                  </div>
                  <div>
                    <p className="text-xl md:text-2xl font-bold text-[#1DA678]">98%</p>
                    <p className="text-xs md:text-sm text-gray-600">Success Rate</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-br from-[#0f2922] to-[#1DA678] rounded-2xl md:rounded-3xl p-6 md:p-10 text-white">
                <h3 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Quick Facts</h3>
                <div className="space-y-3 md:space-y-4">
                  {[
                    'Founded in 2020',
                    '50+ qualified tutors',
                    '20+ subjects covered',
                    'Students from 10+ countries',
                    'Average rating of 4.8/5',
                    'Flexible scheduling 7 days a week',
                    'Free trial class available',
                    'Progress tracking & reports',
                  ].map((fact, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 md:w-6 md:h-6 text-[#4ADE80] flex-shrink-0" />
                      <span className="text-sm md:text-base">{fact}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-[#1DA678] rounded-full opacity-30 blur-xl pointer-events-none" />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Our Values</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              What We <span className="text-[#1DA678]">Stand For</span>
            </h2>
            <p className="text-base md:text-xl text-gray-600 max-w-2xl mx-auto">
              Our core values guide everything we do, from how we teach to how we interact with our community.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {values.map((value, index) => (
              <Card 
                key={index} 
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white text-center"
              >
                <CardContent className="p-6 md:p-8">
                  <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4 md:mb-6">
                    <value.icon className="w-7 h-7 md:w-8 md:h-8 text-white" />
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2 md:mb-3">{value.title}</h3>
                  <p className="text-gray-600 text-sm md:text-base">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            <Card className="border-2 border-[#1DA678]/20 bg-gradient-to-br from-[#E8F8F2] to-white">
              <CardContent className="p-6 md:p-10">
                <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
                  <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-[#1DA678] flex items-center justify-center">
                    <Eye className="w-6 h-6 md:w-7 md:h-7 text-white" />
                  </div>
                  <h3 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">Our Vision</h3>
                </div>
                <p className="text-gray-600 text-sm md:text-lg leading-relaxed">
                  To become the leading online tutoring platform in the Middle East, recognized for excellence 
                  in education and student success. We envision a world where every student has access to the 
                  best teachers, regardless of geographical barriers. Our goal is to empower the next generation 
                  of learners with the knowledge and skills they need to succeed in an ever-changing world.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-2 border-[#1DA678]/20 bg-gradient-to-br from-[#E8F8F2] to-white">
              <CardContent className="p-6 md:p-10">
                <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
                  <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-[#1DA678] flex items-center justify-center">
                    <Target className="w-6 h-6 md:w-7 md:h-7 text-white" />
                  </div>
                  <h3 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">Our Mission</h3>
                </div>
                <p className="text-gray-600 text-sm md:text-lg leading-relaxed">
                  To provide accessible, high-quality education through personalized online tutoring that adapts 
                  to each student&apos;s unique learning style. We are committed to helping students achieve academic 
                  excellence while making learning enjoyable and engaging. We connect passionate educators with 
                  eager learners, creating meaningful educational experiences that last a lifetime.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Our Journey</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Milestones & <span className="text-[#1DA678]">Achievements</span>
            </h2>
          </div>
          
          <div className="relative">
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-[#1DA678]/20 -translate-x-1/2" />
            
            <div className="space-y-8 md:space-y-12">
              {milestones.map((milestone, index) => (
                <div 
                  key={index} 
                  className={`relative flex items-center gap-4 md:gap-8 ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'} hidden md:block`}>
                    <Card className="border-0 shadow-lg inline-block">
                      <CardContent className="p-4 md:p-6">
                        <p className="text-[#1DA678] font-bold text-lg md:text-xl mb-1 md:mb-2">{milestone.year}</p>
                        <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-1 md:mb-2">{milestone.title}</h3>
                        <p className="text-gray-600 text-sm md:text-base">{milestone.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-[#1DA678] rounded-full -translate-x-1/2 z-10" />
                  
                  <div className="flex-1 ml-8 md:ml-0 md:hidden">
                    <Card className="border-0 shadow-lg">
                      <CardContent className="p-4">
                        <p className="text-[#1DA678] font-bold text-lg mb-1">{milestone.year}</p>
                        <h3 className="text-base font-semibold text-gray-900 mb-1">{milestone.title}</h3>
                        <p className="text-gray-600 text-sm">{milestone.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="flex-1 hidden md:block" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
            Ready to Join Our Community?
          </h2>
          <p className="text-base md:text-xl text-white/70 mb-6 md:mb-8">
            Start your learning journey today with a free trial class.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button 
              size="lg" 
              className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
