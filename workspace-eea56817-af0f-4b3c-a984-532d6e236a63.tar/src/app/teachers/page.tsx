'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Star,
  Users,
  Clock,
  GraduationCap,
  Award,
  Globe,
  Heart,
  CheckCircle2,
  ArrowRight,
  Calendar,
  BookOpen,
  MessageCircle,
} from 'lucide-react'
import Link from 'next/link'
import { Navigation, Footer, WhatsAppButton, PageHeader } from '@/components/layout'

const teachers = [
  {
    name: 'Miss Yomna',
    subjects: ['Arabic', 'Islamic Studies'],
    rating: 4.9,
    students: 55,
    lessons: 450,
    experience: '8 years',
    bio: 'Expert in Arabic language and Islamic Studies with a deep understanding of classical Arabic grammar. Creates engaging lessons that connect students to the beauty of the Arabic language.',
    languages: ['Arabic', 'English'],
  },
  {
    name: 'Hanan',
    subjects: ['Mathematics', 'Physics'],
    rating: 5.0,
    students: 48,
    lessons: 380,
    experience: '10 years',
    bio: 'Mathematics specialist with a talent for making complex concepts simple and understandable. Known for her patient approach and ability to build student confidence in problem-solving.',
    languages: ['Arabic', 'English'],
  },
  {
    name: 'Nashwa',
    subjects: ['English', 'IELTS Prep'],
    rating: 4.9,
    students: 42,
    lessons: 340,
    experience: '9 years',
    bio: 'Certified TEFL instructor specializing in IELTS preparation and English conversation. Helps students achieve their target scores with proven strategies and personalized practice.',
    languages: ['English', 'Arabic'],
  },
  {
    name: 'Mahmoud',
    subjects: ['Quran', 'Tajweed'],
    rating: 4.8,
    students: 38,
    lessons: 290,
    experience: '7 years',
    bio: 'Hafiz with expertise in Quran memorization and Tajweed rules. Creates personalized memorization plans and helps students perfect their recitation with beautiful makharij.',
    languages: ['Arabic', 'English'],
  },
  {
    name: 'Omar',
    subjects: ['Science', 'Biology'],
    rating: 4.8,
    students: 32,
    lessons: 250,
    experience: '6 years',
    bio: 'Science educator with expertise in biology and general science. Uses interactive methods and visual aids to make science engaging and memorable for students.',
    languages: ['Arabic', 'English'],
  },
  {
    name: 'Mr. Yusuf Ahmed',
    subjects: ['Programming', 'ICDL'],
    rating: 4.9,
    students: 35,
    lessons: 280,
    experience: '8 years',
    bio: 'Software developer turned educator with expertise in Python, JavaScript, and ICDL certification preparation. Helps students build practical skills through hands-on projects.',
    languages: ['Arabic', 'English'],
  },
]

const stats = [
  { icon: Users, value: '50+', label: 'Expert Tutors' },
  { icon: GraduationCap, value: '98%', label: 'Success Rate' },
  { icon: Clock, value: '24/7', label: 'Availability' },
  { icon: Globe, value: '10+', label: 'Countries' },
]

const requirements = [
  'Minimum 3 years of teaching experience',
  'Relevant degree or certification',
  'Strong communication skills',
  'Passion for education',
  'Reliable internet connection',
  'Flexible schedule availability',
]

export default function TeachersPage() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <PageHeader 
        title="Our Teachers" 
        subtitle="Meet our team of qualified and experienced educators"
        breadcrumb="Teachers"
      />

      {/* Stats */}
      <section className="py-8 md:py-12 bg-[#1DA678]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="w-8 h-8 md:w-10 md:h-10 text-white/80 mx-auto mb-2" />
                <p className="text-2xl md:text-4xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-white/70 text-sm md:text-base">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Our Teachers */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Quality Assurance</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Why Our <span className="text-[#1DA678]">Teachers Stand Out</span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-[#E8F8F2] to-white">
              <CardContent className="p-6 md:p-8 text-center">
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4 md:mb-6">
                  <GraduationCap className="w-7 h-7 md:w-8 md:h-8 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2 md:mb-3">Certified Educators</h3>
                <p className="text-gray-600 text-sm md:text-base">
                  All our teachers hold relevant degrees and certifications in their respective fields, 
                  ensuring high-quality instruction for every student.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-lg bg-gradient-to-br from-[#E8F8F2] to-white">
              <CardContent className="p-6 md:p-8 text-center">
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4 md:mb-6">
                  <Award className="w-7 h-7 md:w-8 md:h-8 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2 md:mb-3">Experienced Professionals</h3>
                <p className="text-gray-600 text-sm md:text-base">
                  Our tutors have an average of 8+ years of teaching experience, bringing proven 
                  methodologies and deep subject knowledge to every session.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-lg bg-gradient-to-br from-[#E8F8F2] to-white">
              <CardContent className="p-6 md:p-8 text-center">
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-[#1DA678] flex items-center justify-center mx-auto mb-4 md:mb-6">
                  <Heart className="w-7 h-7 md:w-8 md:h-8 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2 md:mb-3">Passionate Teachers</h3>
                <p className="text-gray-600 text-sm md:text-base">
                  We select teachers who are genuinely passionate about education and committed 
                  to helping each student reach their full potential.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Teachers */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Featured Tutors</Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              Meet Some of Our <span className="text-[#1DA678]">Expert Tutors</span>
            </h2>
            <p className="text-base md:text-xl text-gray-600 max-w-2xl mx-auto">
              Our tutors are carefully selected for their expertise, teaching ability, and dedication to student success.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {teachers.map((teacher, index) => (
              <Card 
                key={index} 
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white"
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-br from-[#1DA678] to-[#168a60] flex items-center justify-center text-white text-xl md:text-2xl font-bold flex-shrink-0">
                      {teacher.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base md:text-lg font-semibold text-gray-900 truncate">{teacher.name}</h3>
                      <div className="flex items-center gap-1 mb-1">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-3 h-3 md:w-4 md:h-4 ${i < Math.floor(teacher.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                          />
                        ))}
                        <span className="text-xs md:text-sm text-gray-600 ml-1">{teacher.rating}</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {teacher.subjects.map((subject) => (
                          <Badge key={subject} variant="secondary" className="bg-[#E8F8F2] text-[#1DA678] text-xs">
                            {subject}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 text-xs md:text-sm mb-4 line-clamp-2">{teacher.bio}</p>
                  
                  <div className="grid grid-cols-3 gap-2 md:gap-4 py-3 border-y border-gray-100 mb-4">
                    <div className="text-center">
                      <p className="text-base md:text-lg font-bold text-[#1DA678]">{teacher.students}+</p>
                      <p className="text-xs text-gray-500">Students</p>
                    </div>
                    <div className="text-center">
                      <p className="text-base md:text-lg font-bold text-[#1DA678]">{teacher.lessons}+</p>
                      <p className="text-xs text-gray-500">Lessons</p>
                    </div>
                    <div className="text-center">
                      <p className="text-base md:text-lg font-bold text-[#1DA678]">{teacher.experience}</p>
                      <p className="text-xs text-gray-500">Experience</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Globe className="w-3 h-3 md:w-4 md:h-4" />
                    <span>Languages: {teacher.languages.join(', ')}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-10 md:mt-12">
            <p className="text-gray-600 mb-4 text-sm md:text-base">
              And many more qualified tutors available for all subjects!
            </p>
            <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white" asChild>
              <Link href="/contact#trial">
                Book a Trial to Meet Your Tutor
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Become a Teacher */}
      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-10 md:gap-16 items-center">
            <div>
              <Badge className="mb-4 bg-[#E8F8F2] text-[#1DA678]">Join Our Team</Badge>
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 md:mb-6">
                Become a <span className="text-[#1DA678]">Teacher at Abobakr Academy</span>
              </h2>
              <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                Are you passionate about teaching? Join our growing team of educators and make a difference 
                in students&apos; lives while enjoying flexible scheduling and competitive compensation.
              </p>
              
              <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-4">Requirements:</h3>
              <div className="space-y-3 mb-6 md:mb-8">
                {requirements.map((req, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#1DA678] flex-shrink-0" />
                    <span className="text-gray-600 text-sm md:text-base">{req}</span>
                  </div>
                ))}
              </div>
              
              <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white" asChild>
                <Link href="/contact">
                  Apply to Teach
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </div>
            
            <div className="bg-gradient-to-br from-[#0f2922] to-[#1DA678] rounded-2xl md:rounded-3xl p-6 md:p-10 text-white">
              <h3 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Benefits of Teaching With Us</h3>
              <div className="space-y-3 md:space-y-4">
                {[
                  'Flexible working hours',
                  'Competitive pay rates',
                  'Work from anywhere',
                  'Professional development',
                  'Supportive community',
                  'Direct impact on students',
                ].map((benefit, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 md:w-6 md:h-6 text-[#4ADE80] flex-shrink-0" />
                    <span className="text-sm md:text-base">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-[#0f2922] via-[#1a3d32] to-[#0f2922]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
            Ready to Start Learning?
          </h2>
          <p className="text-base md:text-xl text-white/70 mb-6 md:mb-8">
            Book a free trial class and get matched with the perfect tutor for your needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-[#1DA678] hover:bg-[#168a60] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <Link href="/contact#trial">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Book Free Trial
              </Link>
            </Button>
            <Button 
              size="lg" 
              className="bg-[#25D366] hover:bg-[#20BA5C] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg rounded-full"
              asChild
            >
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </main>
  )
}
