'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import {
  Phone,
  Menu,
  X,
  MessageCircle,
  Facebook,
  Instagram,
  Mail,
  MapPin,
} from 'lucide-react'

export function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const menuItems = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
    { name: 'Courses', href: '/courses' },
    { name: 'Teachers', href: '/teachers' },
    { name: 'Success Stories', href: '/success-stories' },
    { name: 'Testimonials', href: '/testimonials' },
    { name: 'Pricing', href: '/pricing' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact', href: '/contact' },
  ]

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/'
    return pathname.startsWith(href)
  }

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-white/80 backdrop-blur-sm'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link href="/" className="flex items-center gap-2">
            <Image
              src="/logo.png"
              alt="Abobakr Academy Logo"
              width={40}
              height={40}
              className="w-10 h-10 md:w-12 md:h-12 object-contain"
            />
            <span className="text-lg md:text-xl font-bold text-[#1DA678]">Abobakr Academy</span>
          </Link>

          <div className="hidden lg:flex items-center gap-6 xl:gap-8">
            {menuItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`font-medium text-sm xl:text-base transition-colors ${
                  isActive(item.href)
                    ? 'text-[#1DA678] border-b-2 border-[#1DA678] pb-1'
                    : 'text-gray-700 hover:text-[#1DA678]'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-3">
            <Button className="bg-[#1DA678] hover:bg-[#168a60] text-white" asChild>
              <Link href="/contact#trial">Free Trial</Link>
            </Button>
          </div>

          <button
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-[#1DA678]" />
            ) : (
              <Menu className="w-6 h-6 text-[#1DA678]" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu with smooth animation */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-300 ease-in-out ${
          mobileMenuOpen ? 'max-h-[80vh] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="bg-white border-t shadow-xl">
          <div className="px-4 py-4 space-y-1 max-h-[70vh] overflow-y-auto">
            {menuItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`block py-3 px-4 rounded-xl font-medium transition-all duration-200 ${
                  isActive(item.href)
                    ? 'text-[#1DA678] bg-[#E8F8F2] shadow-sm'
                    : 'text-gray-700 hover:text-[#1DA678] hover:bg-gray-50'
                }`}
              >
                {item.name}
              </Link>
            ))}

            <div className="pt-4 mt-2 border-t space-y-3">
              <Button className="w-full bg-[#1DA678] hover:bg-[#168a60] text-white py-3 rounded-xl" asChild>
                <Link href="/contact#trial" onClick={() => setMobileMenuOpen(false)}>Free Trial</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}

// TikTok Icon Component
function TikTokIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
    </svg>
  )
}

export function Footer() {
  const currentYear = new Date().getFullYear()

  const quickLinks = [
    { name: 'Home', href: '/' },
    { name: 'All Courses', href: '/courses' },
    { name: 'About Us', href: '/about' },
    { name: 'Teachers', href: '/teachers' },
    { name: 'Success Stories', href: '/success-stories' },
    { name: 'Blog', href: '/blog' },
    { name: 'Testimonials', href: '/testimonials' },
    { name: 'Contact', href: '/contact' },
  ]

  const courses = [
    { name: 'Quran & Tajweed', href: '/courses/quran' },
    { name: 'Arabic Language', href: '/courses/arabic' },
    { name: 'English Language', href: '/courses/english' },
    { name: 'Mathematics', href: '/courses/mathematics' },
    { name: 'Science', href: '/courses/science' },
  ]

  const socialLinks = [
    { icon: Facebook, href: 'https://facebook.com/profile.php?id=100094681973805', label: 'Facebook' },
    { icon: Instagram, href: 'https://instagram.com/abobakracademy', label: 'Instagram' },
    { icon: MessageCircle, href: 'https://t.me/abobakracademy', label: 'Telegram' },
    { icon: TikTokIcon, href: 'https://tiktok.com/@abobakracademy', label: 'TikTok' },
  ]

  return (
    <footer className="bg-[#0f2922] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4 md:mb-6">
              <Image
                src="/logo.png"
                alt="Abobakr Academy Logo"
                width={48}
                height={48}
                className="w-10 h-10 md:w-12 md:h-12 object-contain"
              />
              <span className="text-xl md:text-2xl font-bold">Abobakr Academy</span>
            </Link>
            <p className="text-white/70 mb-4 md:mb-6 leading-relaxed text-sm md:text-base">
              Expert online private tutors for Islamic Studies, Languages, School Support & Digital Skills. Personalized 1-on-1 learning.
            </p>
            <div className="flex gap-2 md:gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-white/10 hover:bg-[#1DA678] flex items-center justify-center transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="w-4 h-4 md:w-5 md:h-5" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-base md:text-lg font-semibold mb-4 md:mb-6">Quick Links</h3>
            <ul className="space-y-2 md:space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-white/70 hover:text-[#1DA678] transition-colors text-sm md:text-base"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-base md:text-lg font-semibold mb-4 md:mb-6">Popular Courses</h3>
            <ul className="space-y-2 md:space-y-3">
              {courses.map((course) => (
                <li key={course.name}>
                  <Link
                    href={course.href}
                    className="text-white/70 hover:text-[#1DA678] transition-colors text-sm md:text-base"
                  >
                    {course.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-base md:text-lg font-semibold mb-4 md:mb-6">Contact Us</h3>
            <ul className="space-y-3 md:space-y-4">
              <li>
                <a
                  href="https://wa.me/966566518545"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 md:gap-3 text-white/70 hover:text-[#1DA678] transition-colors text-sm md:text-base"
                >
                  <Phone className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                  <span>+966 56 651 8545</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@abobakracademy.com"
                  className="flex items-center gap-2 md:gap-3 text-white/70 hover:text-[#1DA678] transition-colors text-sm md:text-base"
                >
                  <Mail className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                  <span>info@abobakracademy.com</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.abobakracademy.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 md:gap-3 text-white/70 hover:text-[#1DA678] transition-colors text-sm md:text-base"
                >
                  <MapPin className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                  <span>www.abobakracademy.com</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-3 md:gap-4">
            <p className="text-white/60 text-xs md:text-sm text-center md:text-left">
              © {currentYear} Abobakr Academy. All rights reserved.
            </p>
            <div className="flex flex-wrap justify-center gap-3 md:gap-6 text-xs md:text-sm">
              <Link href="/privacy" className="text-white/60 hover:text-[#1DA678] transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-white/60 hover:text-[#1DA678] transition-colors">
                Terms of Service
              </Link>
              <Link href="/faq" className="text-white/60 hover:text-[#1DA678] transition-colors">
                FAQ
              </Link>
              <a href="https://wa.me/966566518545" target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-[#1DA678] transition-colors">
                WhatsApp Support
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/966566518545"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50 group"
      aria-label="Chat on WhatsApp"
    >
      {/* Pulse ring effect */}
      <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-25" />

      {/* Main button with text - Enhanced visibility with strong shadow */}
      <div className="relative flex items-center bg-[#25D366] hover:bg-[#20BA5C] text-white rounded-full shadow-[0_4px_25px_rgba(37,211,102,0.7),0_0_0_3px_rgba(37,211,102,0.3)] hover:shadow-[0_6px_35px_rgba(37,211,102,0.8),0_0_0_4px_rgba(37,211,102,0.4)] transition-all duration-300 group-hover:scale-105">
        <div className="w-12 h-12 md:w-14 md:h-14 flex items-center justify-center">
          <MessageCircle className="w-6 h-6 md:w-7 md:h-7 text-white" strokeWidth={2.5} />
        </div>
        <span className="hidden md:block pr-5 pl-1 font-bold text-sm whitespace-nowrap drop-shadow-sm">
          Chat with us
        </span>
      </div>
    </a>
  )
}

export function PageHeader({ title, subtitle, breadcrumb }: { title: string; subtitle: string; breadcrumb?: string }) {
  return (
    <section className="pt-24 md:pt-32 pb-12 md:pb-16 bg-gradient-to-br from-[#E8F8F2] via-white to-[#F0FDF7]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {breadcrumb && (
          <nav className="mb-4 md:mb-6" aria-label="Breadcrumb">
            <ol className="flex items-center gap-2">
              <li>
                <Link 
                  href="/" 
                  className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-gray-600 bg-white rounded-full border border-gray-200 hover:text-[#1DA678] hover:border-[#1DA678] transition-colors shadow-sm"
                >
                  Home
                </Link>
              </li>
              <li className="text-gray-400">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </li>
              <li>
                <span className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-white bg-[#1DA678] rounded-full shadow-sm" aria-current="page">
                  {breadcrumb}
                </span>
              </li>
            </ol>
          </nav>
        )}
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-3 md:mb-4">
          {title}
        </h1>
        <p className="text-base md:text-xl text-gray-600 max-w-2xl">
          {subtitle}
        </p>
      </div>
    </section>
  )
}
