'use client'

import Script from 'next/script'

// FAQ Schema for Rich Snippets
interface FAQItem {
  question: string
  answer: string
}

export function FAQSchema({ faqs, courseName }: { faqs: FAQItem[]; courseName: string }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  }

  return (
    <Script
      id={`faq-schema-${courseName.toLowerCase().replace(/\s+/g, '-')}`}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  )
}

// Course Schema
interface CourseData {
  name: string
  description: string
  provider: string
  url: string
  category: string
  price?: string
  rating?: number
  reviewCount?: number
}

export function CourseSchema({ course }: { course: CourseData }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Course',
    name: course.name,
    description: course.description,
    provider: {
      '@type': 'Organization',
      name: course.provider,
      url: 'https://www.abobakracademy.com',
      telephone: '+966566518545',
      email: 'info@abobakracademy.com',
    },
    url: course.url,
    educationalLevel: 'All Levels',
    isAccessibleForFree: false,
    teachs: course.category,
    ...(course.rating && {
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: course.rating,
        reviewCount: course.reviewCount || 100,
        bestRating: 5,
        worstRating: 1,
      },
    }),
  }

  return (
    <Script
      id={`course-schema-${course.name.toLowerCase().replace(/\s+/g, '-')}`}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  )
}

// Service Schema for Tutoring
interface ServiceData {
  name: string
  description: string
  areaServed: string
  provider: string
  url: string
  category: string
}

export function ServiceSchema({ service }: { service: ServiceData }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: service.name,
    description: service.description,
    provider: {
      '@type': 'Organization',
      name: service.provider,
      url: 'https://www.abobakracademy.com',
    },
    areaServed: {
      '@type': 'Place',
      name: service.areaServed,
    },
    url: service.url,
    category: service.category,
    serviceType: 'Online Tutoring',
  }

  return (
    <Script
      id={`service-schema-${service.name.toLowerCase().replace(/\s+/g, '-')}`}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  )
}

// Breadcrumb Schema
interface BreadcrumbItem {
  name: string
  url: string
}

export function BreadcrumbSchema({ items }: { items: BreadcrumbItem[] }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  }

  return (
    <Script
      id="breadcrumb-schema"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  )
}

// Review Schema for Testimonials
interface ReviewData {
  author: string
  rating: number
  text: string
  courseName: string
}

export function ReviewSchema({ reviews, courseName }: { reviews: ReviewData[]; courseName: string }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: `${courseName} - Online Course`,
    description: `Online ${courseName} tutoring by Abobakr Academy`,
    review: reviews.map((review) => ({
      '@type': 'Review',
      author: {
        '@type': 'Person',
        name: review.author,
      },
      reviewRating: {
        '@type': 'Rating',
        ratingValue: review.rating,
        bestRating: 5,
      },
      reviewBody: review.text,
    })),
  }

  return (
    <Script
      id={`review-schema-${courseName.toLowerCase().replace(/\s+/g, '-')}`}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  )
}
