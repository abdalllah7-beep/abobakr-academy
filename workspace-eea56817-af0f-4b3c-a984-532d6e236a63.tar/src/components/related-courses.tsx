'use client'

import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowRight, BookMarked, Languages, Calculator, Atom, FlaskConical, Code, Award, Globe, Leaf, Globe2, Map, FileSpreadsheet, BookOpen, Landmark } from 'lucide-react'

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  BookMarked,
  Languages,
  Calculator,
  Atom,
  FlaskConical,
  Code,
  Award,
  Globe,
  Leaf,
  Globe2,
  Map,
  FileSpreadsheet,
  BookOpen,
  Landmark,
}

const colorMap: Record<string, string> = {
  'bg-emerald-500': 'bg-emerald-500',
  'bg-blue-500': 'bg-blue-500',
  'bg-purple-500': 'bg-purple-500',
  'bg-indigo-500': 'bg-indigo-500',
  'bg-rose-500': 'bg-rose-500',
  'bg-violet-500': 'bg-violet-500',
  'bg-orange-500': 'bg-orange-500',
  'bg-teal-500': 'bg-teal-500',
  'bg-yellow-500': 'bg-yellow-500',
  'bg-pink-500': 'bg-pink-500',
}

interface RelatedCourse {
  name: string
  href: string
  description: string
  icon: string
  color: string
  category: string
}

interface RelatedCoursesProps {
  courses: RelatedCourse[]
  title?: string
}

export function RelatedCourses({ courses, title = 'Related Courses' }: RelatedCoursesProps) {
  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6 md:mb-8">{title}</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {courses.map((course, index) => {
            const IconComponent = iconMap[course.icon] || BookOpen
            return (
              <Link key={index} href={course.href}>
                <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer group h-full">
                  <CardContent className="p-4 md:p-6">
                    <div className={`${colorMap[course.color] || 'bg-gray-500'} w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                      <IconComponent className="w-5 h-5 md:w-6 md:h-6 text-white" />
                    </div>
                    <Badge className="bg-gray-100 text-gray-600 text-xs mb-2">{course.category}</Badge>
                    <h3 className="font-semibold text-gray-900 text-sm md:text-base mb-1 group-hover:text-[#1DA678] transition-colors line-clamp-2">
                      {course.name}
                    </h3>
                    <p className="text-gray-500 text-xs md:text-sm line-clamp-2 hidden md:block">{course.description}</p>
                    <div className="mt-3 flex items-center text-[#1DA678] text-xs md:text-sm font-medium">
                      Learn More <ArrowRight className="w-3 h-3 md:w-4 md:h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}

// Pre-defined related courses by category
export const relatedCoursesByCategory = {
  'islamic-studies': [
    { name: 'Tajweed', href: '/courses/tajweed', description: 'Master Quranic pronunciation rules', icon: 'BookMarked', color: 'bg-emerald-500', category: 'Islamic Studies' },
    { name: "Qa'ida", href: '/courses/qaida', description: 'Arabic alphabet for beginners', icon: 'BookOpen', color: 'bg-teal-500', category: 'Islamic Studies' },
    { name: 'Islamic Studies', href: '/courses/islamic-studies', description: 'Comprehensive Islamic education', icon: 'BookMarked', color: 'bg-emerald-500', category: 'Islamic Studies' },
    { name: 'Arabic Language', href: '/courses/arabic', description: 'Modern Standard Arabic', icon: 'Languages', color: 'bg-blue-500', category: 'Languages' },
  ],
  'languages': [
    { name: 'English', href: '/courses/english', description: 'IELTS prep & conversation', icon: 'Languages', color: 'bg-blue-500', category: 'Languages' },
    { name: 'Arabic', href: '/courses/arabic', description: 'Modern Standard Arabic', icon: 'Languages', color: 'bg-teal-500', category: 'Languages' },
    { name: 'German', href: '/courses/german', description: 'Goethe exam preparation', icon: 'Languages', color: 'bg-yellow-500', category: 'Languages' },
    { name: 'French', href: '/courses/french', description: 'DELF preparation', icon: 'Languages', color: 'bg-indigo-500', category: 'Languages' },
  ],
  'school-support': [
    { name: 'Mathematics', href: '/courses/mathematics', description: 'K-12 math tutoring', icon: 'Calculator', color: 'bg-purple-500', category: 'School Support' },
    { name: 'Physics', href: '/courses/physics', description: 'Mechanics & modern physics', icon: 'Atom', color: 'bg-indigo-500', category: 'School Support' },
    { name: 'Chemistry', href: '/courses/chemistry', description: 'Organic & physical chemistry', icon: 'FlaskConical', color: 'bg-rose-500', category: 'School Support' },
    { name: 'Biology', href: '/courses/biology', description: 'Life sciences tutoring', icon: 'Leaf', color: 'bg-green-500', category: 'School Support' },
  ],
  'digital-skills': [
    { name: 'ICDL', href: '/courses/icdl', description: 'Computer certification', icon: 'Award', color: 'bg-orange-500', category: 'Digital Skills' },
    { name: 'Programming', href: '/courses/programming', description: 'Python & JavaScript', icon: 'Code', color: 'bg-violet-500', category: 'Digital Skills' },
    { name: 'Microsoft Office', href: '/courses/microsoft-office', description: 'Word, Excel, PowerPoint', icon: 'FileSpreadsheet', color: 'bg-blue-600', category: 'Digital Skills' },
  ],
}
